import xbmc
import xbmcgui
import time

# 打开视频插件窗口
xbmc.executebuiltin('ActivateWindow(Videos,Addons,return)')
time.sleep(0.5)

# 确保列表获得焦点
xbmc.executebuiltin('SendClick(0,0,0)')
time.sleep(0.3)

# 遍历列表查找TMDb Helper
found = False
for i in range(30):  # 假设最多30个项目
    label = xbmc.getInfoLabel('Container.ListItem.Label')
    xbmc.log(f"当前项目: {label}")
    
    if label and 'tmdb helper' in label.lower():
        xbmc.log(f"找到TMDb Helper: {label}")
        found = True
        break
    
    xbmc.executebuiltin('Action(Down)')  # 向下移动
    time.sleep(0.3)

if not found:
    xbmc.log("未找到TMDb Helper插件")
    xbmcgui.Dialog().ok("提示", "未找到TMDb Helper插件")
else:
    # 呼出菜单
    xbmc.executebuiltin('Action(Contextmenu)')
    time.sleep(0.5)
    
    # 选择菜单第一项（信息）
    xbmc.executebuiltin('Action(Select)')
    time.sleep(1)