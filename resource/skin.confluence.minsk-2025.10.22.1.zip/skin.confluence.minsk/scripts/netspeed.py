#!/usr/bin/env python3
import time
import xbmc

UPDATE_INTERVAL = 1.0  # 刷新时间改为1秒

def get_total_bytes():
    """获取所有网络接口的累计下载+上传字节数总和"""
    total = 0
    try:
        with open('/proc/net/dev', 'r') as f:
            lines = f.readlines()
        
        # 跳过标题行
        for line in lines[2:]:
            parts = list(filter(None, line.split()))
            if len(parts) >= 10:  # 确保有足够的数据列
                rx_bytes = int(parts[1])  # 下载字节数
                tx_bytes = int(parts[9])  # 上传字节数
                total += rx_bytes + tx_bytes
        return total
    except Exception as e:
        print(f"获取流量统计失败: {e}")
        return 0

def bytes_to_mbps(b, delta_time):
    """字节转 Mbps (1 Mbps = 1,000,000 比特/秒)"""
    return (b / delta_time) * 8 / 1_000_000

def set_skin_string(value):
    """调用 Kodi 的 Skin.SetString 方法设置变量"""
    xbmc.executebuiltin(f'Skin.SetString(netspeed,{value} Mbps)')

def clear_skin_string():
    """清除 Skin.String(netspeed)"""
    xbmc.executebuiltin('Skin.Reset(netspeed)')

def main():
    print("开始监控所有网络接口总流量速度（1秒刷新）")
    print("按 Ctrl+C 停止...")
    
    last_bytes = get_total_bytes()
    last_time = time.time()
    last_speed_str = ""

    try:
        while True:
            # 修复BUG：使用 Player.HasMedia 检测是否有媒体在播放（包括暂停状态）
            # 只有当没有媒体播放时才退出
            if not xbmc.getCondVisibility("Player.HasMedia"):
                print("检测到没有媒体播放，清除netspeed并退出...")
                clear_skin_string()
                break

            time.sleep(UPDATE_INTERVAL)
            
            current_bytes = get_total_bytes()
            current_time = time.time()

            delta_time = current_time - last_time
            delta_bytes = current_bytes - last_bytes

            # 计算 Mbps 并保留两位小数
            speed_mbps = bytes_to_mbps(delta_bytes, delta_time)
            speed_str = f"{speed_mbps:.2f}"

            # 只有速度变化时才更新 Skin.SetString
            if speed_str != last_speed_str:
                set_skin_string(speed_str)
                last_speed_str = speed_str

            # 更新上一次的值
            last_bytes = current_bytes
            last_time = current_time

    except KeyboardInterrupt:
        print("\n监控已停止。")
        clear_skin_string()

if __name__ == "__main__":
    main()