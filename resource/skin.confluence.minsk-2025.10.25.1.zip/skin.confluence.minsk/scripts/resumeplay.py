import xbmc
import xbmcgui
import xbmcvfs
import sqlite3
import re
import os
import time
import threading
import hashlib

SCRIPT_NAME = "ISO_Resume_Point_Extractor"
SCRIPT_PATH = "special://skin/scripts/resumeplay.py"
SKIN_HASH_PART1 = "657fa7bc2548a4da"
SKIN_HASH_PART2 = "798b0e2726f37b36"
COMMON_VIDEO_FORMATS = {"MKV", "MP4", "TS", "M2TS", "AVI", "FLV", "WMV", "MOV", "MPG", "MPEG", "VOB"}
WINDOW_HOME_ID = 10000
WINDOW_HOME_FILE = "Home.xml"

class ISOResumeExtractor:
    def __init__(self):
        self._skin_auth_passed = False
        self._init_skin_auth()
        
        self.info_delay = self._get_info_delay_param()
        
        self.current_filename = xbmc.getInfoLabel("ListItem.Filename").strip()
        self.current_file_path = self._get_file_path()
        self.in_video_info = self._check_video_info_window()  # 先初始化视频信息页面状态
        self.is_iso = self._check_iso_file()
        self.is_resumable = self._check_resumable()
        self.video_db_path = self._find_latest_video_db()
        self.resume_time = None
        self.resume_time_hhmmss = ""
        self.monitor = xbmc.Monitor()
        self.theoretical_time = self._calc_theoretical_resume_time()
        self.theoretical_time_failed = self.theoretical_time is None

    def log(self, message):
        xbmc.log(f"[{SCRIPT_NAME}] {message}", level=xbmc.LOGINFO)

    def _get_skin_config(self):
        try:
            skin_path = xbmcvfs.translatePath("special://skin/")
            addon_xml = os.path.join(skin_path, "addon.xml")
            if not xbmcvfs.exists(addon_xml):
                self.log("Skin config file missing")
                return ""
            with open(addon_xml, 'r', encoding='utf-8') as f:
                content = f.read()
            match = re.search(r'<addon\s+id="([^"]+?)"', content, re.I)
            return match.group(1).strip() if match else ""
        except Exception as e:
            self.log(f"Failed to read skin config: {str(e)}")
            return ""

    def _encode_str(self, text):
        if not text:
            return ""
        return hashlib.md5(text.encode('utf-8')).hexdigest()

    def _build_auth_key(self):
        return f"{SKIN_HASH_PART1}{SKIN_HASH_PART2}"

    def _init_skin_auth(self):
        skin_id = self._get_skin_config()
        current_key = self._encode_str(skin_id)
        target_key = self._build_auth_key()
        if current_key != target_key:
            raise SystemExit()
        self._skin_auth_passed = True

    def _get_info_delay_param(self):
        try:
            param_val = xbmc.getInfoLabel("Skin.String(info_delay)").strip()
            if not param_val:
                self.log("Skin.String(info_delay) parameter does not exist or is empty")
                return ""
            self.log(f"Read Skin.String(info_delay): {param_val}")
            return param_val
        except Exception as e:
            self.log(f"Failed to read Skin.String(info_delay): {str(e)}, treated as empty value")
            return ""

    def _set_info_delay_param(self, value):
        try:
            value_str = str(value).strip()
            xbmc.executebuiltin(f'Skin.SetString(info_delay,{value_str})')
            self.log(f"Skin.String(info_delay) set to: {value_str}")
        except Exception as e:
            self.log(f"Failed to set Skin.String(info_delay): {str(e)}")

    # 新增设置resumeselect字符串的方法
    def _set_resumeselect_param(self, value):
        try:
            value_str = str(value).strip()
            xbmc.executebuiltin(f'Skin.SetString(resumeselect,{value_str})')
            self.log(f"Skin.String(resumeselect) set to: {value_str}")
        except Exception as e:
            self.log(f"Failed to set Skin.String(resumeselect): {str(e)}")

    def _check_video_info_window(self):
        is_info_window = xbmc.getCondVisibility("Window.IsVisible(MovieInformation)") or \
                        xbmc.getCondVisibility("Window.IsVisible(DialogVideoInfo.xml)")
        self.log(f"Is in video info window: {is_info_window}")
        return is_info_window

    def _check_iso_file(self):
        is_match = re.search(r'\.iso$', self.current_filename, re.IGNORECASE) is not None
        self.log(f"ISO file check result: {is_match} (File: {self.current_filename})")
        return is_match

    def _check_resumable(self):
        is_resumable = xbmc.getCondVisibility("ListItem.IsResumable")
        self.log(f"File resumable check result: {is_resumable}")
        return is_resumable

    def _find_latest_video_db(self):
        db_dir = xbmcvfs.translatePath("special://database/")
        if not xbmcvfs.exists(db_dir):
            self.log(f"Error: Database directory does not exist - {db_dir}")
            return None

        db_files = []
        _, files = xbmcvfs.listdir(db_dir)
        for filename in files:
            if filename.startswith("MyVideos") and filename.endswith(".db"):
                try:
                    version = int(filename[8:-3])
                    db_files.append((version, os.path.join(db_dir, filename)))
                except (ValueError, IndexError):
                    self.log(f"Skipping invalid database file: {filename}")
                    continue

        if not db_files:
            self.log("Error: No MyVideos series database found")
            return None

        db_files.sort(reverse=True, key=lambda x: x[0])
        latest_db = db_files[0][1]
        self.log(f"Found latest video database: {latest_db}")
        return latest_db

    def _time_str_to_seconds(self, time_str):
        if not time_str:
            self.log("Error: Time string is empty, cannot convert")
            return None
        try:
            parts = list(map(int, time_str.split(':')))
            if len(parts) == 2:
                parts = [0] + parts
            elif len(parts) != 3:
                self.log(f"Error: Invalid time format (need HH:MM:SS or MM:SS) - {time_str}")
                return None

            hours, minutes, seconds = parts
            if minutes >= 60 or seconds >= 60:
                self.log(f"Error: Invalid time value (minutes/seconds cannot be ≥60) - {time_str}")
                return None
            
            total_seconds = hours * 3600 + minutes * 60 + seconds
            self.log(f"Time conversion: {time_str} → {total_seconds} seconds")
            return total_seconds
        except (ValueError, AttributeError) as e:
            self.log(f"Time conversion failed: {str(e)} (Input: {time_str})")
            return None

    def _get_file_ids(self):
        if not self.video_db_path or not xbmcvfs.exists(self.video_db_path):
            self.log("Error: Invalid database path")
            return []

        normalized_filename = self.current_filename.replace(os.sep, '/')
        file_ids = []

        try:
            conn = sqlite3.connect(self.video_db_path)
            cursor = conn.cursor()

            cursor.execute("SELECT idFile FROM files WHERE strFilename = ?", (normalized_filename,))
            results = cursor.fetchall()

            if not results:
                cursor.execute(
                    "SELECT idFile FROM files WHERE strFilename LIKE ? COLLATE NOCASE",
                    (f'%{re.escape(normalized_filename)}%',)
                )
                results = cursor.fetchall()

            file_ids = [item[0] for item in results] if results else []
            conn.close()
            self.log(f"Queried idFile list: {file_ids} (Matching file: {normalized_filename})")
        except Exception as e:
            self.log(f"Failed to query idFile: {str(e)}")

        return file_ids

    def _get_resume_points_by_file_ids(self, file_ids):
        resume_points = []
        if not self.video_db_path or not file_ids:
            self.log("Error: Invalid database path or empty idFile")
            return resume_points

        try:
            conn = sqlite3.connect(self.video_db_path)
            cursor = conn.cursor()

            for file_id in file_ids:
                cursor.execute(
                    "SELECT timeInSeconds FROM bookmark WHERE idFile = ? AND timeInSeconds IS NOT NULL AND type = 1",
                    (file_id,)
                )
                results = cursor.fetchall()
                if results:
                    for result in results:
                        if result[0] is not None:
                            resume_time = round(float(result[0]))
                            resume_points.append(resume_time)
                            self.log(f"idFile={file_id} Found type=1 resume point: {resume_time} seconds")

            conn.close()
        except Exception as e:
            self.log(f"Failed to query resume points: {str(e)}")

        return resume_points

    def _calc_theoretical_resume_time(self):
        try:
            percent_str = xbmc.getInfoLabel("ListItem.PercentPlayed").strip()
            if not percent_str or percent_str == "NaN":
                self.log(f"Error: Invalid progress - {percent_str}")
                return None
            percent_played = float(percent_str) / 100

            duration_str = xbmc.getInfoLabel("ListItem.Duration").strip()
            if not duration_str:
                self.log("Error: Video duration is empty (ListItem.Duration returned empty)")
                return None
            
            total_seconds = self._time_str_to_seconds(duration_str)
            if not total_seconds:
                return None

            theoretical_time = round(percent_played * total_seconds)
            self.log(f"Theoretical resume time: {percent_str}% × {total_seconds} seconds = {theoretical_time} seconds")
            return theoretical_time
        except (ValueError, TypeError) as e:
            self.log(f"Failed to calculate theoretical resume time: {str(e)}")
            return None

    def _select_closest_resume_point(self, resume_points):
        if len(resume_points) == 0:
            self.log("No available resume points")
            return None
        elif len(resume_points) == 1:
            selected = resume_points[0]
            self.log(f"Only 1 type=1 resume point, selected directly: {selected} seconds")
            return selected

        if self.theoretical_time_failed:
            shortest_time = min(resume_points)
            self.log(f"Theoretical resume time calculation failed, selecting shortest resume point: {shortest_time} seconds")
            return shortest_time

        if not self.theoretical_time:
            self.log("Error: Invalid theoretical resume time, cannot filter multiple resume points")
            return None

        closest_time = min(resume_points, key=lambda x: abs(x - self.theoretical_time))
        diff = abs(closest_time - self.theoretical_time)
        self.log(f"Multiple type=1 resume points filtered: Theoretical {self.theoretical_time} seconds → Selected {closest_time} seconds (Difference: {diff} seconds)")
        return closest_time

    def _handle_error(self, error_msg):
        self.log(f"Error handling: {error_msg}")
        
        if self.in_video_info:
            self.log("In video info window, execute SendClick(8)")
            xbmc.executebuiltin('SendClick(8)')
        
        self.log("Cannot get valid resume point, exiting after 5 seconds")
        time.sleep(5)
        raise SystemExit()

    def _manage_info_delay(self):
        if self._should_apply_blocking():
            self._set_info_delay_param(1)
            time.sleep(3)
            self._set_info_delay_param(0)
        else:
            self.log("In Home window, skip Skin.String(info_delay) blocking logic")

    def wait_for_fullscreen(self):
        timeout = 0
        while not xbmc.getCondVisibility("Window.IsVisible(FullscreenVideo)") and timeout < 600:
            if timeout % 100 == 0 and timeout > 0:
                self.log(f"Waiting for fullscreen video... Waited {timeout//10} seconds")
            time.sleep(0.1)
            timeout += 1
            if self.monitor.abortRequested():
                self.log("Program exit requested, stop waiting for fullscreen")
                return False
        
        if xbmc.getCondVisibility("Window.IsVisible(FullscreenVideo)"):
            self.log("Fullscreen video displayed")
            return True
        else:
            self.log("Waiting for fullscreen video timed out (Waited 60 seconds)", xbmc.LOGWARNING)
            return False

    def _check_fullscreen_and_seek(self):
        if self.wait_for_fullscreen() and self.resume_time is not None:
            self.log(f"Execute seek operation, jump to {self.resume_time} seconds ({self.resume_time_hhmmss})")
            xbmc.executebuiltin(f'Seek({self.resume_time})')
        else:
            self.log("Fullscreen video not detected or no resume time, skip seek operation")

    def _wait_for_contextmenu(self, timeout=5):
        start_time = time.time()
        self.log("Start monitoring if contextmenu pops up")
        
        while time.time() - start_time < timeout:
            if xbmc.getCondVisibility("Window.IsVisible(contextmenu)") or \
               xbmc.getCondVisibility("Window.IsVisible(DialogContextMenu)"):
                self.log("contextmenu popped up")
                return True
            time.sleep(0.1)
            if self.monitor.abortRequested():
                self.log("Program exit requested, stop contextmenu monitoring")
                return False
        
        self.log(f"contextmenu monitoring timed out (Not popped up within {timeout} seconds)")
        return False

    def _get_file_extension_info(self):
        ext_match = re.search(r'\.([^.]+)$', self.current_filename, re.IGNORECASE)
        if not ext_match:
            self.log("Failed to get file extension")
            return ("未知格式", "原方式播放")
        
        ext = ext_match.group(1).upper()
        self.log(f"Extracted file extension: {ext}")
        
        if ext == "ISO":
            return ("ISO原盘", "原方式播放[COLOR=orange]（续播无法切换音轨和字幕）[/COLOR]")
        elif ext in COMMON_VIDEO_FORMATS:
            return (f"{ext}格式", "原方式播放[COLOR=FF00FF00]（续播可切换音轨和字幕）[/COLOR]")
        else:
            return ("未知格式", "原方式播放[COLOR=orange]（续播能否切换未知）[/COLOR]")

    def _get_file_path(self):
        file_path = xbmc.getInfoLabel("ListItem.FilenameAndPath").strip()
        self.log(f"File full path (FilenameAndPath): {file_path}")
        return file_path

    def _is_home_window(self):
        current_window_id = xbmcgui.getCurrentWindowId()
        current_window_file = xbmc.getInfoLabel("Window.Property(xmlfile)").strip()
        is_home = (current_window_id == WINDOW_HOME_ID) and (current_window_file == WINDOW_HOME_FILE)
        self.log(f"Is Home window (ID:{WINDOW_HOME_ID}, File:{WINDOW_HOME_FILE}): {is_home}")
        return is_home

    def _should_apply_blocking(self):
        return not self._is_home_window()

    def _show_playback_choices(self):
        # 在弹出选择窗前设置resumeselect为1
        self._set_resumeselect_param(1)
        # 启动线程延时2秒后设置为0（不阻塞主界面）
        threading.Thread(target=lambda: [time.sleep(2), self._set_resumeselect_param(0)], daemon=True).start()

        if self.resume_time == 0:
            self.log("Resume point is 0, showing playback choices")

        format_prefix, original_play_note = self._get_file_extension_info()
        original_play_option = f"{format_prefix}-{original_play_note}"

        choices = [
            f"从续播点[COLOR=FF00FF00]({self.resume_time_hhmmss})[/COLOR]播放-[COLOR=FF00FF00](可切换字幕/音轨)[/COLOR]",
            "从头播放-[COLOR=FF00FF00](可切换字幕/音轨)[/COLOR]",
            original_play_option
        ]
        
        dialog = xbmcgui.Dialog()
        selection = dialog.select("选择播放方式", choices)
        
        self.log(f"User selected option {selection}, closing selection window")

        if self._should_apply_blocking():
            threading.Thread(target=self._manage_info_delay, daemon=True).start()

        if self._is_home_window():
            if not self.current_file_path:
                self.log("Error: File full path is empty, cannot execute related operations")
                return

            if selection == 0:
                self.log("Home window: Play from resume point - execute playmedia with noresume")
                xbmc.executebuiltin(f'PlayMedia({self.current_file_path},noresume)')
                threading.Thread(target=self._check_fullscreen_and_seek, daemon=True).start()
                time.sleep(5)

            elif selection == 1:
                self.log("Home window: Play from start - execute playmedia with noresume")
                xbmc.executebuiltin(f'PlayMedia({self.current_file_path},noresume)')
                time.sleep(5)

            elif selection == 2:
                self.log("Home window: Original playback - call contextmenu (Action(ContextMenu))")
                xbmc.executebuiltin('Action(ContextMenu)')
                time.sleep(5)

            else:
                self.log("Home window: User canceled selection")

        else:
            if selection == 0:
                self.log("Non-Home window: Play from resume point")
                if self.in_video_info:
                    xbmc.executebuiltin('SendClick(8)')
                    time.sleep(0.2)
                    if not self._wait_for_contextmenu():
                        self.log("contextmenu not popped up, stop process")
                        return
                
                xbmc.executebuiltin('Action(Down)')
                time.sleep(0.1)
                xbmc.executebuiltin('Action(Select)')
                threading.Thread(target=self._check_fullscreen_and_seek, daemon=True).start()
                if self._should_apply_blocking():
                    time.sleep(5)
                
            elif selection == 1:
                self.log("Non-Home window: Play from start")
                if self.in_video_info:
                    xbmc.executebuiltin('SendClick(8)')
                    time.sleep(0.2)
                    if not self._wait_for_contextmenu():
                        self.log("contextmenu not popped up, stop process")
                        return
                
                xbmc.executebuiltin('Action(Down)')
                time.sleep(0.1)
                xbmc.executebuiltin('Action(Select)')
                if self._should_apply_blocking():
                    time.sleep(5)
                
            else:
                self.log("Non-Home window: Original playback or cancel")
                if self.in_video_info:
                    xbmc.executebuiltin('SendClick(8)')
                if self._should_apply_blocking():
                    time.sleep(5)

    def run(self):
        # 检查onlyiso设置及视频信息页面特殊处理
        only_iso_enabled = xbmc.getCondVisibility("Skin.HasSetting(onlyiso)")
        self.log(f"Skin.HasSetting(onlyiso) status: {only_iso_enabled}")
        
        # 核心修改：Home页面且onlyiso为真时，对非ISO文件自动执行上下文菜单
        if only_iso_enabled and self._is_home_window():
            has_iso = re.search(r'iso', self.current_filename, re.IGNORECASE) is not None
            self.log(f"Filename contains ISO (case-insensitive): {has_iso}")
            
            if not has_iso:
                self.log("Home窗口+onlyiso启用+非ISO文件：自动执行上下文菜单")
                xbmc.executebuiltin('Action(ContextMenu)')  # 执行上下文菜单
                self.log("执行完毕，延时5秒后退出脚本")
                time.sleep(5)
                return
        
        # 视频信息页面且onlyiso为真时，对非ISO文件直接执行确认
        if only_iso_enabled and self.in_video_info:
            has_iso = re.search(r'iso', self.current_filename, re.IGNORECASE) is not None
            self.log(f"Filename contains ISO (case-insensitive): {has_iso}")
            
            if not has_iso:
                self.log("视频信息页面+onlyiso启用+非ISO文件：执行模拟确认按键")
                xbmc.executebuiltin('SendClick(8)')  # 模拟确认按键
                self.log("延时5秒后退出脚本")
                time.sleep(5)
                return
        
        # 原有onlyiso逻辑：非Home和非视频信息页的情况
        if only_iso_enabled:
            has_iso = re.search(r'iso', self.current_filename, re.IGNORECASE) is not None
            self.log(f"Filename contains ISO (case-insensitive): {has_iso}")
            
            if not has_iso:
                self.log("Filename does not contain ISO, exiting after 5 seconds")
                time.sleep(5)
                return
        
        if self.info_delay in ("1", ""):
            self.log(f"Skin.String(info_delay) is '{self.info_delay}', meets exit condition, exit after 1 second delay")
            time.sleep(1)
            return

        self.log("=" * 50)
        self.log(f"Script starts running (Path: {SCRIPT_PATH})")
        self.log("=" * 50)

        if self._is_home_window() and not self.is_resumable:
            self.log("Home window and file is not resumable: execute playmedia directly")
            if self.current_file_path:
                xbmc.executebuiltin(f'PlayMedia({self.current_file_path})')
                time.sleep(5)
            else:
                self.log("Error: File path is empty, cannot play directly")
            return

        if not (self.in_video_info or self.is_resumable):
            if self.in_video_info:
                self.log("In video info window, skip ISO and resumable check")
            else:
                self.log("Core conditions not met (Non-resumable and not in video info window), exit")
                return

        file_ids = self._get_file_ids()
        if not file_ids:
            self._handle_error("No matching idFile queried")

        resume_points = self._get_resume_points_by_file_ids(file_ids)
        if not resume_points:
            self._handle_error("No valid type=1 resume points queried")

        self.resume_time = self._select_closest_resume_point(resume_points)
        if not self.resume_time:
            self._handle_error("Cannot determine valid resume point")

        self.resume_time_hhmmss = time.strftime('%H:%M:%S', time.gmtime(self.resume_time))
        self.log(f"Final valid resume point: {self.resume_time} seconds ({self.resume_time_hhmmss})")

        self._show_playback_choices()

        self.log("Script runs completed and exits")
        self.log("=" * 50)

if __name__ == "__main__":
    extractor = ISOResumeExtractor()
    extractor.run()