#!/usr/bin/env python3
import os
import xbmc

# 脚本路径
SKINUPDATE_PATH = "/storage/.kodi/addons/skin.confluence.minsk/scripts/skinupdate.py"
VERSION_PATH = "/storage/.kodi/addons/skin.confluence.minsk/scripts/version.py"
BDMVPLAY_PATH = "/storage/.kodi/addons/skin.confluence.minsk/scripts/bdmvplay.py"
AUTOSTART_PATH = "/storage/.config/autostart.sh"

# 要写入的命令行（延迟 5 秒后运行）
command_skinupdate = f"(sleep 5 && kodi-send --action=\"RunScript(special://skin/scripts/skinupdate.py)\") &\n"
command_version = f"(sleep 5 && kodi-send --action=\"RunScript(special://skin/scripts/version.py)\") &\n"
command_bdmvplay = f"(sleep 5 && kodi-send --action=\"RunScript(special://skin/scripts/bdmvplay.py)\") &\n"

def ensure_autostart():
    # 检查 autostart.sh 是否存在
    if not os.path.exists(AUTOSTART_PATH):
        print(f"未找到 {AUTOSTART_PATH}，跳过脚本执行。")
        return

    # 检查是否已经有命令
    with open(AUTOSTART_PATH, "r") as f:
        lines = f.readlines()

    skinupdate_exists = any(command_skinupdate.strip() in line.strip() for line in lines)
    version_exists = any(command_version.strip() in line.strip() for line in lines)
    bdmvplay_exists = any(command_bdmvplay.strip() in line.strip() for line in lines)

    if skinupdate_exists and version_exists and bdmvplay_exists:
        print("autostart.sh 已包含运行 skinupdate.py、version.py 和 bdmvplay.py 的指令，无需修改。")
        return

    # 如果没有，则追加命令
    with open(AUTOSTART_PATH, "a") as f:
        if not skinupdate_exists:
            f.write("\n# 开机运行皮肤更新脚本\n")
            f.write(command_skinupdate)
        if not version_exists:
            f.write("\n# 开机运行版本信息设置脚本\n")
            f.write(command_version)
        if not bdmvplay_exists:
            f.write("\n# 开机运行BDMV播放脚本\n")
            f.write(command_bdmvplay)

    print("已在 autostart.sh 中添加缺失的脚本启动命令。")

    # 立即运行缺失的脚本
    if not skinupdate_exists:
        print("立即运行一次 skinupdate.py 脚本...")
        xbmc.executebuiltin('RunScript(special://skin/scripts/skinupdate.py)')
    if not version_exists:
        print("立即运行一次 version.py 脚本...")
        xbmc.executebuiltin('RunScript(special://skin/scripts/version.py)')
    if not bdmvplay_exists:
        print("立即运行一次 bdmvplay.py 脚本...")
        xbmc.executebuiltin('RunScript(special://skin/scripts/bdmvplay.py)')

if __name__ == "__main__":
    ensure_autostart()