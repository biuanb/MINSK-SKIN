import xbmc
import time
import re

def get_build_date_from_kernel_version():
    """从System.KernelVersion中提取构建日期，处理获取失败的重试逻辑"""
    xbmc.log("尝试从System.KernelVersion获取构建日期", xbmc.LOGINFO)
    
    # 定义重试等待时间（秒）
    retry_delays = [10, 20, 30]
    kernel_version = None
    date_str = None
    
    # 首次尝试获取
    kernel_version = xbmc.getInfoLabel("System.KernelVersion")
    xbmc.log(f"首次获取到的System.KernelVersion值: {kernel_version}", xbmc.LOGINFO)
    date_str = extract_date(kernel_version)
    
    # 检查是否获取到日期，未获取到则按策略重试
    for i, delay in enumerate(retry_delays):
        if not date_str:
            xbmc.log(f"未从System.KernelVersion中获取到日期，将等待{delay}秒后第{i+2}次重试", xbmc.LOGINFO)
            time.sleep(delay)
            kernel_version = xbmc.getInfoLabel("System.KernelVersion")
            xbmc.log(f"第{i+2}次获取到的System.KernelVersion值: {kernel_version}", xbmc.LOGINFO)
            date_str = extract_date(kernel_version)
        else:
            break  # 获取到日期则退出重试循环
    
    return date_str, kernel_version

def extract_date(kernel_version):
    """从内核版本字符串中提取日期"""
    if not kernel_version:
        return None
    
    # 正则匹配8位数字的日期（YYYYMMDD格式）
    pattern = re.compile(r'(\d{8})')
    match = pattern.search(kernel_version)
    
    if match:
        date_str = match.group(1)
        xbmc.log(f"提取到的构建日期: {date_str}", xbmc.LOGINFO)
        return date_str
    else:
        xbmc.log(f"无法从'{kernel_version}'中提取日期", xbmc.LOGWARNING)
        return None

def get_prefix_from_kernel_version(kernel_version):
    """根据内核版本字符串判断前缀"""
    if not kernel_version:
        return "未知"
        
    lower_version = kernel_version.lower()
    
    if "nightly" in lower_version:
        return "夜版CE-"
    elif "official" in lower_version and "nightly" not in lower_version:
        return "原版CE-"
    elif "community" in lower_version:
        return "CPM分支-"
    else:
        return "未知"

def set_build_date_with_prefix():
    """根据内核版本字符串判断前缀，并设置构建日期"""
    build_date, kernel_version = get_build_date_from_kernel_version()
    xbmc.log(f"处理后的构建日期: {build_date}, 内核版本: {kernel_version}", xbmc.LOGINFO)
    
    if not build_date:
        build_date = "未知"  # 无法获取日期时设置为中文"未知"
        final_build_date = build_date
    else:
        # 获取日期成功后再获取前缀
        prefix = get_prefix_from_kernel_version(kernel_version)
        final_build_date = f"{prefix}{build_date}"
        
    xbmc.log(f"设置Skin.SetString(BuildDate, {final_build_date})", xbmc.LOGINFO)
    xbmc.executebuiltin(f'Skin.SetString(BuildDate,{final_build_date})')

def set_version_from_file():
    """从version.txt读取版本号，如果不存在则根据条件创建"""
    from xbmcvfs import translatePath, exists
    import os
    import subprocess
    
    home_path = translatePath('special://home/userdata/')
    version_file = os.path.join(home_path, 'version.txt')
    
    # 如果version.txt已存在，则直接读取
    if exists(version_file):
        try:
            with open(version_file, 'r', encoding='utf-8', errors='ignore') as f:
                version_content = f.readline().strip()
            xbmc.executebuiltin(f'Skin.SetString(version,{version_content})')
            return
        except Exception as e:
            xbmc.log(f"读取version.txt失败: {str(e)}", xbmc.LOGERROR)
            # 即使读取失败，我们也继续尝试创建新文件
    
    # 检查挂载到 /flash 的分区大小
    try:
        # 使用df命令获取 /flash 分区大小信息
        result = subprocess.check_output(['df', '-P', '/flash'], 
                                        stderr=subprocess.STDOUT, 
                                        universal_newlines=True)
        
        # 解析输出获取分区大小(KB)
        lines = result.strip().split('\n')
        if len(lines) >= 2:
            parts = lines[1].split()
            if len(parts) >= 2:
                size_kb = int(parts[1])
                size_mb = size_kb / 1024
                
                xbmc.log(f"/flash分区大小: {size_mb:.2f}MB", xbmc.LOGINFO)
                
                # 判断分区大小是否大于800MB
                if size_mb > 800:
                    version_content = "Minsk-20251007"
                else:
                    # 检查/flash目录下的文件
                    if exists('/flash/KERNELcpm.img.md5') or exists('/flash/KERNELce.img.md5'):
                        version_content = "Minsk-20250926"
                    else:
                        version_content = "Minsk-早期版本"
                        
                # 创建version.txt文件
                with open(version_file, 'w', encoding='utf-8') as f:
                    f.write(version_content)
                    
                xbmc.log(f"创建version.txt，内容: {version_content}", xbmc.LOGINFO)
                xbmc.executebuiltin(f'Skin.SetString(version,{version_content})')
                return
                
    except Exception as e:
        xbmc.log(f"检查/flash分区大小失败: {str(e)}", xbmc.LOGERROR)
    
    # 如果所有检查都失败，设置为"Minsk-未知版本"
    xbmc.executebuiltin('Skin.SetString(version,Minsk-未知版本)')

if __name__ == '__main__':
    xbmc.log("开始执行版本信息脚本", xbmc.LOGINFO)
    set_build_date_with_prefix()
    set_version_from_file()
    xbmc.log("版本信息脚本执行完成", xbmc.LOGINFO)