#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import subprocess
import time
import threading
import xbmc
import xbmcgui

def reboot_system():
    """先同步数据再强制重启"""
    xbmc.log("同步数据并强制重启", xbmc.LOGINFO)
    subprocess.run(["sync"])
    subprocess.run(["reboot", "-f"])

def poweroff_system():
    """先同步数据，显示通知，延迟后执行关机"""
    xbmc.log("同步数据并执行KODI安全关机", xbmc.LOGINFO)
    subprocess.run(["sync"])

    # 显示通知（非阻塞）
    xbmcgui.Dialog().notification(
        "系统提示", 
        "正在安全关机中...",
        xbmcgui.NOTIFICATION_INFO, 
        3000  # 显示3秒
    )

    # 延迟关机，让用户看到提示
    time.sleep(0.5)
    xbmc.executebuiltin("Powerdown()")

if __name__ == "__main__":
    args = sys.argv[1:]
    if args and args[0].lower() == "reboot":
        reboot_system()
    elif args and args[0].lower() == "turnoff":
        poweroff_system()
    else:
        xbmc.log("未指定或参数错误，不执行任何操作。", xbmc.LOGWARNING)