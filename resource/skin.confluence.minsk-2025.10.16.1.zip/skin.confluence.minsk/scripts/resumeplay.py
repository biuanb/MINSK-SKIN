import xbmc
import xbmcgui
import xbmcvfs
import sqlite3
import os
import time

# 全局变量用于存储当前处理的bookmark_id
current_bookmark_id = None

def wait_for_context_menu(timeout=1.0):
    """等待上下文菜单弹出（超时时间默认1秒）"""
    xbmc.log("[续播脚本] 开始等待上下文菜单弹出", xbmc.LOGINFO)
    start_time = time.time()
    interval = 0.05  # 检查间隔（50毫秒）
    max_attempts = int(timeout / interval)  # 最大检查次数
    
    for attempt in range(max_attempts):
        if xbmc.getCondVisibility("Window.IsVisible(ContextMenu)"):
            xbmc.log(f"[续播脚本] 上下文菜单已弹出（耗时 {time.time()-start_time:.3f} 秒）", xbmc.LOGINFO)
            return True
        time.sleep(interval)
    
    xbmc.log(f"[续播脚本] 等待上下文菜单超时（超过 {timeout} 秒）", xbmc.LOGWARNING)
    return False

def get_resume_point(filename_only):
    """仅从bookmark表读取续播点及bookmark_id，不修改数据"""
    global current_bookmark_id
    xbmc.log(f"[续播脚本] 开始查询续播点，文件名: {filename_only}", xbmc.LOGINFO)
    
    db_path = xbmcvfs.translatePath("special://userdata/Database/")
    db_files = [f for f in os.listdir(db_path) if f.startswith("MyVideos") and f.endswith(".db")]
    
    if not db_files:
        xbmc.log("[续播脚本] 未找到 MyVideos*.db 数据库文件", xbmc.LOGWARNING)
        return None
        
    db_file = max(db_files)
    full_db_path = os.path.join(db_path, db_file)
    
    try:
        conn = sqlite3.connect(full_db_path)
        cursor = conn.cursor()
        
        # 仅查询type=1的续播点（不修改）
        cursor.execute("""
            SELECT b.idBookmark, b.timeInSeconds
            FROM bookmark b
            JOIN files f ON f.idFile = b.idFile
            WHERE f.strFileName = ?
              AND b.type = 1
            ORDER BY b.idBookmark DESC
            LIMIT 1
        """, (filename_only,))
        
        result = cursor.fetchone()
        conn.close()
        
        if not result or result[1] is None:
            xbmc.log("[续播脚本] 查询结果为空或 timeInSeconds 为 None", xbmc.LOGINFO)
            current_bookmark_id = None
            return None
        
        bookmark_id, resume_seconds = result
        current_bookmark_id = bookmark_id  # 记录bookmark_id供后续使用
        xbmc.log(f"[续播脚本] 查询到续播点: {float(resume_seconds)} 秒 (ID: {bookmark_id})", xbmc.LOGINFO)
        return float(resume_seconds)
        
    except Exception as e:
        xbmc.log(f"[续播脚本] 续播点查询失败: {str(e)}", xbmc.LOGERROR)
        current_bookmark_id = None
        return None

def update_bookmark_type(bookmark_id):
    """将指定bookmark_id的type修改为0"""
    if not bookmark_id:
        xbmc.log("[续播脚本] 无有效bookmark_id，无法修改type", xbmc.LOGWARNING)
        return False
        
    db_path = xbmcvfs.translatePath("special://userdata/Database/")
    db_files = [f for f in os.listdir(db_path) if f.startswith("MyVideos") and f.endswith(".db")]
    
    if not db_files:
        xbmc.log("[续播脚本] 未找到 MyVideos*.db 数据库文件，无法修改type", xbmc.LOGWARNING)
        return False
        
    db_file = max(db_files)
    full_db_path = os.path.join(db_path, db_file)
    
    try:
        conn = sqlite3.connect(full_db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE bookmark SET type = 0 WHERE idBookmark = ?", (bookmark_id,))
        conn.commit()
        conn.close()
        
        xbmc.log(f"[续播脚本] 已将续播点type修改为0 (ID: {bookmark_id})", xbmc.LOGINFO)
        return True
        
    except Exception as e:
        xbmc.log(f"[续播脚本] 修改续播点type失败: {str(e)}", xbmc.LOGERROR)
        return False

def delete_bookmark(bookmark_id):
    """从数据库中删除指定bookmark_id的续播点记录"""
    if not bookmark_id:
        xbmc.log("[续播脚本] 无有效bookmark_id，无法删除续播点", xbmc.LOGWARNING)
        return False
        
    db_path = xbmcvfs.translatePath("special://userdata/Database/")
    db_files = [f for f in os.listdir(db_path) if f.startswith("MyVideos") and f.endswith(".db")]
    
    if not db_files:
        xbmc.log("[续播脚本] 未找到 MyVideos*.db 数据库文件，无法删除续播点", xbmc.LOGWARNING)
        return False
        
    db_file = max(db_files)
    full_db_path = os.path.join(db_path, db_file)
    
    try:
        conn = sqlite3.connect(full_db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM bookmark WHERE idBookmark = ?", (bookmark_id,))
        conn.commit()
        conn.close()
        
        xbmc.log(f"[续播脚本] 已删除续播点记录 (ID: {bookmark_id})", xbmc.LOGINFO)
        return True
        
    except Exception as e:
        xbmc.log(f"[续播脚本] 删除续播点失败: {str(e)}", xbmc.LOGERROR)
        return False

def restore_bookmark_type():
    """将之前修改为0的bookmark type恢复为1"""
    global current_bookmark_id
    if not current_bookmark_id:
        xbmc.log("[续播脚本] 没有需要恢复的bookmark记录", xbmc.LOGINFO)
        return False
        
    db_path = xbmcvfs.translatePath("special://userdata/Database/")
    db_files = [f for f in os.listdir(db_path) if f.startswith("MyVideos") and f.endswith(".db")]
    
    if not db_files:
        xbmc.log("[续播脚本] 未找到 MyVideos*.db 数据库文件，无法恢复type", xbmc.LOGWARNING)
        return False
        
    db_file = max(db_files)
    full_db_path = os.path.join(db_path, db_file)
    
    try:
        conn = sqlite3.connect(full_db_path)
        cursor = conn.cursor()
        cursor.execute("UPDATE bookmark SET type = 1 WHERE idBookmark = ?", (current_bookmark_id,))
        conn.commit()
        conn.close()
        
        xbmc.log(f"[续播脚本] 已将续播点type恢复为1 (ID: {current_bookmark_id})", xbmc.LOGINFO)
        current_bookmark_id = None
        return True
        
    except Exception as e:
        xbmc.log(f"[续播脚本] 恢复续播点type失败: {str(e)}", xbmc.LOGERROR)
        return False

def wait_for_restore_trigger(total_timeout=60):
    """
    等待恢复type的触发条件（或关系）：
    1. 检测到全屏视频窗口
    2. 检测到okdialog/DialogConfirm.xml窗口
    满足任意一个即恢复type，总超时60秒
    """
    global current_bookmark_id
    if not current_bookmark_id:
        xbmc.log("[续播脚本] 无需要恢复的bookmark记录，跳过触发检测", xbmc.LOGINFO)
        return False
        
    xbmc.log("[续播脚本] 开始等待恢复触发条件（全屏或确认对话框）", xbmc.LOGINFO)
    timeout_count = 0
    check_interval = 0.1  # 100毫秒检查一次
    
    while timeout_count < total_timeout * 10:  # 转换为0.1秒单位
        # 条件1：检测全屏窗口
        if xbmc.getCondVisibility("Window.IsVisible(FullscreenVideo)"):
            xbmc.log("[续播脚本] 触发条件满足：检测到全屏视频窗口", xbmc.LOGINFO)
            restore_bookmark_type()
            return True
        
        # 条件2：检测目标对话框（与条件1为或关系）
        if (xbmc.getCondVisibility("Window.IsVisible(okdialog)") or 
            xbmc.getCondVisibility("Window.IsVisible(DialogConfirm.xml)")):
            xbmc.log("[续播脚本] 触发条件满足：检测到确认对话框", xbmc.LOGINFO)
            restore_bookmark_type()
            return True
        
        time.sleep(check_interval)
        timeout_count += 1
    
    xbmc.log(f"[续播脚本] 等待恢复触发条件超时（超过 {total_timeout} 秒）", xbmc.LOGWARNING)
    return False

def reset_context_menu_cache():
    """重置上下文菜单缓存（通过刷新容器实现）"""
    xbmc.log("[续播脚本] 开始重置上下文菜单缓存", xbmc.LOGINFO)
    xbmc.executebuiltin('Container.Refresh')
    time.sleep(0.2)
    xbmc.log("[续播脚本] 上下文菜单缓存已重置", xbmc.LOGINFO)

def seconds_to_time_str(seconds):
    """将秒数转换为 HH:MM:SS 格式"""
    hours = int(seconds) // 3600
    minutes = (int(seconds) % 3600) // 60
    seconds = int(seconds) % 60
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

def time_str_to_seconds(time_str):
    """回退用：将时间字符串转为秒数"""
    try:
        parts = time_str.split(':')
        seconds = 0
        if len(parts) == 3:
            seconds = int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
        elif len(parts) == 2:
            seconds = int(parts[0]) * 60 + int(parts[1])
        elif len(parts) == 1:
            seconds = int(parts[0])
        return seconds
    except Exception:
        return 0

# ---------------------- 主逻辑 ----------------------
is_resumable = xbmc.getCondVisibility("ListItem.IsResumable")
filename_only = xbmc.getInfoLabel("ListItem.FileName")

xbmc.log(f"[续播脚本] 当前文件: {filename_only}", xbmc.LOGINFO)
xbmc.log(f"[续播脚本] 是否可续播: {is_resumable}", xbmc.LOGINFO)

# 弹出上下文菜单
xbmc.executebuiltin('Action(ContextMenu)')
xbmc.log("[续播脚本] 已触发上下文菜单指令", xbmc.LOGINFO)

if not is_resumable:
    xbmc.log("[续播脚本] 不可续播，直接播放", xbmc.LOGINFO)
    xbmc.executebuiltin('SendClick(8)')
    if wait_for_context_menu():
        xbmc.executebuiltin('Action(Select)')
        xbmc.log("[续播脚本] 已确认上下文菜单", xbmc.LOGINFO)
    # 无续播点，无需执行恢复逻辑
    time.sleep(1)
else:
    # 仅查询续播点，不修改type
    resume_point = get_resume_point(filename_only)
    reset_context_menu_cache()
    
    # 回退逻辑（数据库查询失败时用百分比计算）
    if resume_point is None:
        xbmc.log("[续播脚本] 数据库未找到续播点，回退到百分比计算", xbmc.LOGINFO)
        percent_played_str = xbmc.getInfoLabel("ListItem.PercentPlayed")
        duration_str = xbmc.getInfoLabel("ListItem.Duration")
        
        try:
            percent_played = float(percent_played_str) / 100.0
        except Exception:
            percent_played = 0.0
            
        duration = time_str_to_seconds(duration_str)
        resume_point = int(percent_played * duration)
        xbmc.log(f"[续播脚本] 计算得到续播点: {resume_point} 秒", xbmc.LOGINFO)
    
    # 续播点调整（提前2秒）
    adjusted_resume_point = max(0, resume_point - 2)
    resume_time_str = seconds_to_time_str(adjusted_resume_point)
    xbmc.log(f"[续播脚本] 调整后续播时间: {resume_time_str}", xbmc.LOGINFO)
    
    # 显示用户选择菜单
    dialog = xbmcgui.Dialog()
    choice = dialog.contextmenu([
        f"从 {resume_time_str} 继续播放",
        "从头播放"
    ])
    xbmc.log(f"[续播脚本] 用户选择: {choice} (0=继续, 1=从头)", xbmc.LOGINFO)
    
    # 分支1：用户选择续播 → 执行type修改 + 或关系恢复逻辑
    if choice == 0:
        xbmc.log("[续播脚本] 用户选择从记忆点播放", xbmc.LOGINFO)
        # 仅当数据库查询到有效bookmark_id时才修改type
        if current_bookmark_id:
            update_bookmark_type(current_bookmark_id)
        
        xbmc.executebuiltin('SendClick(8)')
        if wait_for_context_menu():
            xbmc.executebuiltin('Action(Select)')
            xbmc.log("[续播脚本] 已确认上下文菜单", xbmc.LOGINFO)
            # 关键修改：调用或关系检测函数，满足任一条件即恢复type
            wait_for_restore_trigger()
        
        # 若恢复逻辑已执行（current_bookmark_id已重置），则无需重复跳转
        if current_bookmark_id is None:
            xbmc.log(f"[续播脚本] 跳转至 {adjusted_resume_point} 秒", xbmc.LOGINFO)
            xbmc.executebuiltin(f'Seek({adjusted_resume_point})')
    
    # 分支2：用户选择从头播放 → 删除续播点，无需恢复逻辑
    elif choice == 1:
        xbmc.log("[续播脚本] 用户选择从头播放", xbmc.LOGINFO)
        # 仅当数据库查询到有效bookmark_id时才删除
        if current_bookmark_id:
            delete_bookmark(current_bookmark_id)
            current_bookmark_id = None  # 重置全局变量
        
        xbmc.executebuiltin('SendClick(8)')
        if wait_for_context_menu():
            xbmc.executebuiltin('Action(Select)')
            xbmc.log("[续播脚本] 已确认上下文菜单", xbmc.LOGINFO)
        # 从头播放无type修改，无需恢复逻辑
        time.sleep(1)