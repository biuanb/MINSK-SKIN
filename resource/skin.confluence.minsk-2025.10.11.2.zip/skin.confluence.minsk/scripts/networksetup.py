# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import time

def show_yesno_dialog(title, message):
    """显示确认对话框"""
    dialog = xbmcgui.Dialog()
    return dialog.yesno(title, message)

def show_input_dialog(title, default=""):
    """显示输入对话框"""
    dialog = xbmcgui.Dialog()
    return dialog.input(title, default, type=xbmcgui.INPUT_ALPHANUM)

def show_select_dialog(title, options):
    """显示选择对话框"""
    dialog = xbmcgui.Dialog()
    ret = dialog.select(title, options)
    if ret >= 0:
        return options[ret]
    return None

def main():
    # 1. 选择协议
    protocol = show_select_dialog("选择网络协议", ["SMB", "NFS", "WEBDAV"])
    if not protocol:
        return
        
    # 2. 输入共享名(IP地址)
    share_name = show_input_dialog("输入共享名(IP地址)")
    if not share_name:
        return
        
    # 3. 根据协议处理用户名和密码
    username = ""
    password = ""
    
    if protocol in ["SMB", "WEBDAV"]:
        username = show_input_dialog("输入用户名(没有用户名请直接确定)")
        if username:  # 只有当用户名存在时才要求输入密码
            password = show_input_dialog("输入密码")
            if not password:  # 密码不能为空
                xbmcgui.Dialog().ok("错误", "密码不能为空！")
                return
    
    # 4. 构建URL
    if protocol == "SMB":
        if username and password:
            url = f"smb://{username}:{password}@{share_name}/"
        else:
            url = f"smb://{share_name}/"
            
    elif protocol == "NFS":
        url = f"nfs://{share_name}/"
        
    elif protocol == "WEBDAV":
        if username and password:
            url = f"WEBDAV://{username}:{password}@{share_name}/"
        else:
            url = f"WEBDAV://{share_name}/"
    
    # 5. 显示确认信息
    if not show_yesno_dialog("确认信息", f"您输入的信息如下：\n协议: {protocol}\nURL: {url}\n\n是否确认？"):
        return
        
    # 6. 设置KODI皮肤属性
    xbmc.executebuiltin(f'Skin.SetBool(lanUseCustompath)')
    xbmc.executebuiltin(f'Skin.SetString(lanCustompath,{url})')
    
    xbmcgui.Dialog().ok("成功", "以后点击“本地网络”将进入您设置的网络位置")
    
    # 7. 模拟手动操作：向上移动并按确定
    time.sleep(0.5)  # 等待对话框关闭
    xbmc.executebuiltin('Action(Up)')  # 向上移动
    time.sleep(0.5)
    xbmc.executebuiltin('Action(Select)')  # 按确定

if __name__ == "__main__":
    main()