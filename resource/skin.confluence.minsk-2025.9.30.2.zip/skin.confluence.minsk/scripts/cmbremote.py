import os
import xbmc
import xbmcgui
import xbmcvfs

def get_kodi_keymaps_path():
    """获取Kodi的keymaps文件夹路径"""
    try:
        keymaps_path = xbmcvfs.translatePath("special://userdata/keymaps/")
        if not xbmcvfs.exists(keymaps_path):
            xbmcvfs.mkdirs(keymaps_path)
            xbmc.log(f"创建keymaps目录: {keymaps_path}", xbmc.LOGINFO)
        return keymaps_path
    except Exception as e:
        raise Exception(f"获取Kodi keymaps路径失败: {str(e)}")

def get_cmbremote_source_path():
    """获取cmbremote文件夹路径"""
    try:
        src_dir = xbmcvfs.translatePath("special://home/addons/skin.confluence.minsk/extras/cmbremote")
        
        if not xbmcvfs.exists(src_dir) and not os.path.exists(src_dir):
            raise Exception(f"源目录不存在: {src_dir}")
            
        return src_dir
    except Exception as e:
        raise Exception(f"获取cmbremote路径失败: {str(e)}")

def copy_and_clean_files(source_dir):
    """复制gen.xml到keymaps，并删除指定文件"""
    try:
        keymaps_dir = get_kodi_keymaps_path()
        hwdb_dir = "/storage/.config/hwdb.d/"
        
        failed = []
        
        # 1. 复制 gen.xml 到 keymaps 目录
        gen_src = os.path.join(source_dir, "gen.xml")
        gen_dst = os.path.join(keymaps_dir, "gen.xml")
        try:
            if not xbmcvfs.copy(gen_src, gen_dst):
                failed.append(f"gen.xml (复制操作返回失败)")
        except Exception as e:
            failed.append(f"gen.xml (错误: {str(e)})")
        
        # 2. 删除 keymaps 目录下的 keyboard.xml
        keyboard_path = os.path.join(keymaps_dir, "keyboard.xml")
        try:
            if xbmcvfs.exists(keyboard_path) and not xbmcvfs.delete(keyboard_path):
                failed.append(f"删除 keyboard.xml 失败")
        except Exception as e:
            failed.append(f"删除 keyboard.xml 错误: {str(e)}")
        
        # 3. 删除 hwdb.d 目录下的 UgoosUR02.hwdb
        hwdb_file = os.path.join(hwdb_dir, "UgoosUR02.hwdb")
        try:
            if xbmcvfs.exists(hwdb_file) and not xbmcvfs.delete(hwdb_file):
                failed.append(f"删除 UgoosUR02.hwdb 失败")
        except Exception as e:
            failed.append(f"删除 UgoosUR02.hwdb 错误: {str(e)}")
        
        return failed
    except Exception as e:
        raise Exception(f"文件操作过程出错: {str(e)}")

def main():
    if not xbmcgui.Dialog().yesno(
        "确认操作", 
        "此设置将执行以下操作：\n"
        "将CoreELEC系统适配MX3和中国移动蓝牙遥控器按键设置\n"
        "是否继续？"
    ):
        xbmcgui.Dialog().ok("已取消", "操作已取消")
        return
    
    try:
        source_dir = get_cmbremote_source_path()
        failed = copy_and_clean_files(source_dir)
        
        if not failed:
            # 全部成功
            xbmcgui.Dialog().ok("完成", "操作已完成，请重启设备使配置生效")
        else:
            # 有错误
            xbmcgui.Dialog().ok("部分失败", "以下操作失败：\n" + "\n".join(failed))
        
    except Exception as e:
        xbmcgui.Dialog().ok("错误", str(e))
        xbmc.log(f"CMBRemote配置脚本错误: {str(e)}", xbmc.LOGERROR)

if __name__ == "__main__":
    main()
