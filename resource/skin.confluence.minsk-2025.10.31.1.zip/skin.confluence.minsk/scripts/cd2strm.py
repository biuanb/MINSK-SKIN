import os
import sys
import xbmc
import xbmcgui
import re
import xml.etree.ElementTree as ET
from xml.dom import minidom

# 固定STRM目录
TARGET_DIR = "/storage/videos/strm/"
# 源目录选择的默认路径
DEFAULT_SOURCE_PATH = "/storage/videos/CloudNAS/CloudDrive/"
# 源目录记录文件路径（XML格式）
SOURCE_RECORD_FILE = os.path.join(TARGET_DIR, "source_directories.xml")
# 需要识别并截断削的前缀文件夹
PREFIXES_TO_TRUNCATE = {'115', '115open'}
# 最大文件名长度限制（包含完整扩展名，调整为130字符）
MAX_FILENAME_LENGTH = 115  # 从150调整为130

# 确保STRM目录和源记录文件存在
def initialize():
    if not os.path.exists(TARGET_DIR):
        try:
            os.makedirs(TARGET_DIR)
            xbmc.log(f"[STRM同步工具] 已创建STRM根目录：{TARGET_DIR}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[STRM同步工具] 创建STRM根目录失败：{str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("初始化失败", f"无法创建STRM目录：{str(e)}")
            sys.exit(1)
    
    # 初始化XML文件（如果不存在）
    if not os.path.exists(SOURCE_RECORD_FILE):
        try:
            root = ET.Element("source_directories")
            rough_string = ET.tostring(root, 'utf-8')
            reparsed = minidom.parseString(rough_string)
            pretty_xml = reparsed.toprettyxml(indent="  ")
            
            with open(SOURCE_RECORD_FILE, 'w', encoding='utf-8') as f:
                f.write(pretty_xml)
            xbmc.log(f"[STRM同步工具] 已创建源目录XML记录文件：{SOURCE_RECORD_FILE}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[STRM同步工具] 创建源目录XML记录文件失败：{str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("初始化失败", f"无法创建源目录记录文件：{str(e)}")
            sys.exit(1)

# 从XML记录文件读取源目录列表（自动去重）
def load_source_directories():
    if not os.path.exists(SOURCE_RECORD_FILE):
        return []
    try:
        tree = ET.parse(SOURCE_RECORD_FILE)
        root = tree.getroot()
        
        sources = []
        for dir_elem in root.findall('directory'):
            path = dir_elem.text.strip() if dir_elem.text else ""
            if path and os.path.exists(path) and os.path.isdir(path) and path not in sources:
                sources.append(path)
        return sources
    except Exception as e:
        xbmc.log(f"[STRM同步工具] 读取源目录XML记录失败：{str(e)}", xbmc.LOGERROR)
        return []

# 向XML记录文件添加源目录（自动去重）
def add_source_directory(new_dir):
    sources = load_source_directories()
    if new_dir in sources:
        return True, "目录已存在，将直接同步"
    
    if not os.path.exists(new_dir) or not os.path.isdir(new_dir):
        return False, "目录不存在或不是有效目录"
    
    try:
        tree = ET.parse(SOURCE_RECORD_FILE)
        root = tree.getroot()
        
        dir_elem = ET.SubElement(root, "directory")
        dir_elem.text = new_dir
        dir_elem.tail = "\n  "
        
        rough_string = ET.tostring(root, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ")
        lines = [line for line in pretty_xml.split('\n') if line.strip() != '']
        pretty_xml = '\n'.join(lines)
        
        with open(SOURCE_RECORD_FILE, 'w', encoding='utf-8') as f:
            f.write(pretty_xml)
        
        return True, "添加成功，开始同步"
    except Exception as e:
        return False, f"添加失败：{str(e)}"

# 需要处理的视频文件扩展名
def get_video_extensions():
    return {'.mkv', '.mp4', '.ts', '.m2ts', '.iso'}

def extract_without_brackets(filename):
    """移除[]和【】符号，保留内部内容"""
    cleaned = re.sub(r'【|】|\[|\]', ' ', filename)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned if cleaned else "未命名文件"

def clean_and_truncate(filename, max_length):
    """
    修复版文件名处理：
    1. 确保只保留一个原始扩展名
    2. 强制添加.strm后缀，且不受截断影响
    3. 总长度严格控制在max_length内
    """
    # 第一步：清理文件名主体（不含扩展名）
    base_name = os.path.splitext(filename)[0]  # 分离主体和扩展名
    core_content = extract_without_brackets(base_name)
    safe_content = re.sub(r'[^\w\s\u4e00-\u9fa5\.\-]', '', core_content)
    safe_content = re.sub(r'\s+', ' ', safe_content).strip()
    if not safe_content:
        safe_content = "未命名文件"
    
    # 第二步：提取并保留唯一的原始扩展名
    original_ext = os.path.splitext(filename)[1].lower()  # 只取最后一个扩展名
    valid_exts = get_video_extensions()
    ext_part = original_ext if original_ext in valid_exts else ""  # 只保留有效的扩展名
    
    # 第三步：定义STRM固定后缀（必须保留）
    strm_ext = ".strm"
    
    # 第四步：计算允许的主体长度（总长度 - 原始扩展名长度 - STRM后缀长度）
    available_length = max_length - len(ext_part) - len(strm_ext)
    available_length = max(available_length, 1)  # 至少保留1个字符作为主体
    
    # 第五步：截断主体部分
    truncated_body = safe_content[:available_length] if len(safe_content) > available_length else safe_content
    
    # 第六步：组合最终文件名
    final_name = f"{truncated_body}{ext_part}{strm_ext}"
    
    # 最终检查：确保不超过长度限制
    if len(final_name) > max_length:
        final_name = final_name[:max_length - len(strm_ext)] + strm_ext
    
    # 避免文件名以点开头
    if final_name.startswith('.'):
        final_name = f"视频{final_name}"
        if len(final_name) > max_length:
            final_name = final_name[:max_length - len(strm_ext)] + strm_ext
    
    return final_name

def process_source_directory(source_dir, progress):
    """处理源目录，返回统计数据：(新增数, 更新数, 错误列表, 源文件键集合)"""
    xbmc.log(f"[STRM同步工具] 开始处理源目录：{source_dir}", xbmc.LOGINFO)
    if not os.path.exists(source_dir) or not os.path.isdir(source_dir):
        xbmc.log(f"[STRM同步工具] 错误：源目录无效 -> {source_dir}", xbmc.LOGERROR)
        return (0, 0, [f"源目录无效：{source_dir}"], set())
    
    video_extensions = get_video_extensions()
    new_count = 0        # 新增的STRM文件
    updated_count = 0    # 更新的STRM文件
    error_list = []
    source_keys = set()
    existing_strm = collect_existing_strm(include_mtime=True)
    
    try:
        for root, dirs, files in os.walk(source_dir):
            # 处理BDMV文件夹
            has_bdmv = any(dir_name.lower() == 'bdmv' for dir_name in dirs)
            if has_bdmv:
                rel_path = os.path.relpath(root, source_dir)
                item_key = f"bdmv_{rel_path}_{source_dir}"
                source_keys.add(item_key)
                
                folder_name = os.path.basename(root)
                folder_mtime = os.path.getmtime(root)
                is_new = item_key not in existing_strm
                
                # 检查是否需要更新
                if not is_new:
                    strm_path, strm_mtime = existing_strm[item_key]
                    if folder_mtime <= strm_mtime:
                        xbmc.log(f"[STRM同步工具] 跳过：BDMV文件夹{folder_name}未更新", xbmc.LOGINFO)
                        continue
                
                progress.update(0, f"处理BDMV：{folder_name}")
                success, result = create_strm_file("bdmv", root, folder_name, source_dir)
                if success:
                    if is_new:
                        new_count += 1
                    else:
                        updated_count += 1
                    xbmc.log(f"[STRM同步工具] BDMV STRM{'新增' if is_new else '更新'}成功：{result}", xbmc.LOGINFO)
                else:
                    error_list.append(f"BDMV {folder_name}：{result}")
                    xbmc.log(f"[STRM同步工具] BDMV STRM生成失败：{result}", xbmc.LOGERROR)
                
                dirs[:] = []
                continue
            
            # 处理视频文件
            for file in files:
                file_ext = os.path.splitext(file)[1].lower()
                if file_ext in video_extensions:
                    xbmc.log(f"[STRM同步工具] 发现视频文件：{file}（扩展名{file_ext}）", xbmc.LOGINFO)
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, source_dir)
                    item_key = f"video_{rel_path}_{source_dir}"
                    source_keys.add(item_key)
                    
                    try:
                        file_mtime = os.path.getmtime(file_path)
                        is_new = item_key not in existing_strm
                        
                        # 检查是否需要更新
                        if not is_new:
                            strm_path, strm_mtime = existing_strm[item_key]
                            if file_mtime <= strm_mtime:
                                xbmc.log(f"[STRM同步工具] 跳过：视频{file}未更新", xbmc.LOGINFO)
                                continue
                        
                        progress.update(0, f"处理文件：{file}")
                        success, result = create_strm_file("video", file_path, file, source_dir)
                        if success:
                            if is_new:
                                new_count += 1
                            else:
                                updated_count += 1
                            xbmc.log(f"[STRM同步工具] 视频STRM{'新增' if is_new else '更新'}成功：{result}", xbmc.LOGINFO)
                        else:
                            error_list.append(f"视频 {file}：{result}")
                            xbmc.log(f"[STRM同步工具] 视频STRM生成失败：{result}", xbmc.LOGERROR)
                    except Exception as e:
                        error_list.append(f"获取{file}修改时间失败：{str(e)}")
                        continue
            
            if progress.iscanceled():
                error_list.append("操作已取消")
                return (new_count, updated_count, error_list, source_keys)
        
        xbmc.log(f"[STRM同步工具] 源目录处理完成：{source_dir}，新增{new_count}个，更新{updated_count}个STRM", xbmc.LOGINFO)
    
    except Exception as e:
        error_msg = f"扫描目录出错：{str(e)}"
        error_list.append(error_msg)
        xbmc.log(f"[STRM同步工具] 扫描目录异常：{error_msg}", xbmc.LOGERROR)
    
    return (new_count, updated_count, error_list, source_keys)

def collect_existing_strm(include_mtime=False):
    existing_strm = {}
    if not os.path.exists(TARGET_DIR):
        return existing_strm
    
    for root, _, files in os.walk(TARGET_DIR):
        for file in files:
            if file.lower().endswith('.strm'):
                strm_path = os.path.join(root, file)
                try:
                    with open(strm_path, 'r', encoding='utf-8') as f:
                        source_path = f.readline().strip()
                    
                    source_dirs = load_source_directories()
                    base_source = None
                    for src_dir in source_dirs:
                        if source_path.startswith(src_dir):
                            base_source = src_dir
                            break
                    if not base_source:
                        continue
                    
                    if 'BDMV/index.bdmv' in source_path:
                        bdmv_folder = os.path.dirname(os.path.dirname(source_path))
                        rel_path = os.path.relpath(bdmv_folder, base_source)
                        item_key = f"bdmv_{rel_path}_{base_source}"
                    else:
                        rel_path = os.path.relpath(source_path, base_source)
                        item_key = f"video_{rel_path}_{base_source}"
                    
                    if include_mtime:
                        strm_mtime = os.path.getmtime(strm_path)
                        existing_strm[item_key] = (strm_path, strm_mtime)
                    else:
                        existing_strm[item_key] = strm_path
                
                except Exception as e:
                    xbmc.log(f"[STRM同步工具] 处理STRM文件失败：{str(e)}", xbmc.LOGERROR)
    
    return existing_strm

def create_strm_file(item_type, source_path, name, source_dir):
    try:
        if item_type == "bdmv":
            strm_content = os.path.join(source_path, "BDMV", "index.bdmv")
            original_filename = name
        else:
            strm_content = source_path
            original_filename = name
        
        # 生成修正后的文件名
        strm_filename = clean_and_truncate(original_filename, MAX_FILENAME_LENGTH)
        xbmc.log(f"[STRM同步工具] 处理后文件名：{strm_filename}（长度：{len(strm_filename)}）", xbmc.LOGINFO)
        
        # 构建目标目录路径
        full_source_dir = os.path.dirname(source_path) if item_type == "video" else source_path
        path_parts = [part for part in full_source_dir.split(os.sep) if part]
        target_parts = []
        found_truncate_prefix = False
        
        for part in path_parts:
            if not found_truncate_prefix and part.lower() in PREFIXES_TO_TRUNCATE:
                found_truncate_prefix = True
                continue
            if found_truncate_prefix:
                cleaned_part = extract_without_brackets(part)
                cleaned_part = re.sub(r'[^\w\s\u4e00-\u9fa5\.\-]', '', cleaned_part)
                cleaned_part = re.sub(r'\s+', ' ', cleaned_part).strip()
                if cleaned_part:
                    target_parts.append(cleaned_part)
        
        if not found_truncate_prefix:
            source_dir_parts = [extract_without_brackets(part) for part in source_dir.split(os.sep) if part]
            source_dir_parts = [re.sub(r'[^\w\s\u4e00-\u9fa5\.\-]', '', p).strip() for p in source_dir_parts if p.strip()]
            if len(path_parts) >= len(source_dir_parts) and path_parts[:len(source_dir_parts)] == source_dir_parts:
                target_parts = path_parts[len(source_dir_parts):]
            else:
                target_parts = path_parts
        
        final_target_dir = TARGET_DIR
        if target_parts:
            target_subdir = os.sep.join(target_parts)
            final_target_dir = os.path.join(TARGET_DIR, target_subdir)
        
        if not os.path.exists(final_target_dir):
            os.makedirs(final_target_dir, exist_ok=True)
        
        # 拼接最终路径并检查总长度
        strm_path = os.path.join(final_target_dir, strm_filename)
        
        # 路径总长度超过系统限制（255字符）的极端处理
        if len(strm_path) > 255:
            xbmc.log(f"[STRM同步工具] 路径过长（{len(strm_path)}），强制放在根目录", xbmc.LOGWARNING)
            strm_path = os.path.join(TARGET_DIR, strm_filename)
        
        # 写入文件
        with open(strm_path, 'w', encoding='utf-8') as f:
            f.write(strm_content)
        
        if os.path.getsize(strm_path) == 0:
            raise Exception("STRM文件为空")
        
        return True, strm_path
    except Exception as e:
        return False, f"{str(e)}"

def delete_empty_dirs(root_dir):
    if not os.path.isdir(root_dir):
        return
    for dir_name in os.listdir(root_dir):
        dir_path = os.path.join(root_dir, dir_name)
        if os.path.isdir(dir_path):
            delete_empty_dirs(dir_path)
            if not os.listdir(dir_path):
                try:
                    os.rmdir(dir_path)
                    xbmc.log(f"[STRM同步工具] 删除空目录：{dir_path}", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[STRM同步工具] 删除空目录失败：{str(e)}", xbmc.LOGERROR)

# 同步指定的源目录（包含增量更新和减量清理）
def sync_selected_source(selected_dirs):
    total_new = 0
    total_updated = 0
    total_deleted = 0
    total_errors = []
    all_source_keys = set()
    progress = xbmcgui.DialogProgress()
    progress.create("同步目录", "准备同步...")
    
    try:
        for i, src_dir in enumerate(selected_dirs):
            src_name = get_display_name(src_dir)
            progress.update(int(i/len(selected_dirs)*100), f"处理目录：{src_name}")
            
            # 处理当前目录，获取新增和更新的数量
            new_count, updated_count, errors, source_keys = process_source_directory(src_dir, progress)
            total_new += new_count
            total_updated += updated_count
            total_errors.extend(errors)
            all_source_keys.update(source_keys)
            
            if progress.iscanceled():
                break
        
        if progress.iscanceled():
            xbmcgui.Dialog().ok("同步取消", "同步已终止")
            return
    
    finally:
        progress.close()
    
    # 清理选中目录相关的过时文件（减量处理）
    existing_strm = collect_existing_strm()
    obsolete_keys = []
    for k in existing_strm:
        # 检查这个STRM文件是否属于当前正在同步的源目录
        if any(src_dir in k for src_dir in selected_dirs) and k not in all_source_keys:
            obsolete_keys.append(k)
    
    if obsolete_keys:
        confirm = xbmcgui.Dialog().yesno(
            "发现过时文件",
            f"共 {len(obsolete_keys)} 个STRM文件对应源已删除\n是否删除？"
        )
        if confirm:
            progress = xbmcgui.DialogProgress()
            progress.create("删除过时文件", "正在处理...")
            
            for i, key in enumerate(obsolete_keys):
                strm_path = existing_strm[key]
                try:
                    if os.path.exists(strm_path):
                        os.remove(strm_path)
                        total_deleted += 1
                except Exception as e:
                    total_errors.append(f"删除{os.path.basename(strm_path)}失败：{str(e)}")
                
                progress.update(int((i+1)/len(obsolete_keys)*100), f"删除：{os.path.basename(strm_path)}")
                if progress.iscanceled():
                    break
            
            progress.close()
            delete_empty_dirs(TARGET_DIR)
    
    # 构建结果信息
    result_msg = [
        f"同步目录数量：{len(selected_dirs)}",
        f"新增STRM文件：{total_new} 个",
        f"更新STRM文件：{total_updated} 个",
        f"删除过时文件：{total_deleted} 个"
    ]
    
    if total_errors:
        result_msg.append(f"\n错误 ({len(total_errors)})：")
        for err in total_errors[:5]:
            result_msg.append(f"- {err}")
        if len(total_errors) > 5:
            result_msg.append(f"- 还有 {len(total_errors)-5} 个错误")
    
    xbmcgui.Dialog().ok("同步完成", "\n".join(result_msg))

# 获取源目录的显示名称（移除115或115open之前的路径）
def get_display_name(source_dir):
    path_parts = [part for part in source_dir.split(os.sep) if part]
    display_parts = []
    found_truncate_prefix = False
    
    for part in path_parts:
        if not found_truncate_prefix and part.lower() in PREFIXES_TO_TRUNCATE:
            found_truncate_prefix = True
            display_parts.append(part)  # 保留115或115open本身
            continue
        if found_truncate_prefix:
            display_parts.append(part)
    
    # 如果没有找到前缀，则显示完整路径的最后两个部分
    if not found_truncate_prefix:
        display_parts = path_parts[-2:] if len(path_parts) >= 2 else path_parts
    
    return os.sep.join(display_parts)

def add_source_and_sync():
    default_path = DEFAULT_SOURCE_PATH
    if not os.path.exists(default_path) or not os.path.isdir(default_path):
        default_path = "/storage"
        xbmc.log(f"[STRM同步工具] 默认源路径不存在，使用 fallback：{default_path}", xbmc.LOGWARNING)
    
    new_source = select_directory("选择视频源目录", default_path)
    if not new_source:
        xbmcgui.Dialog().ok("操作取消", "未选择源目录")
        return
    
    success, msg = add_source_directory(new_source)
    if not success:
        xbmcgui.Dialog().ok("操作失败", msg)
        return
    
    progress = xbmcgui.DialogProgress()
    progress.create("同步目录", f"处理：{get_display_name(new_source)}\n{msg}")
    
    try:
        new_count, updated_count, error_list, all_source_keys = process_source_directory(new_source, progress)
        
        existing_strm = collect_existing_strm()
        obsolete_keys = [k for k in existing_strm if new_source in k and k not in all_source_keys]
        delete_count = 0
        
        if obsolete_keys and not progress.iscanceled():
            for key in obsolete_keys:
                strm_path = existing_strm[key]
                try:
                    if os.path.exists(strm_path):
                        os.remove(strm_path)
                        delete_count += 1
                except Exception as e:
                    error_list.append(f"删除{os.path.basename(strm_path)}失败：{str(e)}")
            
            delete_empty_dirs(TARGET_DIR)
    
    finally:
        progress.close()
    
    result_msg = [
        f"源目录：{get_display_name(new_source)}",
        f"{msg}",
        f"新增STRM文件：{new_count} 个",
        f"更新STRM文件：{updated_count} 个",
        f"删除过时文件：{delete_count} 个"
    ]
    
    if error_list:
        result_msg.append(f"\n错误 ({len(error_list)})：")
        for err in error_list[:5]:
            result_msg.append(f"- {err}")
        if len(error_list) > 5:
            result_msg.append(f"- 还有 {len(error_list)-5} 个错误")
    
    xbmcgui.Dialog().ok("同步完成", "\n".join(result_msg))
    open_strm_in_kodi()

def delete_all_strm():
    if not os.path.exists(TARGET_DIR):
        xbmcgui.Dialog().ok("提示", "STRM目录不存在")
        return
    
    confirm = xbmcgui.Dialog().yesno(
        "警告",
        f"确定删除 {TARGET_DIR} 下所有内容？\n包括所有STRM文件、子目录和源目录记录！"
    )
    if not confirm:
        return
    
    total_files = 0
    for root, _, files in os.walk(TARGET_DIR):
        total_files += len(files)
    
    progress = xbmcgui.DialogProgress()
    progress.create("删除所有内容", "正在处理...")
    file_count = 0
    
    try:
        for root, _, files in os.walk(TARGET_DIR):
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    os.remove(file_path)
                    file_count += 1
                    progress.update(int(file_count/total_files*100), f"删除：{file}")
                except Exception as e:
                    xbmc.log(f"[STRM同步工具] 删除{file}失败：{str(e)}", xbmc.LOGERROR)
                
                if progress.iscanceled():
                    progress.close()
                    xbmcgui.Dialog().ok("操作取消", "部分文件已删除")
                    return
        
        delete_empty_dirs(TARGET_DIR)
        progress.close()
        xbmcgui.Dialog().ok("删除完成", f"共删除 {file_count} 个文件和所有空目录\n源目录记录已清空")
    
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok("删除失败", f"错误：{str(e)}")

def show_manual_sync_menu():
    options = [
        "添加源目录生成strm文件",
        "选择同步源目录",
        "删除所有strm文件及记录"
    ]
    return xbmcgui.Dialog().select("手动同步模式选择", options)

def show_source_selection_menu():
    source_dirs = load_source_directories()
    if not source_dirs:
        xbmcgui.Dialog().ok("同步失败", "未找到源目录，请先添加源目录")
        return None
    
    # 构建选项列表，第一项为"所有文件夹"，其余为源目录（显示处理后的名称）
    options = ["所有文件夹"]
    options.extend([get_display_name(dir) for dir in source_dirs])
    
    selected = xbmcgui.Dialog().select("选择要同步的目录", options)
    if selected == -1:  # 取消选择
        return None
    
    if selected == 0:  # 所有文件夹
        return source_dirs
    else:  # 单个源目录
        return [source_dirs[selected - 1]]

def select_directory(title, default_path):
    return xbmcgui.Dialog().browse(
        type=3,
        heading=title,
        shares="local",
        defaultt=default_path,
        useThumbs=False,
        treatAsFolder=True,
        mask=""
    )

def open_strm_in_kodi():
    if os.path.exists(TARGET_DIR) and os.path.isdir(TARGET_DIR):
        xbmc.executebuiltin(f'ActivateWindow(Videos, "{TARGET_DIR}", return)')
    else:
        xbmcgui.Dialog().ok("打开失败", "STRM目录不存在")

def auto_mode():
    source_dirs = load_source_directories()
    strm_exists = os.path.exists(TARGET_DIR) and os.path.isdir(TARGET_DIR)
    strm_empty = True
    
    if strm_exists:
        for _, _, files in os.walk(TARGET_DIR):
            if any(f.lower().endswith('.strm') for f in files):
                strm_empty = False
                break
    
    if not source_dirs or (strm_exists and strm_empty):
        confirm = xbmcgui.Dialog().yesno(
            "未找到有效数据",
            "是否添加源目录并生成STRM文件？"
        )
        if confirm:
            add_source_and_sync()
    else:
        open_strm_in_kodi()

def main():
    initialize()
    args = sys.argv[1:] if len(sys.argv) > 1 else []
    
    if "manualsync" in args:
        selected = show_manual_sync_menu()
        if selected == 0:
            add_source_and_sync()
        elif selected == 1:
            # 显示源目录选择菜单
            selected_dirs = show_source_selection_menu()
            if selected_dirs is not None and len(selected_dirs) > 0:
                sync_selected_source(selected_dirs)
                open_strm_in_kodi()
        elif selected == 2:
            delete_all_strm()
    else:
        auto_mode()

if __name__ == '__main__':
    main()