import os
import shutil
import subprocess
import xbmc
import xbmcgui

FLASH_DIR = "/flash"
RESOURCE_DIR = "/storage/.resource"
GUI_SETTINGS_CE = os.path.join(RESOURCE_DIR, "guisettingsce.xml")
GUI_SETTINGS_CPM = os.path.join(RESOURCE_DIR, "guisettingscpm.xml")
GUI_SETTINGS_CURRENT = "/storage/.kodi/userdata/guisettings.xml"
AUTOSTART_SCRIPT = "/storage/.config/autostart.sh"
BIND_LINE = "mount --bind /storage/.resource/settings.xml /usr/share/kodi/system/settings/settings.xml"
SETTINGS_XML = os.path.join(RESOURCE_DIR, "settings.xml")

# 两个标记文件
MARKER_CE = "/storage/.config/switch_to_ce"
MARKER_CPM = "/storage/.config/switch_to_cpm"

def get_build_date():
    """获取皮肤字符串 BuildDate 的值"""
    return xbmc.getInfoLabel("Skin.String(BuildDate)") or ""

def set_flash_writable():
    """将 /flash 挂载为可读写"""
    try:
        result = subprocess.run(
            ["mount", "-o", "remount,rw", FLASH_DIR],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            raise Exception(f"挂载 /flash 为可写失败: {result.stderr}")
        return True
    except Exception as e:
        xbmcgui.Dialog().ok("错误", f"无法挂载 /flash 为可写:\n{str(e)}")
        return False

def file_exists(filename):
    """检查文件是否存在"""
    return os.path.exists(os.path.join(FLASH_DIR, filename))

def rename_file(old_name, new_name):
    """重命名文件"""
    old_path = os.path.join(FLASH_DIR, old_name)
    new_path = os.path.join(FLASH_DIR, new_name)
    if os.path.exists(old_path):
        os.rename(old_path, new_path)
        return True
    return False

def ensure_resource_dir():
    """确保资源目录存在"""
    os.makedirs(RESOURCE_DIR, exist_ok=True)

def copy_gui_settings(src, dst):
    """复制 GUI 设置文件"""
    try:
        shutil.copy2(src, dst)
        return True
    except Exception as e:
        xbmc.log(f"复制 GUI 设置文件失败: {str(e)}", xbmc.LOGERROR)
        return False

def reboot_system():
    """先同步数据再强制重启（加快重启速度）"""
    xbmc.log("同步数据并强制重启", xbmc.LOGINFO)
    subprocess.run(["sync"])  # 确保数据写入磁盘
    subprocess.run(["reboot", "-f"])  # 强制重启，不等待服务退出

def clean_bind_settings():
    """清理 autostart.sh 中的 bind 挂载命令和对应文件"""
    if os.path.exists(AUTOSTART_SCRIPT):
        try:
            with open(AUTOSTART_SCRIPT, "r", encoding="utf-8") as f:
                lines = f.readlines()

            new_lines = [line for line in lines if BIND_LINE not in line]

            if len(new_lines) != len(lines):
                with open(AUTOSTART_SCRIPT, "w", encoding="utf-8") as f:
                    f.writelines(new_lines)
                xbmc.log("已从 autostart.sh 中删除 mount --bind 命令", xbmc.LOGINFO)

                if os.path.exists(SETTINGS_XML):
                    os.remove(SETTINGS_XML)
                    xbmc.log("已删除 /storage/.resource/settings.xml", xbmc.LOGINFO)
            else:
                xbmc.log("autostart.sh 中未发现需要删除的 mount --bind 命令", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"清理 autostart.sh 失败: {str(e)}", xbmc.LOGERROR)

def setup_autostart_switch_logic():
    """确保 autostart.sh 中有分支切换逻辑"""
    if not os.path.exists(AUTOSTART_SCRIPT):
        with open(AUTOSTART_SCRIPT, "w", encoding="utf-8") as f:
            f.write("#!/bin/sh\n")
        os.chmod(AUTOSTART_SCRIPT, 0o755)

    # 分支切换逻辑
    switch_code = """
# GUI 分支切换逻辑
if [ -f "/storage/.config/switch_to_ce" ]; then
    cp "/storage/.resource/guisettingsce.xml" "/storage/.kodi/userdata/guisettings.xml"
    rm "/storage/.config/switch_to_ce"
elif [ -f "/storage/.config/switch_to_cpm" ]; then
    cp "/storage/.resource/guisettingscpm.xml" "/storage/.kodi/userdata/guisettings.xml"
    rm "/storage/.config/switch_to_cpm"
fi
"""

    with open(AUTOSTART_SCRIPT, "r", encoding="utf-8") as f:
        content = f.read()

    if "# GUI 分支切换逻辑" not in content:
        with open(AUTOSTART_SCRIPT, "a", encoding="utf-8") as f:
            f.write(switch_code)

def set_switch_marker(marker_file):
    """创建指定的切换标记文件"""
    # 删除可能存在的其他标记
    for m in [MARKER_CE, MARKER_CPM]:
        if os.path.exists(m):
            os.remove(m)
    # 创建当前标记
    with open(marker_file, "w", encoding="utf-8") as f:
        f.write("1")

def main():
    has_ce = file_exists("KERNELce.img")
    has_cpm = file_exists("KERNELcpm.img")

    if has_ce and has_cpm:
        xbmcgui.Dialog().ok("错误", "系统文件错误，无法完成转换")
        return

    if not has_ce and not has_cpm:
        xbmcgui.Dialog().ok("提示", "系统文件缺失，无法完成转换")
        return

    if not set_flash_writable():
        return

    ensure_resource_dir()
    setup_autostart_switch_logic()

    # 获取 BuildDate 字符串并判断确认对话框内容
    build_date = get_build_date().lower()
    dialog_title = "确认切换"
    dialog_message = ""

    if "cpm" in build_date:
        dialog_message = "将从 CPM 分支切换为原版，是否继续？"
    elif "ce" in build_date:
        dialog_message = "将从原版切换为 CPM 分支，是否继续？"
    else:
        dialog_message = "将切换CoreELEC的内核，是否继续？"

    # 显示确认对话框
    if not xbmcgui.Dialog().yesno(dialog_title, dialog_message):
        xbmcgui.Dialog().ok("已取消", "操作已取消")
        return

    # 再次获取 BuildDate 用于切换完成提示（确保最新状态）
    build_date = get_build_date().lower()
    success_title = "完成"
    success_message = ""

    if has_ce:
        # 从 CPM 切换到原版
        rename_file("KERNEL.img", "KERNELcpm.img")
        rename_file("KERNEL.img.md5", "KERNELcpm.img.md5")
        rename_file("KERNELce.img", "KERNEL.img")
        rename_file("KERNELce.img.md5", "KERNEL.img.md5")

        rename_file("SYSTEM", "SYSTEMcpm")
        rename_file("SYSTEM.md5", "SYSTEMcpm.md5")
        rename_file("SYSTEMce", "SYSTEM")
        rename_file("SYSTEMce.md5", "SYSTEM.md5")

        clean_bind_settings()
        copy_gui_settings(GUI_SETTINGS_CURRENT, GUI_SETTINGS_CPM)
        set_switch_marker(MARKER_CE)

        # 设置完成提示消息
        if "cpm" in build_date:
            success_message = "已切换到原版(夜版)，系统将立即重启"
        elif "ce" in build_date:
            success_message = "已切换到CPM分支，系统将立即重启"
        else:
            success_message = "已完成切换CoreELEC内核，系统将立即重启"

    elif has_cpm:
        # 从原版切换到 CPM
        rename_file("KERNEL.img", "KERNELce.img")
        rename_file("KERNEL.img.md5", "KERNELce.img.md5")
        rename_file("KERNELcpm.img", "KERNEL.img")
        rename_file("KERNELcpm.img.md5", "KERNEL.img.md5")

        rename_file("SYSTEM", "SYSTEMce")
        rename_file("SYSTEM.md5", "SYSTEMce.md5")
        rename_file("SYSTEMcpm", "SYSTEM")
        rename_file("SYSTEMcpm.md5", "SYSTEM.md5")

        clean_bind_settings()
        copy_gui_settings(GUI_SETTINGS_CURRENT, GUI_SETTINGS_CE)
        set_switch_marker(MARKER_CPM)

        # 设置完成提示消息
        if "cpm" in build_date:
            success_message = "已切换到原版(夜版)，系统将立即重启"
        elif "ce" in build_date:
            success_message = "已切换到CPM分支，系统将立即重启"
        else:
            success_message = "已完成切换CoreELEC内核，系统将立即重启"

    # 显示完成提示并重启
    xbmcgui.Dialog().ok(success_title, success_message)
    reboot_system()

if __name__ == "__main__":
    main()