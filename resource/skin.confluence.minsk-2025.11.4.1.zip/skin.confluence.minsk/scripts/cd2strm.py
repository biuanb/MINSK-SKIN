import os
import sys
import xbmc
import xbmcgui
import re
import xml.etree.ElementTree as ET
from xml.dom import minidom
import threading
import time

# 固定STRM目录
TARGET_DIR = "/storage/videos/strm/"
# 源目录选择的默认路径
DEFAULT_source_path = "/storage/videos/CloudNAS/CloudDrive/"
# 源目录记录
SOURCE_RECORD_FILE = os.path.join(TARGET_DIR, "source_directories.xml")
# 需要识别并截断的前缀文件夹（按优先级排序，不区分大小写）
PRIORITY_PREFIXES = ['clouddrive', 'cloudnas']  # 优先clouddrive，其次cloudnas
# 最大文件名长度限制（包含完整扩展名）
MAX_FILENAME_LENGTH = 100
# 最大文件夹名称长度限制
MAX_FOLDERR_NAME_LENGTH = 90
# 判定文件名相似的前缀长度（前N个字符相同）
SIMILAR_PREFIX_LENGTH = 10
# 监控模式下的检查间隔（秒）
MONITOR_CHECK_INTERVAL = 240  # 5分钟
# 全屏播放时的检查间隔（秒，更短以便快速恢复）
FULLSCREEN_CHECK_INTERVAL = 120  # 30秒

# 全局变量用于控制监控线程
monitor_running = False

# 确保STRM目录和源记录文件存在
def initialize():
    if not os.path.exists(TARGET_DIR):
        try:
            os.makedirs(TARGET_DIR)
            xbmc.log(f"[STRM同步工具] 已创建STRM根目录：{TARGET_DIR}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[STRM同步工具] 创建STRM根目录失败：{str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("初始化失败", f"无法创建STRM目录：{str(e)}")
            sys.exit(1)
    
    # 初始化XML文件（如果不存在）
    if not os.path.exists(SOURCE_RECORD_FILE):
        try:
            root = ET.Element("source_directories")
            rough_string = ET.tostring(root, 'utf-8')
            reparsed = minidom.parseString(rough_string)
            pretty_xml = reparsed.toprettyxml(indent="  ")
            
            with open(SOURCE_RECORD_FILE, 'w', encoding='utf-8') as f:
                f.write(pretty_xml)
            xbmc.log(f"[STRM同步工具] 已创建源目录XML记录文件：{SOURCE_RECORD_FILE}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[STRM同步工具] 创建源目录XML记录文件失败：{str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("初始化失败", f"无法创建源目录记录文件：{str(e)}")
            sys.exit(1)

# 从XML记录文件读取源目录列表（自动去重）
def load_source_directories():
    if not os.path.exists(SOURCE_RECORD_FILE):
        return []
    try:
        tree = ET.parse(SOURCE_RECORD_FILE)
        root = tree.getroot()
        
        sources = []
        for dir_elem in root.findall('directory'):
            path = dir_elem.text.strip() if dir_elem.text else ""
            if path and os.path.exists(path) and os.path.isdir(path) and path not in sources:
                sources.append(path)
        return sources
    except Exception as e:
        xbmc.log(f"[STRM同步工具] 读取源目录XML记录失败：{str(e)}", xbmc.LOGERROR)
        return []

# 向XML记录文件添加源目录（自动去重）
def add_source_directory(new_dir):
    sources = load_source_directories()
    if new_dir in sources:
        return True, "目录已存在"
    
    if not os.path.exists(new_dir) or not os.path.isdir(new_dir):
        return False, "目录不存在或不是有效目录"
    
    try:
        tree = ET.parse(SOURCE_RECORD_FILE)
        root = tree.getroot()
        
        dir_elem = ET.SubElement(root, "directory")
        dir_elem.text = new_dir
        dir_elem.tail = "\n  "
        
        rough_string = ET.tostring(root, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ")
        lines = [line for line in pretty_xml.split('\n') if line.strip() != '']
        pretty_xml = '\n'.join(lines)
        
        with open(SOURCE_RECORD_FILE, 'w', encoding='utf-8') as f:
            f.write(pretty_xml)
        
        return True, "添加成功"
    except Exception as e:
        return False, f"添加失败：{str(e)}"

# 需要处理的视频文件扩展名
def get_video_extensions():
    return {'.mkv', '.mp4', '.ts', '.m2ts', '.iso'}

def extract_without_brackets(filename):
    """移除[]和【】符号，保留内部内容"""
    cleaned = re.sub(r'【|】|\[|\]', ' ', filename)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned if cleaned else "未命名文件"

def clean_folder_name(folder_name):
    """清理文件夹名称并确保不超过最大长度限制，超过则从后端截断"""
    cleaned = extract_without_brackets(folder_name)
    cleaned = re.sub(r'[^\w\s\u4e00-\u9fa5\.\-]', '', cleaned)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    
    if not cleaned:
        cleaned = "未命名文件夹"
    
    if len(cleaned) > MAX_FOLDERR_NAME_LENGTH:
        cleaned = cleaned[:MAX_FOLDERR_NAME_LENGTH].strip()
        while cleaned.endswith('.'):
            cleaned = cleaned[:-1].strip()
        if not cleaned:
            cleaned = "未命名文件夹"
    
    return cleaned

def clean_and_truncate(filename, max_length):
    """处理文件名，确保正确添加.strm后缀并控制长度"""
    base_name = os.path.splitext(filename)[0]
    core_content = extract_without_brackets(base_name)
    safe_content = re.sub(r'[^\w\s\u4e00-\u9fa5\.\-]', '', core_content)
    safe_content = re.sub(r'\s+', ' ', safe_content).strip()
    if not safe_content:
        safe_content = "未命名文件"
    
    original_ext = os.path.splitext(filename)[1].lower()
    valid_exts = get_video_extensions()
    ext_part = original_ext if original_ext in valid_exts else ""
    
    strm_ext = ".strm"
    available_length = max_length - len(ext_part) - len(strm_ext)
    available_length = max(available_length, 1)
    
    truncated_body = safe_content[:available_length] if len(safe_content) > available_length else safe_content
    final_name = f"{truncated_body}{ext_part}{strm_ext}"
    
    if len(final_name) > max_length:
        final_name = final_name[:max_length - len(strm_ext)] + strm_ext
    
    if final_name.startswith('.'):
        final_name = f"视频{final_name}"
        if len(final_name) > max_length:
            final_name = final_name[:max_length - len(strm_ext)] + strm_ext
    
    return final_name

def find_similar_strm_files(target_dir, target_filename):
    """查找同目录下前缀相似的STRM文件"""
    if not os.path.exists(target_dir) or not os.path.isdir(target_dir):
        return []
    
    similar_files = []
    # 获取目标文件的前缀（去除扩展名）
    target_base = os.path.splitext(target_filename)[0]
    target_prefix = target_base[:SIMILAR_PREFIX_LENGTH].lower()
    
    for filename in os.listdir(target_dir):
        if filename.lower().endswith('.strm') and filename != target_filename:
            file_base = os.path.splitext(filename)[0]
            file_prefix = file_base[:SIMILAR_PREFIX_LENGTH].lower()
            if file_prefix == target_prefix:
                similar_files.append(os.path.join(target_dir, filename))
    
    return similar_files

def get_strm_content(strm_path):
    """读取STRM文件内容"""
    try:
        with open(strm_path, 'r', encoding='utf-8') as f:
            return f.readline().strip()
    except Exception as e:
        xbmc.log(f"[STRM同步工具] 读取STRM内容失败：{str(e)}", xbmc.LOGERROR)
        return None

def remove_duplicate_strm_files(target_path):
    """移除同目录下前缀相似且内容相同的旧STRM文件"""
    if not os.path.exists(target_path) or not os.path.isfile(target_path):
        return 0
    
    target_dir = os.path.dirname(target_path)
    target_filename = os.path.basename(target_path)
    similar_files = find_similar_strm_files(target_dir, target_filename)
    
    if not similar_files:
        return 0
    
    # 获取目标文件的内容和修改时间
    target_content = get_strm_content(target_path)
    if not target_content:
        return 0
    
    target_mtime = os.path.getmtime(target_path)
    deleted_count = 0
    
    # 检查每个相似文件
    for file_path in similar_files:
        file_content = get_strm_content(file_path)
        if file_content == target_content:
            file_mtime = os.path.getmtime(file_path)
            # 只删除比目标文件旧的文件
            if file_mtime < target_mtime:
                try:
                    os.remove(file_path)
                    deleted_count += 1
                    xbmc.log(f"[STRM同步工具] 删除重复STRM文件：{file_path}（内容相同且较旧）", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[STRM同步工具] 删除重复文件失败：{str(e)}", xbmc.LOGERROR)
    
    # 如果删除了文件，检查是否有需要清理的空目录（但保留BDMV目录）
    if deleted_count > 0:
        delete_empty_dirs(target_dir)
    
    return deleted_count

def process_single_item(item_path, progress=None):
    """处理单个文件或文件夹，返回统计数据"""
    xbmc.log(f"[STRM同步工具] 开始处理单个项目：{item_path}", xbmc.LOGINFO)
    if not os.path.exists(item_path):
        xbmc.log(f"[STRM同步工具] 错误：项目不存在 -> {item_path}", xbmc.LOGERROR)
        return (0, 0, 0, 0, [f"项目不存在：{item_path}"])
    
    # 获取最顶层的源目录（用于相对路径计算）
    source_dirs = load_source_directories()
    base_source = None
    for src_dir in source_dirs:
        if item_path.startswith(src_dir):
            base_source = src_dir
            break
    
    # 如果没找到，将项目所在目录作为临时源目录
    if not base_source:
        base_source = os.path.dirname(item_path) if os.path.isfile(item_path) else item_path
        add_source_directory(base_source)  # 添加到源目录记录
    
    video_extensions = get_video_extensions()
    new_count = 0
    updated_count = 0
    deleted_duplicates = 0
    deleted_obsolete = 0
    error_list = []
    existing_strm = collect_existing_strm(include_mtime=True)
    
    try:
        # 处理文件夹
        if os.path.isdir(item_path):
            # 检查是否是BDMV文件夹
            has_bdmv = any(dir_name.lower() == 'bdmv' for dir_name in os.listdir(item_path) 
                          if os.path.isdir(os.path.join(item_path, dir_name)))
            
            if has_bdmv:
                rel_path = os.path.relpath(item_path, base_source)
                item_key = f"bdmv_{rel_path}_{base_source}"
                
                folder_name = os.path.basename(item_path)
                folder_mtime = os.path.getmtime(item_path)
                is_new = item_key not in existing_strm
                
                # 检查是否需要更新
                if not is_new:
                    strm_path, strm_mtime = existing_strm[item_key]
                    if folder_mtime <= strm_mtime:
                        xbmc.log(f"[STRM同步工具] 跳过：BDMV文件夹{folder_name}未更新", xbmc.LOGINFO)
                        return (0, 0, 0, 0, [])
                
                if progress:
                    progress.update(50, f"处理BDMV：{folder_name}")
                success, result = create_strm_file("bdmv", item_path, folder_name, base_source)
                if success:
                    if is_new:
                        new_count += 1
                    else:
                        updated_count += 1
                    # 检查并删除重复文件
                    deleted = remove_duplicate_strm_files(result)
                    deleted_duplicates += deleted
                    xbmc.log(f"[STRM同步工具] BDMV STRM{'新增' if is_new else '更新'}成功：{result}，删除重复{deleted}个", xbmc.LOGINFO)
                else:
                    error_list.append(f"BDMV {folder_name}：{result}")
                    xbmc.log(f"[STRM同步工具] BDMV STRM生成失败：{result}", xbmc.LOGERROR)
                
                return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list)
            
            # 处理普通文件夹（递归处理所有视频文件）
            source_keys = set()
            for root, dirs, files in os.walk(item_path):
                # 检查是否包含BDMV子文件夹
                bdmv_dirs = [d for d in dirs if d.lower() == 'bdmv']
                if bdmv_dirs:
                    # 处理BDMV文件夹
                    bdmv_path = os.path.join(root, bdmv_dirs[0])
                    parent_folder = os.path.dirname(bdmv_path)
                    rel_path = os.path.relpath(parent_folder, base_source)
                    item_key = f"bdmv_{rel_path}_{base_source}"
                    source_keys.add(item_key)
                    
                    folder_name = os.path.basename(parent_folder)
                    folder_mtime = os.path.getmtime(parent_folder)
                    is_new = item_key not in existing_strm
                    
                    if not is_new:
                        strm_path, strm_mtime = existing_strm[item_key]
                        if folder_mtime <= strm_mtime:
                            xbmc.log(f"[STRM同步工具] 跳过：BDMV文件夹{folder_name}未更新", xbmc.LOGINFO)
                            dirs[:] = []  # 跳过子目录
                            continue
                    
                    if progress:
                        progress.update(0, f"处理BDMV：{folder_name}")
                    success, result = create_strm_file("bdmv", parent_folder, folder_name, base_source)
                    if success:
                        if is_new:
                            new_count += 1
                        else:
                            updated_count += 1
                        # 检查并删除重复文件
                        deleted = remove_duplicate_strm_files(result)
                        deleted_duplicates += deleted
                    else:
                        error_list.append(f"BDMV {folder_name}：{result}")
                    
                    dirs[:] = []  # 处理完BDMV后不再扫描子目录
                    continue
                
                # 处理视频文件
                for file in files:
                    file_ext = os.path.splitext(file)[1].lower()
                    if file_ext in video_extensions:
                        file_path = os.path.join(root, file)
                        rel_path = os.path.relpath(file_path, base_source)
                        item_key = f"video_{rel_path}_{base_source}"
                        source_keys.add(item_key)
                        
                        try:
                            file_mtime = os.path.getmtime(file_path)
                            is_new = item_key not in existing_strm
                            
                            if not is_new:
                                strm_path, strm_mtime = existing_strm[item_key]
                                if file_mtime <= strm_mtime:
                                    continue
                            
                            if progress:
                                progress.update(0, f"处理文件：{file}")
                            success, result = create_strm_file("video", file_path, file, base_source)
                            if success:
                                if is_new:
                                    new_count += 1
                                else:
                                    updated_count += 1
                                # 检查并删除重复文件
                                deleted = remove_duplicate_strm_files(result)
                                deleted_duplicates += deleted
                            else:
                                error_list.append(f"视频 {file}：{result}")
                        except Exception as e:
                            error_list.append(f"获取{file}信息失败：{str(e)}")
                
                if progress and progress.iscanceled():
                    error_list.append("操作已取消")
                    return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list)
            
            # 清理已删除的文件对应的STRM
            for item_key in existing_strm:
                if item_key.endswith(f"_{base_source}") and item_key not in source_keys:
                    strm_path = existing_strm[item_key][0] if isinstance(existing_strm[item_key], tuple) else existing_strm[item_key]
                    try:
                        if os.path.exists(strm_path):
                            os.remove(strm_path)
                            deleted_obsolete += 1
                            xbmc.log(f"[STRM同步工具] 删除过时STRM文件：{strm_path}（源文件已删除）", xbmc.LOGINFO)
                    except Exception as e:
                        error_list.append(f"删除过时文件{os.path.basename(strm_path)}失败：{str(e)}")
            
            delete_empty_dirs(TARGET_DIR)
        
        # 处理单个视频文件
        elif os.path.isfile(item_path):
            file_ext = os.path.splitext(item_path)[1].lower()
            if file_ext in video_extensions:
                rel_path = os.path.relpath(item_path, base_source)
                item_key = f"video_{rel_path}_{base_source}"
                source_keys = {item_key}
                
                try:
                    file_mtime = os.path.getmtime(item_path)
                    is_new = item_key not in existing_strm
                    
                    if not is_new:
                        strm_path, strm_mtime = existing_strm[item_key]
                        if file_mtime <= strm_mtime:
                            xbmc.log(f"[STRM同步工具] 跳过：视频文件未更新", xbmc.LOGINFO)
                            return (0, 0, 0, 0, [])
                    
                    file_name = os.path.basename(item_path)
                    if progress:
                        progress.update(50, f"处理文件：{file_name}")
                    success, result = create_strm_file("video", item_path, file_name, base_source)
                    if success:
                        if is_new:
                            new_count += 1
                        else:
                            updated_count += 1
                        # 检查并删除重复文件
                        deleted = remove_duplicate_strm_files(result)
                        deleted_duplicates += deleted
                        xbmc.log(f"[STRM同步工具] 视频STRM{'新增' if is_new else '更新'}成功：{result}，删除重复{deleted}个", xbmc.LOGINFO)
                    else:
                        error_list.append(f"视频 {file_name}：{result}")
                        xbmc.log(f"[STRM同步工具] 视频STRM生成失败：{result}", xbmc.LOGERROR)
                except Exception as e:
                    error_list.append(f"处理文件失败：{str(e)}")
                
                # 清理已删除的文件对应的STRM
                for item_key in existing_strm:
                    if item_key.endswith(f"_{base_source}") and item_key not in source_keys:
                        strm_path = existing_strm[item_key][0] if isinstance(existing_strm[item_key], tuple) else existing_strm[item_key]
                        try:
                            if os.path.exists(strm_path):
                                os.remove(strm_path)
                                deleted_obsolete += 1
                                xbmc.log(f"[STRM同步工具] 删除过时STRM文件：{strm_path}（源文件已删除）", xbmc.LOGINFO)
                        except Exception as e:
                            error_list.append(f"删除过时文件{os.path.basename(strm_path)}失败：{str(e)}")
                
                delete_empty_dirs(TARGET_DIR)
            else:
                error_list.append(f"不支持的文件格式：{os.path.basename(item_path)}")
        
        xbmc.log(f"[STRM同步工具] 单个项目处理完成，新增{new_count}个，更新{updated_count}个STRM，删除重复{deleted_duplicates}个，删除过时{deleted_obsolete}个", xbmc.LOGINFO)
    
    except Exception as e:
        error_msg = f"处理项目出错：{str(e)}"
        error_list.append(error_msg)
        xbmc.log(f"[STRM同步工具] 处理项目异常：{error_msg}", xbmc.LOGERROR)
    
    return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list)

def collect_existing_strm(include_mtime=False):
    existing_strm = {}
    if not os.path.exists(TARGET_DIR):
        return existing_strm
    
    for root, _, files in os.walk(TARGET_DIR):
        for file in files:
            if file.lower().endswith('.strm'):
                strm_path = os.path.join(root, file)
                try:
                    with open(strm_path, 'r', encoding='utf-8') as f:
                        source_path = f.readline().strip()
                    
                    source_dirs = load_source_directories()
                    base_source = None
                    for src_dir in source_dirs:
                        if source_path.startswith(src_dir):
                            base_source = src_dir
                            break
                    if not base_source:
                        continue
                    
                    if 'BDMV/index.bdmv' in source_path:
                        bdmv_folder = os.path.dirname(os.path.dirname(source_path))
                        rel_path = os.path.relpath(bdmv_folder, base_source)
                        item_key = f"bdmv_{rel_path}_{base_source}"
                    else:
                        rel_path = os.path.relpath(source_path, base_source)
                        item_key = f"video_{rel_path}_{base_source}"
                    
                    if include_mtime:
                        strm_mtime = os.path.getmtime(strm_path)
                        existing_strm[item_key] = (strm_path, strm_mtime)
                    else:
                        existing_strm[item_key] = strm_path
                
                except Exception as e:
                    xbmc.log(f"[STRM同步工具] 处理STRM文件失败：{str(e)}", xbmc.LOGERROR)
    
    return existing_strm

def create_strm_file(item_type, source_path, name, source_dir):
    try:
        if item_type == "bdmv":
            strm_content = os.path.join(source_path, "BDMV", "index.bdmv")
            original_filename = name
        else:
            strm_content = source_path
            original_filename = name
        
        strm_filename = clean_and_truncate(original_filename, MAX_FILENAME_LENGTH)
        xbmc.log(f"[STRM同步工具] 处理后文件名：{strm_filename}（长度：{len(strm_filename)}）", xbmc.LOGINFO)
        
        full_source_dir = os.path.dirname(source_path) if item_type == "video" else source_path
        path_parts = [part for part in full_source_dir.split(os.sep) if part]
        target_parts = []
        found_truncate_index = -1  # 记录最后一个符合条件的前缀索引
        
        # 按优先级查找前缀文件夹，记录最后一个符合条件的索引
        for i, part in enumerate(path_parts):
            part_lower = part.lower()
            # 检查当前部分是否匹配优先级列表中的任何前缀
            for prefix in PRIORITY_PREFIXES:
                if part_lower == prefix:
                    found_truncate_index = i  # 更新为当前索引（最后出现的会覆盖前面的）
                    break
        
        # 根据找到的截断点处理路径
        if found_truncate_index != -1:
            # 截取截断点之后的路径部分
            for part in path_parts[found_truncate_index + 1:]:
                cleaned_part = clean_folder_name(part)
                if cleaned_part:
                    target_parts.append(cleaned_part)
        else:
            # 未找到任何前缀，使用完整路径（排除源目录部分）
            source_dir_parts = [clean_folder_name(part) for part in source_dir.split(os.sep) if part]
            source_dir_parts = [p for p in source_dir_parts if p.strip()]
            if len(path_parts) >= len(source_dir_parts) and path_parts[:len(source_dir_parts)] == source_dir_parts:
                target_parts = path_parts[len(source_dir_parts):]
            else:
                target_parts = path_parts
        
        final_target_dir = TARGET_DIR
        if target_parts:
            target_subdir = os.sep.join(target_parts)
            final_target_dir = os.path.join(TARGET_DIR, target_subdir)
        
        # 创建目标目录（如果不存在）
        if not os.path.exists(final_target_dir):
            os.makedirs(final_target_dir, exist_ok=True)
        
        # 对于BDMV类型，创建空的BDMV文件夹并添加保护文件
        if item_type == "bdmv":
            bdmv_empty_dir = os.path.join(final_target_dir, "BDMV")
            if not os.path.exists(bdmv_empty_dir):
                os.makedirs(bdmv_empty_dir, exist_ok=True)
                # 创建保护文件防止目录被删除
                protection_file = os.path.join(bdmv_empty_dir, ".keep")
                with open(protection_file, 'w', encoding='utf-8') as f:
                    f.write("This file keeps the BDMV directory from being deleted")
                xbmc.log(f"[STRM同步工具] 创建受保护的BDMV文件夹：{bdmv_empty_dir}", xbmc.LOGINFO)
        
        strm_path = os.path.join(final_target_dir, strm_filename)
        
        path_length = len(strm_path)
        if path_length > 255:
            xbmc.log(f"[STRM同步工具] 路径较长（{path_length}字符）：{strm_path}", xbmc.LOGWARNING)
        
        with open(strm_path, 'w', encoding='utf-8') as f:
            f.write(strm_content)
        
        if os.path.getsize(strm_path) == 0:
            raise Exception("STRM文件为空")
        
        return True, strm_path
    except Exception as e:
        return False, f"{str(e)}"

def delete_empty_dirs(root_dir):
    """删除空目录，但保留BDMV文件夹（即使为空）"""
    if not os.path.isdir(root_dir):
        return
    
    # 先递归处理子目录
    for dir_name in os.listdir(root_dir):
        dir_path = os.path.join(root_dir, dir_name)
        if os.path.isdir(dir_path):
            # 特别处理BDMV目录：不递归删除其子目录
            if dir_name.lower() == "bdmv":
                continue
            delete_empty_dirs(dir_path)
    
    # 检查当前目录是否为空且不是BDMV文件夹
    if os.path.basename(root_dir).lower() != "bdmv":  # 排除BDMV文件夹
        try:
            # 检查目录是否真的为空
            if not os.listdir(root_dir):
                os.rmdir(root_dir)
                xbmc.log(f"[STRM同步工具] 删除空目录：{root_dir}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[STRM同步工具] 删除空目录失败：{str(e)}", xbmc.LOGERROR)

def sync_selected_source(selected_dirs):
    total_new = 0
    total_updated = 0
    total_duplicates = 0
    total_obsolete = 0
    total_errors = []
    all_source_keys = set()
    progress = xbmcgui.DialogProgress()
    progress.create("同步目录", "准备同步...")
    
    try:
        for i, src_dir in enumerate(selected_dirs):
            src_name = get_display_name(src_dir)
            progress.update(int(i/len(selected_dirs)*100), f"处理目录：{src_name}")
            
            new_count, updated_count, duplicates, deleted_obsolete, errors, source_keys = process_source_directory(src_dir, progress)
            total_new += new_count
            total_updated += updated_count
            total_duplicates += duplicates
            total_obsolete += deleted_obsolete
            total_errors.extend(errors)
            all_source_keys.update(source_keys)
            
            if progress.iscanceled():
                break
        
        if progress.iscanceled():
            xbmcgui.Dialog().ok("同步取消", "同步已终止")
            return
    
    finally:
        progress.close()
    
    # 更新结果消息，包含过时文件删除数量
    result_msg = [
        f"同步目录数量：{len(selected_dirs)}",
        f"新增STRM文件：{total_new} 个",
        f"更新STRM文件：{total_updated} 个",
        f"删除过时文件：{total_obsolete} 个",
        f"删除重复文件：{total_duplicates} 个"
    ]
    
    if total_errors:
        result_msg.append(f"\n错误 ({len(total_errors)})：")
        for err in total_errors[:5]:
            result_msg.append(f"- {err}")
        if len(total_errors) > 5:
            result_msg.append(f"- 还有 {len(total_errors)-5} 个错误")
    
    xbmcgui.Dialog().ok("同步完成", "\n".join(result_msg))

def get_display_name(source_dir):
    path_parts = [part for part in source_dir.split(os.sep) if part]
    display_parts = []
    found_truncate_index = -1  # 记录最后一个符合条件的前缀索引
    
    # 按优先级查找前缀文件夹，记录最后一个符合条件的索引
    for i, part in enumerate(path_parts):
        part_lower = part.lower()
        for prefix in PRIORITY_PREFIXES:
            if part_lower == prefix:
                found_truncate_index = i  # 更新为当前索引（最后出现的会覆盖前面的）
                break
    
    # 截取截断点之后的路径部分作为显示名称
    if found_truncate_index != -1:
        display_parts = path_parts[found_truncate_index + 1:]
    else:
        # 未找到任何前缀，显示最后两级目录
        display_parts = path_parts[-2:] if len(path_parts) >= 2 else path_parts
    
    return os.sep.join(display_parts)

def add_source_and_sync():
    default_path = DEFAULT_source_path
    if not os.path.exists(default_path) or not os.path.isdir(default_path):
        default_path = "/storage"
        xbmc.log(f"[STRM同步工具] 默认源路径不存在，使用 fallback：{default_path}", xbmc.LOGWARNING)
    
    new_source = select_directory("选择视频源目录", default_path)
    if not new_source:
        xbmcgui.Dialog().ok("操作取消", "未选择有效的源目录")
        return
    
    success, msg = add_source_directory(new_source)
    if not success:
        xbmcgui.Dialog().ok("操作失败", msg)
        return
    
    progress = xbmcgui.DialogProgress()
    progress.create("同步目录", f"处理：{get_display_name(new_source)}\n{msg}")
    
    try:
        new_count, updated_count, duplicates, deleted_obsolete, error_list, all_source_keys = process_source_directory(new_source, progress)
        delete_empty_dirs(TARGET_DIR)
    
    finally:
        progress.close()
    
    # 更新结果消息
    result_msg = [
        f"源目录：{get_display_name(new_source)}",
        f"{msg}",
        f"新增STRM文件：{new_count} 个",
        f"更新STRM文件：{updated_count} 个",
        f"删除过时文件：{deleted_obsolete} 个",
        f"删除重复文件：{duplicates} 个"
    ]
    
    if error_list:
        result_msg.append(f"\n错误 ({len(error_list)})：")
        for err in error_list[:5]:
            result_msg.append(f"- {err}")
        if len(error_list) > 5:
            result_msg.append(f"- 还有 {len(error_list)-5} 个错误")
    
    xbmcgui.Dialog().ok("同步完成", "\n".join(result_msg))
    open_strm_in_kodi()

def delete_all_strm():
    if not os.path.exists(TARGET_DIR):
        xbmcgui.Dialog().ok("提示", "STRM目录不存在")
        return
    
    confirm = xbmcgui.Dialog().yesno(
        "警告",
        f"确定删除 {TARGET_DIR} 下所有内容？\n包括所有STRM文件、子目录和源目录记录！"
    )
    if not confirm:
        return
    
    total_files = 0
    for root, _, files in os.walk(TARGET_DIR):
        total_files += len(files)
    
    progress = xbmcgui.DialogProgress()
    progress.create("删除所有内容", "正在处理...")
    file_count = 0
    
    try:
        for root, _, files in os.walk(TARGET_DIR):
            # 特殊处理BDMV目录：只删除其中的文件，不删除目录本身
            if os.path.basename(root).lower() == "bdmv":
                for file in files:
                    # 保留保护文件.keep
                    if file == ".keep":
                        continue
                    file_path = os.path.join(root, file)
                    try:
                        os.remove(file_path)
                        file_count += 1
                        progress.update(int(file_count/total_files*100), f"删除：{file}")
                    except Exception as e:
                        xbmc.log(f"[STRM同步工具] 删除{file}失败：{str(e)}", xbmc.LOGERROR)
                continue  # 跳过BDMV目录的目录删除
            
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    os.remove(file_path)
                    file_count += 1
                    progress.update(int(file_count/total_files*100), f"删除：{file}")
                except Exception as e:
                    xbmc.log(f"[STRM同步工具] 删除{file}失败：{str(e)}", xbmc.LOGERROR)
                
                if progress.iscanceled():
                    progress.close()
                    xbmcgui.Dialog().ok("操作取消", "部分文件已删除")
                    return
        
        # 清理空目录（会自动保留BDMV目录）
        delete_empty_dirs(TARGET_DIR)
        progress.close()
        # 清空源目录记录
        with open(SOURCE_RECORD_FILE, 'w', encoding='utf-8') as f:
            f.write('<?xml version="1.0" ?>\n<source_directories>\n</source_directories>')
        xbmcgui.Dialog().ok("删除完成", f"共删除 {file_count} 个文件和所有空目录\n源目录记录已清空")
    
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok("删除失败", f"错误：{str(e)}")

def process_source_directory(source_dir, progress=None):
    """处理源目录，返回统计数据：(新增数, 更新数, 重复删除数, 过时删除数, 错误列表, 源文件键集合)"""
    xbmc.log(f"[STRM同步工具] 开始处理源目录：{source_dir}", xbmc.LOGINFO)
    if not os.path.exists(source_dir) or not os.path.isdir(source_dir):
        xbmc.log(f"[STRM同步工具] 错误：源目录无效 -> {source_dir}", xbmc.LOGERROR)
        return (0, 0, 0, 0, [f"源目录无效：{source_dir}"], set())
    
    video_extensions = get_video_extensions()
    new_count = 0
    updated_count = 0
    deleted_duplicates = 0
    deleted_obsolete = 0
    error_list = []
    source_keys = set()
    existing_strm = collect_existing_strm(include_mtime=True)
    
    try:
        # 第一阶段：处理所有存在的文件和文件夹，收集有效键
        for root, dirs, files in os.walk(source_dir):
            # 检查当前目录是否包含BDMV文件夹
            has_bdmv = any(dir_name.lower() == 'bdmv' for dir_name in dirs)
            
            if has_bdmv:
                # 处理BDMV文件夹
                rel_path = os.path.relpath(root, source_dir)
                item_key = f"bdmv_{rel_path}_{source_dir}"
                source_keys.add(item_key)
                
                folder_name = os.path.basename(root)
                folder_mtime = os.path.getmtime(root)
                is_new = item_key not in existing_strm
                
                if not is_new:
                    strm_path, strm_mtime = existing_strm[item_key]
                    if folder_mtime <= strm_mtime:
                        xbmc.log(f"[STRM同步工具] 跳过：BDMV文件夹{folder_name}未更新", xbmc.LOGINFO)
                        dirs[:] = []
                        continue
                
                if progress:
                    progress.update(0, f"处理BDMV：{folder_name}")
                success, result = create_strm_file("bdmv", root, folder_name, source_dir)
                if success:
                    if is_new:
                        new_count += 1
                    else:
                        updated_count += 1
                    deleted = remove_duplicate_strm_files(result)
                    deleted_duplicates += deleted
                    xbmc.log(f"[STRM同步工具] BDMV STRM{'新增' if is_new else '更新'}成功：{result}，删除重复{deleted}个", xbmc.LOGINFO)
                else:
                    error_list.append(f"BDMV {folder_name}：{result}")
                    xbmc.log(f"[STRM同步工具] BDMV STRM生成失败：{result}", xbmc.LOGERROR)
                
                dirs[:] = []
                continue
            
            # 处理视频文件
            for file in files:
                file_ext = os.path.splitext(file)[1].lower()
                if file_ext in video_extensions:
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, source_dir)
                    item_key = f"video_{rel_path}_{source_dir}"
                    source_keys.add(item_key)
                    
                    try:
                        file_mtime = os.path.getmtime(file_path)
                        is_new = item_key not in existing_strm
                        
                        if not is_new:
                            strm_path, strm_mtime = existing_strm[item_key]
                            if file_mtime <= strm_mtime:
                                continue
                        
                        if progress:
                            progress.update(0, f"处理文件：{file}")
                        success, result = create_strm_file("video", file_path, file, source_dir)
                        if success:
                            if is_new:
                                new_count += 1
                            else:
                                updated_count += 1
                            deleted = remove_duplicate_strm_files(result)
                            deleted_duplicates += deleted
                        else:
                            error_list.append(f"视频 {file}：{result}")
                    except Exception as e:
                        error_list.append(f"获取{file}信息失败：{str(e)}")
                        continue
            
            if progress and progress.iscanceled():
                error_list.append("操作已取消")
                return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list, source_keys)
        
        # 第二阶段：清理源中已删除的文件对应的STRM
        xbmc.log(f"[STRM同步工具] 开始检查并清理过时STRM文件", xbmc.LOGINFO)
        for item_key in existing_strm:
            # 只处理当前源目录的STRM文件
            if item_key.endswith(f"_{source_dir}") and item_key not in source_keys:
                strm_path = existing_strm[item_key][0] if isinstance(existing_strm[item_key], tuple) else existing_strm[item_key]
                try:
                    if os.path.exists(strm_path):
                        os.remove(strm_path)
                        deleted_obsolete += 1
                        xbmc.log(f"[STRM同步工具] 删除过时STRM文件：{strm_path}（源文件已删除）", xbmc.LOGINFO)
                except Exception as e:
                    error_list.append(f"删除过时文件{os.path.basename(strm_path)}失败：{str(e)}")
                    xbmc.log(f"[STRM同步工具] 删除过时文件失败：{str(e)}", xbmc.LOGERROR)
        
        # 清理空目录（会自动保留BDMV目录）
        delete_empty_dirs(TARGET_DIR)
        
        xbmc.log(f"[STRM同步工具] 源目录处理完成：{source_dir}，新增{new_count}个，更新{updated_count}个，删除重复{deleted_duplicates}个，删除过时{deleted_obsolete}个", xbmc.LOGINFO)
    
    except Exception as e:
        error_msg = f"扫描目录出错：{str(e)}"
        error_list.append(error_msg)
        xbmc.log(f"[STRM同步工具] 扫描目录异常：{error_msg}", xbmc.LOGERROR)
    
    return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list, source_keys)

def show_manual_sync_menu():
    options = [
        "添加源目录生成strm文件",
        "选择同步源目录",
        "删除所有strm文件及记录"
    ]
    return xbmcgui.Dialog().select("手动同步模式选择", options)

def show_source_selection_menu():
    source_dirs = load_source_directories()
    if not source_dirs:
        xbmcgui.Dialog().ok("同步失败", "未找到源目录，请先添加源目录")
        return None
    
    options = ["所有文件夹"]
    options.extend([get_display_name(dir) for dir in source_dirs])
    
    selected = xbmcgui.Dialog().select("选择要同步的目录", options)
    if selected == -1:
        return None
    
    if selected == 0:
        return source_dirs
    else:
        return [source_dirs[selected - 1]]

def select_directory(title, default_path):
    """选择目录，返回选择的路径或None（如果取消）"""
    result = xbmcgui.Dialog().browse(
        type=3,
        heading=title,
        shares="local",
        defaultt=default_path,
        useThumbs=False,
        treatAsFolder=True,
        mask=""
    )
    if not result or result == default_path:
        return None
    return result

def open_strm_in_kodi():
    if os.path.exists(TARGET_DIR) and os.path.isdir(TARGET_DIR):
        xbmc.executebuiltin(f'ActivateWindow(Videos, "{TARGET_DIR}", return)')
    else:
        xbmcgui.Dialog().ok("打开失败", "STRM目录不存在")

def auto_mode():
    source_dirs = load_source_directories()
    strm_exists = os.path.exists(TARGET_DIR) and os.path.isdir(TARGET_DIR)
    strm_empty = True
    
    if strm_exists:
        for _, _, files in os.walk(TARGET_DIR):
            if any(f.lower().endswith('.strm') for f in files):
                strm_empty = False
                break
    
    if not source_dirs or (strm_exists and strm_empty):
        confirm = xbmcgui.Dialog().yesno(
            "未找到有效数据",
            "是否添加源目录并生成STRM文件？"
        )
        if confirm:
            add_source_and_sync()
    else:
        open_strm_in_kodi()

def handle_addstrm():
    """处理addstrm参数，生成当前选中项目的STRM文件"""
    # 获取当前选中的项目路径
    item_path = xbmc.getInfoLabel('ListItem.FolderPath')
    if not item_path or item_path == "":
        item_path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    
    # 处理特殊路径格式
    if item_path.startswith('special://'):
        item_path = xbmc.translatePath(item_path)
    
    if not item_path or not os.path.exists(item_path):
        xbmcgui.Dialog().ok("错误", "未找到选中的项目或项目不存在")
        return
    
    # 显示进度对话框
    progress = xbmcgui.DialogProgress()
    progress.create("生成STRM文件", f"正在处理：{os.path.basename(item_path)}")
    
    try:
        new_count, updated_count, deleted_duplicates, deleted_obsolete, errors = process_single_item(item_path, progress)
    finally:
        progress.close()
    
    # 显示结果对话框
    result_msg = [
        f"处理项目：{os.path.basename(item_path)}",
        f"新增STRM文件：{new_count} 个",
        f"更新STRM文件：{updated_count} 个",
        f"删除重复文件：{deleted_duplicates} 个",
        f"删除过时文件：{deleted_obsolete} 个"
    ]
    
    if errors:
        result_msg.append(f"\n错误 ({len(errors)})：")
        for err in errors[:5]:
            result_msg.append(f"- {err}")
        if len(errors) > 5:
            result_msg.append(f"- 还有 {len(errors)-5} 个错误")
    
    xbmcgui.Dialog().ok("处理完成", "\n".join(result_msg))

def is_fullscreen_video_playing():
    """检查是否正在全屏播放视频"""
    return xbmc.getCondVisibility("Window.IsVisible(FullscreenVideo)")

def monitor_directory_changes():
    """监控线程函数，循环检查源目录变化，全屏播放时暂停"""
    global monitor_running
    xbmc.log("[STRM同步工具] 监控线程已启动", xbmc.LOGINFO)
    
    while monitor_running:
        # 检查是否正在全屏播放视频
        if is_fullscreen_video_playing():
            xbmc.log("[STRM同步工具] 检测到全屏视频播放，暂停监控", xbmc.LOGINFO)
            # 缩短检查间隔，以便在播放结束后快速恢复
            wait_time = 0
            while wait_time < FULLSCREEN_CHECK_INTERVAL and monitor_running and is_fullscreen_video_playing():
                time.sleep(1)
                wait_time += 1
            continue
        
        source_dirs = load_source_directories()
        if not source_dirs:
            xbmc.log("[STRM同步工具] 没有需要监控的源目录，等待下次检查...", xbmc.LOGINFO)
            time.sleep(MONITOR_CHECK_INTERVAL)
            continue
        
        # 依次检查每个源目录
        for src_dir in source_dirs:
            if not monitor_running:  # 检查是否需要退出
                break
                
            if not os.path.exists(src_dir) or not os.path.isdir(src_dir):
                xbmc.log(f"[STRM同步工具] 源目录不存在或无效：{src_dir}，跳过检查", xbmc.LOGWARNING)
                continue
                
            xbmc.log(f"[STRM同步工具] 开始检查源目录更新：{src_dir}", xbmc.LOGINFO)
            # 处理源目录，进行增量同步（包含减量清理）
            new_count, updated_count, duplicates, deleted_obsolete, errors, _ = process_source_directory(src_dir)
            
            # 记录同步结果
            if new_count > 0 or updated_count > 0 or duplicates > 0 or deleted_obsolete > 0:
                xbmc.log(f"[STRM同步工具] 源目录 {src_dir} 同步完成：新增{new_count}，更新{updated_count}，删除重复{duplicates}，删除过时{deleted_obsolete}", xbmc.LOGINFO)
            
            if errors:
                xbmc.log(f"[STRM同步工具] 源目录 {src_dir} 同步过程中出现错误：{', '.join(errors)}", xbmc.LOGERROR)
        
        # 等待下一次检查
        wait_time = 0
        while wait_time < MONITOR_CHECK_INTERVAL and monitor_running and not is_fullscreen_video_playing():
            time.sleep(1)
            wait_time += 1
    
    xbmc.log("[STRM同步工具] 监控线程已停止", xbmc.LOGINFO)

def start_monitor_mode():
    """启动监控模式（无对话框）"""
    global monitor_running
    if monitor_running:
        xbmc.log("[STRM同步工具] 监控模式已在运行中", xbmc.LOGINFO)
        return
    
    # 直接启动监控线程，无确认对话框
    monitor_running = True
    monitor_thread = threading.Thread(target=monitor_directory_changes, daemon=True)
    monitor_thread.start()
    
    xbmc.log(f"[STRM同步工具] 监控模式已启动，检查间隔 {MONITOR_CHECK_INTERVAL//60} 分钟", xbmc.LOGINFO)

def stop_monitor_mode():
    """停止监控模式（无对话框）"""
    global monitor_running
    if not monitor_running:
        xbmc.log("[STRM同步工具] 监控模式未在运行", xbmc.LOGINFO)
        return
    
    monitor_running = False
    xbmc.log("[STRM同步工具] 监控模式已停止", xbmc.LOGINFO)

def main():
    initialize()
    args = sys.argv[1:] if len(sys.argv) > 1 else []
    
    # 处理addstrm参数
    if "addstrm" in args:
        handle_addstrm()
        return
    
    # 处理monitor参数
    if "monitor" in args:
        global monitor_running
        if monitor_running:
            stop_monitor_mode()
        else:
            start_monitor_mode()
        return
    
    if "manualsync" in args:
        selected = show_manual_sync_menu()
        if selected == 0:
            add_source_and_sync()
        elif selected == 1:
            selected_dirs = show_source_selection_menu()
            if selected_dirs is not None and len(selected_dirs) > 0:
                sync_selected_source(selected_dirs)
                open_strm_in_kodi()
        elif selected == 2:
            delete_all_strm()
    else:
        auto_mode()

if __name__ == '__main__':
    main()