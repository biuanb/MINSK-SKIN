import os
import sys
import xbmc
import xbmcgui
import xbmcvfs

# 获取用户数据目录（兼容新旧版本Kodi）
try:
    userdata_path = xbmcvfs.translatePath("special://userdata")
except AttributeError:
    userdata_path = xbmc.translatePath("special://userdata")

database_dir = os.path.join(userdata_path, "Database")

try:
    # 确认提示（横向按钮：是 / 否）
    if not xbmcgui.Dialog().yesno(
        "警告",
        "该操作将删除全部的电影和剧集的海报信息，并且不可逆！\n 您确定要继续吗？",
        "我再想想"
    ):
        xbmcgui.Dialog().ok("提示", "操作已取消")
        sys.exit(0)

    # 查找并删除所有包含"MyVideos"的文件
    deleted_files = []
    if os.path.exists(database_dir):
        for filename in os.listdir(database_dir):
            if "MyVideos" in filename:
                file_path = os.path.join(database_dir, filename)
                os.remove(file_path)
                deleted_files.append(filename)
    
    # 显示删除结果
    if deleted_files:
        xbmcgui.Dialog().ok("完成", "已成功删除所有电影和剧集海报！")
    else:
        xbmcgui.Dialog().ok("提示", "你的媒体资料库是空的，无需进行清理。")
    
    # 重载皮肤
    xbmc.executebuiltin("ReloadSkin()")

except Exception as e:
    xbmcgui.Dialog().ok("错误", f"操作失败: {str(e)}")
    sys.exit(1)