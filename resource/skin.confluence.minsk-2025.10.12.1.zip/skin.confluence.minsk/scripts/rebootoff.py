#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import subprocess
import xbmc

def reboot_system():
    """先同步数据再强制重启（加快重启速度）"""
    xbmc.log("同步数据并强制重启", xbmc.LOGINFO)
    subprocess.run(["sync"])  # 确保数据写入磁盘
    subprocess.run(["reboot", "-f"])  # 强制重启，不等待服务退出

def poweroff_system():
    """先同步数据再强制关机"""
    xbmc.log("同步数据并强制关机", xbmc.LOGINFO)
    subprocess.run(["sync"])  # 确保数据写入磁盘
    subprocess.run(["halt", "-f"])  # 强制关机，跳过进程终止

if __name__ == "__main__":
    args = sys.argv[1:]  # 从 RunScript 接收参数
    if args and args[0].lower() == "reboot":
        reboot_system()
    elif args and args[0].lower() == "turnoff":
        poweroff_system()
    else:
        xbmc.log("未指定或参数错误，不执行任何操作。", xbmc.LOGWARNING)