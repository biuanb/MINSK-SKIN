import xbmc
import xbmcgui
import json
import time

# 刷新率自动调整设置ID
SETTING_ID_REFRESH = "videoplayer.adjustrefreshrate"

# 选项
options_refresh = [
    "关闭(取消握手解决播放黑屏问题)",             # 值: 0
    "在开始播放/停止播放时"  # 值: 2
]

dialog = xbmcgui.Dialog()
selected_index = dialog.select("刷新率自动调整", options_refresh)

if selected_index != -1:
    new_refresh_value = 0 if selected_index == 0 else 2

    # 设置刷新率自动调整
    set_refresh_request = {
        "jsonrpc": "2.0",
        "method": "Settings.SetSettingValue",
        "params": {"setting": SETTING_ID_REFRESH, "value": new_refresh_value},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(set_refresh_request))

    dialog.ok("设置完成", f"刷新率自动调整 已设为:\n{options_refresh[selected_index]}")

    # 如果选择关闭，则进入显示设置并模拟按键
    if new_refresh_value == 0:
        # 打开系统 → 显示 设置页面
        xbmc.executebuiltin('ActivateWindow(systemSettings,display)')

        # 等待窗口加载
        time.sleep(1)

        # 模拟向左方向键
        xbmc.executebuiltin('Action(right)')

        # 等待界面响应
        time.sleep(0.5)

        # 模拟确定键，调出分辨率选择窗口
        xbmc.executebuiltin('Action(Select)')

else:
    dialog.ok("已取消", "未做任何更改")