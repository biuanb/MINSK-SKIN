import os
import re
import json
import time
import shutil
import zipfile
import tempfile
import urllib.request
import xbmc
import xbmcgui
import xbmcvfs

# === 核心配置===
SKIN_ADDON_ID = "skin.confluence.minsk"
# 版本检测网址
VER_URL = "https://raw.staticdn.net/biuanb/MINSK-SKIN/main/resource/version.txt"
# 下载地址前缀
DL_PRE_URL = "https://raw.staticdn.net/biuanb/MINSK-SKIN/main/resource/skin.confluence.minsk-"
DL_SUF = ".zip"  # 下载地址后缀

DOWNLOAD_DIR = "/storage/downloads/"
ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
SKIN_DIR = os.path.join(ADDONS_DIR, SKIN_ADDON_ID)


def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[SkinUpdater] {message}", level)


def get_current_skin_version():
    """获取当前皮肤版本"""
    try:
        rpc_request = {
            "jsonrpc": "2.0",
            "method": "Addons.GetAddonDetails",
            "params": {"addonid": SKIN_ADDON_ID, "properties": ["version"]},
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(rpc_request))
        result = json.loads(response)
        if "result" in result and "addon" in result["result"]:
            return result["result"]["addon"]["version"]
        return None
    except Exception as e:
        log(f"获取当前版本失败: {e}", xbmc.LOGERROR)
        return None


def get_remote_version():
    """获取远程版本"""
    try:
        headers = {"User-Agent": "SkinUpdater"}
        req = urllib.request.Request(VER_URL, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as response:
            version_str = response.read().decode("utf-8").strip()
            if re.match(r'^\d+\.\d+\.\d+\.\d+$', version_str):
                return version_str
        return None
    except Exception as e:
        log(f"获取远程版本失败: {e}", xbmc.LOGERROR)
        return None


def get_latest_zip_url(version):
    """构造下载链接"""
    return f"{DL_PRE_URL}{version}{DL_SUF}"


def compare_versions(ver1, ver2):
    """比较版本号"""
    try:
        v1 = [int(p) for p in ver1.split('.')]
        v2 = [int(p) for p in ver2.split('.')]
        for i in range(max(len(v1), len(v2))):
            num1 = v1[i] if i < len(v1) else 0
            num2 = v2[i] if i < len(v2) else 0
            if num1 > num2:
                return 1
            elif num1 < num2:
                return -1
        return 0
    except Exception as e:
        log(f"版本比较出错: {e}", xbmc.LOGERROR)
        return None


def download_with_progress(url, save_path):
    """带进度条下载"""
    try:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        req = urllib.request.Request(url, headers={"User-Agent": "SkinUpdater"})
        with urllib.request.urlopen(req) as response:
            total_size = int(response.headers.get("Content-Length", 0))
            downloaded_size = 0

            dialog = xbmcgui.DialogProgress()
            dialog.create("皮肤更新", "准备下载...")

            with open(save_path, "wb") as out_file:
                while True:
                    chunk = response.read(8192)
                    if not chunk:
                        break
                    out_file.write(chunk)
                    downloaded_size += len(chunk)
                    if total_size > 0:
                        percent = int((downloaded_size / total_size) * 100)
                        dialog.update(percent, f"下载中... {percent}%")
                    if dialog.iscanceled():
                        dialog.close()
                        os.remove(save_path)
                        xbmcgui.Dialog().ok("下载取消", "您已取消下载。")
                        return False
            dialog.close()
            return True
    except Exception as e:
        log(f"下载失败: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("下载错误", f"下载过程中发生错误:\n{str(e)}")
        return False


def refresh_addon_database():
    """刷新插件数据库"""
    try:
        xbmc.executebuiltin('UpdateLocalAddons')
        log("已执行数据库刷新")
        time.sleep(2)
    except Exception as e:
        log(f"刷新数据库出错: {e}", xbmc.LOGERROR)


def copy_override(src_dir, dst_dir):
    """复制覆盖文件"""
    failed_files = []
    try:
        os.makedirs(dst_dir, exist_ok=True)

        for root, dirs, files in os.walk(src_dir):
            rel_path = os.path.relpath(root, src_dir)
            target_root = os.path.join(dst_dir, rel_path)
            os.makedirs(target_root, exist_ok=True)

            for file in files:
                src_file = os.path.join(root, file)
                dst_file = os.path.join(target_root, file)
                try:
                    if os.path.exists(dst_file):
                        os.remove(dst_file)
                    shutil.copy2(src_file, dst_file)
                    log(f"已覆盖: {dst_file}")
                except Exception as e:
                    failed_files.append(f"{dst_file} (原因: {str(e)[:50]})")
                    log(f"覆盖失败: {dst_file} | 原因: {e}")

        return True, failed_files
    except Exception as e:
        log(f"复制覆盖整体失败: {e}", xbmc.LOGERROR)
        return False, [f"整体复制失败 (原因: {str(e)[:50]})"]


def install_from_zip_dialog():
    """手动更新"""
    dialog = xbmcgui.Dialog()
    if dialog.ok("手动更新", "请把皮肤ZIP包复制到 downloads 文件夹后点击确定。"):
        xbmc.executebuiltin('InstallFromZip')
        xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')
        log("手动更新已执行，重置更新标记")


def main():
    # === 方案2：添加皮肤设置条件判断（放在所有逻辑最开头）===
    if not xbmc.getCondVisibility('!Skin.HasSetting(allowskinupdate)'):
        log("皮肤更新开关[allowskinupdate]未开启，跳过更新检查", xbmc.LOGINFO)
        return
    
    # 原有更新检查逻辑
    log("开始检查皮肤更新...")

    current_ver = get_current_skin_version()
    remote_ver = get_remote_version()

    if not current_ver or not remote_ver:
        return

    log(f"当前版本: {current_ver} | 远程版本: {remote_ver}")

    compare_result = compare_versions(remote_ver, current_ver)

    if compare_result > 0:
        xbmc.executebuiltin('Skin.SetString(skincanupdate,1)')
        log("远程版本更高，设置更新标记")

        dialog = xbmcgui.Dialog()
        options = ["自动更新", "手动更新", "不更新"]
        title = f"发现新版本 (当前: {current_ver} → 最新: {remote_ver})"
        ret = dialog.select(title, options)

        if ret == 0:  # 自动更新
            zip_url = get_latest_zip_url(remote_ver)
            if not zip_url:
                xbmcgui.Dialog().ok("更新失败", "无法构造下载链接，请检查配置")
                return
            
            zip_filename = os.path.basename(zip_url)
            save_path = os.path.join(DOWNLOAD_DIR, zip_filename)

            if download_with_progress(zip_url, save_path):
                log(f"安装包已下载到: {save_path}")

                with tempfile.TemporaryDirectory() as temp_dir:
                    try:
                        with zipfile.ZipFile(save_path, 'r') as zip_ref:
                            zip_ref.extractall(temp_dir)
                        log(f"已解压到临时目录: {temp_dir}")
                    except Exception as e:
                        log(f"解压失败: {e}", xbmc.LOGERROR)
                        xbmcgui.Dialog().ok("更新失败", "解压文件时出错，请手动更新。")
                        return

                    src_skin_dir = temp_dir
                    if not os.path.exists(os.path.join(temp_dir, "addon.xml")):
                        for root, dirs, files in os.walk(temp_dir):
                            if "addon.xml" in files:
                                src_skin_dir = root
                                break
                    log(f"皮肤源目录: {src_skin_dir}")

                    success, failed_files = copy_override(src_skin_dir, SKIN_DIR)

                    if not success:
                        xbmcgui.Dialog().ok("更新失败", f"复制覆盖时发生错误:\n{failed_files[0]}")
                        return
                    if failed_files:
                        fail_msg = "部分文件覆盖失败（可能被占用）:\n" + "\n".join(failed_files[:3])
                        if len(failed_files) > 3:
                            fail_msg += f"\n... 共 {len(failed_files)} 个文件失败"
                        xbmcgui.Dialog().ok("更新警告", fail_msg + "\n建议重启Kodi后重试。")

                refresh_addon_database()
                xbmc.executebuiltin('ReloadSkin()')
                time.sleep(3)

                new_version = get_current_skin_version()
                if new_version == remote_ver:
                    xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')
                    xbmcgui.Dialog().ok("更新成功", f"皮肤已更新到版本 {new_version}！")
                else:
                    xbmcgui.Dialog().ok("更新失败",
                                        f"自动更新未生效，当前版本: {new_version}\n请手动更新或重启Kodi。")

        elif ret == 1:  # 手动更新
            install_from_zip_dialog()

        elif ret == 2:  # 不更新
            log("用户选择不更新")

    else:
        xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')
        log("当前已是最新版本，运行手动更新函数")
        install_from_zip_dialog()


if __name__ == "__main__":
    main()