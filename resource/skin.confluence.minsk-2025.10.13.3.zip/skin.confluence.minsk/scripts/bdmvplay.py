import xbmc
import xbmcgui
import xbmcvfs
import os

class BDMVMonitor:
    def __init__(self):
        self.last_folder = ""
        self.play_flag = False
        self.processing = False
        self.check_settings()  # 初始检测
        xbmc.log("BDMVMonitor: 脚本启动，支持运行时设置检测", xbmc.LOGINFO)

    def check_settings(self):
        """检测皮肤设置，更新启用状态"""
        self.enabled = not xbmc.getCondVisibility("Skin.HasSetting(bdmvplay)")
        if self.enabled:
            xbmc.log("BDMVMonitor: 检测到 bdmvplay 未设置，脚本启用", xbmc.LOGINFO)
        else:
            xbmc.log("BDMVMonitor: 检测到 bdmvplay 已设置，脚本暂停运行", xbmc.LOGINFO)

    def normalize_network_path(self, path):
        """标准化网络路径格式"""
        path = path.replace("\\", "/")
        if path.startswith("nfs:/") and not path.startswith("nfs://"):
            path = "nfs://" + path[4:]
        if path.startswith("smb:/") and not path.startswith("smb://"):
            path = "smb://" + path[4:]
        if path.startswith("webdav:/") and not path.startswith("webdav://"):
            path = "webdav://" + path[7:]
        return path

    def find_index_bdmv(self, folder_path):
        """查找当前目录下的 BDMV/index.bdmv"""
        try:
            if folder_path.startswith(("nfs:", "smb:", "webdav:")):
                local_path = self.normalize_network_path(folder_path)
            else:
                if hasattr(xbmc, 'translatePath'):
                    local_path = xbmc.translatePath(folder_path)
                else:
                    local_path = folder_path

                if local_path.startswith("file://"):
                    local_path = local_path[7:]

                local_path = local_path.replace("\\", "/")

            local_path = local_path.rstrip("/") + "/"

            xbmc.log(f"BDMVMonitor: 待检查目录 = {local_path}", xbmc.LOGINFO)

            if local_path.upper().endswith("BDMV/"):
                index_path = f"{local_path}index.bdmv"
                if xbmcvfs.exists(index_path):
                    return index_path, os.path.dirname(local_path.rstrip("/"))
                return None, None

            dirs, _ = xbmcvfs.listdir(local_path)
            if "BDMV" in dirs:
                index_path = f"{local_path}BDMV/index.bdmv"
                if xbmcvfs.exists(index_path):
                    return index_path, local_path
                return None, None

            return None, None
        except Exception as e:
            xbmc.log(f"BDMVMonitor: 查找index.bdmv出错 - {str(e)}", xbmc.LOGERROR)
            return None, None

    def play_index_bdmv(self, index_path):
        """播放 index.bdmv（支持本地和网络路径）"""
        try:
            if index_path.startswith(("nfs://", "smb://", "webdav://")):
                play_path = index_path
            else:
                play_path = index_path.replace("/", "\\")

            xbmc.log(f"BDMVMonitor: 触发播放 = PlayMedia({play_path})", xbmc.LOGINFO)
            xbmc.executebuiltin(f'PlayMedia("{play_path}", "noresume")')
            self.play_flag = True
        except Exception as e:
            xbmc.log(f"BDMVMonitor: 播放index.bdmv出错 - {str(e)}", xbmc.LOGERROR)
            self.play_flag = False

    def go_back(self):
        """模拟按下返回键"""
        xbmc.log("BDMVMonitor: 发送返回按键信号", xbmc.LOGINFO)
        xbmc.executebuiltin("Action(back)")

    def run(self):
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            # 每次循环都检测设置
            self.check_settings()

            if not self.enabled:
                monitor.waitForAbort(1)
                continue

            current_folder = xbmc.getInfoLabel('Container.FolderPath')

            if current_folder.startswith("sources://"):
                if current_folder != self.last_folder:
                    xbmc.log(f"BDMVMonitor: 跳过虚拟源目录 - {current_folder}", xbmc.LOGINFO)
                    self.last_folder = current_folder
                    self.play_flag = False
                monitor.waitForAbort(1)
                continue

            if current_folder and current_folder != self.last_folder and not self.processing:
                xbmc.log(f"BDMVMonitor: 目录变化 - 从「{self.last_folder}」切换到「{current_folder}」", xbmc.LOGINFO)
                self.last_folder = current_folder
                self.play_flag = False
                self.processing = True

                index_path, parent_path = self.find_index_bdmv(current_folder)
                if index_path:
                    self.go_back()  # 返回上一级
                    monitor.waitForAbort(0.8)  # 等待UI更新
                    self.play_index_bdmv(index_path)
                else:
                    xbmc.log("BDMVMonitor: 未找到BDMV/index.bdmv", xbmc.LOGINFO)

                self.processing = False

            monitor.waitForAbort(1)

if __name__ == '__main__':
    monitor = BDMVMonitor()
    monitor.run()