#!/usr/bin/env python3
import os
import xbmc

# 目标命令（用绝对路径，因为 autostart.sh 环境变量有限）
KODI_SCRIPT_PATH = "/storage/.kodi/addons/skin.confluence.minsk/scripts/skinupdate.py"
AUTOSTART_PATH = "/storage/.config/autostart.sh"

# 要写入的命令行（先切到脚本目录，再用 Kodi 的 python 运行）
command = f"(sleep 5 && kodi-send --action=\"RunScript(special://skin/scripts/skinupdate.py)\") &\n"

def ensure_autostart():
    # 确保 autostart.sh 存在且可执行
    if not os.path.exists(AUTOSTART_PATH):
        with open(AUTOSTART_PATH, "w") as f:
            f.write("#!/bin/sh\n")
        os.chmod(AUTOSTART_PATH, 0o755)

    # 检查是否已经有该命令
    with open(AUTOSTART_PATH, "r") as f:
        lines = f.readlines()

    if any(command.strip() in line.strip() for line in lines):
        print("autostart.sh 已包含运行 skinupdate.py 的指令，无需修改。")
        return

    # 如果没有，则追加命令
    with open(AUTOSTART_PATH, "a") as f:
        f.write("\n# 开机运行皮肤更新脚本\n")
        f.write(command)

    print("已在 autostart.sh 中添加运行 skinupdate.py 的指令。")

    # 立即运行一次 skinupdate.py（使用 Kodi 环境）
    print("立即运行一次 skinupdate.py 脚本...")
    xbmc.executebuiltin('RunScript(special://skin/scripts/skinupdate.py)')

if __name__ == "__main__":
    ensure_autostart()