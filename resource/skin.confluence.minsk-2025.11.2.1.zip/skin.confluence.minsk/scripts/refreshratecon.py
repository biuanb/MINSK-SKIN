import xbmc
import json

# 数字映射到中文
mapping = {
    "0": "关闭",
    "1": "总是",
    "2": "开始/停止播放时",
    "3": "开始播放时"
}

# 全局变量保存当前值
current_value = None

def get_adjust_refresh_rate():
    """通过 JSON-RPC 获取当前设置值"""
    json_query = '''
    {
        "jsonrpc": "2.0",
        "method": "Settings.GetSettingValue",
        "params": {
            "setting": "videoplayer.adjustrefreshrate"
        },
        "id": 1
    }
    '''
    result = xbmc.executeJSONRPC(json_query)
    data = json.loads(result)
    if "result" in data and "value" in data["result"]:
        return str(data["result"]["value"])
    return ""

def update_skin_string(force_update=False):
    """更新皮肤变量（仅当值变化时）"""
    global current_value
    new_value = get_adjust_refresh_rate()
    
    if force_update or new_value != current_value:
        current_value = new_value
        text_value = mapping.get(new_value, f"未知({new_value})")
        xbmc.executebuiltin(f'Skin.SetString(refreshrate,{text_value})')
        xbmc.log(f"刷新率调整设置已更新为: {text_value}", xbmc.LOGINFO)

class SettingMonitor(xbmc.Monitor):
    """监听设置变化"""
    def onSettingsChanged(self):
        # 当任何设置改变时调用
        update_skin_string()

if __name__ == "__main__":
    # 启动时先更新一次
    update_skin_string(force_update=True)

    # 创建监听器并进入等待
    monitor = SettingMonitor()
    xbmc.log("开始精准监听刷新率调整设置变化...", xbmc.LOGINFO)

    # 保持脚本运行直到 Kodi 退出
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break