import os
import sys
import xbmc
import xbmcgui
import xbmcvfs
import re
import xml.etree.ElementTree as ET
from xml.dom import minidom
import threading
import time

# --------------------------
# 配置文件路径
# --------------------------
CONFIG_FILE = xbmcvfs.translatePath("special://userdata/addon_data/skin.confluence.minsk/strm_config.xml")

# --------------------------
# 兼容旧版本Kodi的文件/目录判断函数
# --------------------------
def is_file(path):
    """判断路径是否为文件（兼容旧版本Kodi）"""
    if hasattr(xbmcvfs, 'isfile'):
        return xbmcvfs.isfile(path)
    return xbmcvfs.exists(path) and not path.endswith(('/', '\\'))

def is_dir(path):
    """判断路径是否为目录（兼容旧版本Kodi）"""
    if hasattr(xbmcvfs, 'isdir'):
        return xbmcvfs.isdir(path)
    return xbmcvfs.exists(path) and path.endswith(('/', '\\'))

# --------------------------
# 视频文件扩展名支持函数
# --------------------------
def get_video_extensions():
    """返回支持的视频文件扩展名集合（小写）"""
    return {'.mkv', '.mp4', '.ts', '.m2ts', '.iso'}

# --------------------------
# 配置管理函数
# --------------------------
def init_config():
    """初始化配置文件目录和结构"""
    config_dir = os.path.dirname(CONFIG_FILE)
    if not xbmcvfs.exists(config_dir):
        xbmcvfs.mkdirs(config_dir)
    
    if not xbmcvfs.exists(CONFIG_FILE):
        root = ET.Element("config")
        ET.SubElement(root, "strm_directory").text = ""
        rough_string = ET.tostring(root, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ")
        
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            f.write(pretty_xml)

def get_saved_strm_dir():
    """从配置文件获取保存的STRM目录"""
    init_config()
    try:
        tree = ET.parse(CONFIG_FILE)
        root = tree.getroot()
        dir_elem = root.find('strm_directory')
        return dir_elem.text.strip() if dir_elem is not None else ""
    except Exception as e:
        xbmc.log(f"[STRM同步工具] 读取配置文件失败：{str(e)}", xbmc.LOGERROR)
        return ""

def save_strm_dir(path):
    """保存STRM目录到配置文件"""
    init_config()
    try:
        tree = ET.parse(CONFIG_FILE)
        root = tree.getroot()
        dir_elem = root.find('strm_directory')
        if dir_elem is None:
            dir_elem = ET.SubElement(root, "strm_directory")
        dir_elem.text = path
        
        rough_string = ET.tostring(root, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ")
        lines = [line for line in pretty_xml.split('\n') if line.strip() != '']
        pretty_xml = '\n'.join(lines)
        
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            f.write(pretty_xml)
        return True
    except Exception as e:
        xbmc.log(f"[STRM同步工具] 保存配置文件失败：{str(e)}", xbmc.LOGERROR)
        return False

# --------------------------
# 常量定义（修改）
# --------------------------
def get_target_dir():
    """获取STRM目录（优先使用用户配置）"""
    # 检查是否有保存的目录
    saved_dir = get_saved_strm_dir()
    if saved_dir and xbmcvfs.exists(saved_dir) and is_dir(saved_dir):
        return saved_dir
    
    # 首次使用：询问用户选择目录
    default_path = "/storage/videos" if xbmcvfs.exists("/storage/videos") else "special://home"
    
    # 显示选择对话框
    dialog = xbmcgui.Dialog()
    dialog.ok("首次配置", "请选择STRM文件的保存目录\n该目录将用于存储所有生成的.strm文件")
    
    selected_dir = dialog.browse(
        type=3,
        heading="选择STRM保存目录",
        shares="local",
        defaultt=default_path,
        useThumbs=False,
        treatAsFolder=True,
        mask=""
    )
    
    if not selected_dir or not xbmcvfs.exists(selected_dir) or not is_dir(selected_dir):
        default_dir = xbmcvfs.translatePath("/storage/videos/strm/")
        xbmcvfs.mkdirs(default_dir)
        save_strm_dir(default_dir)
        return default_dir
    
    # 保存用户选择
    save_strm_dir(selected_dir)
    return selected_dir

# 固定STRM目录（根据配置动态获取）
TARGET_DIR = get_target_dir()
DEFAULT_source_path = "/storage/videos/CloudNAS/CloudDrive/"
SOURCE_RECORD_FILE = os.path.join(TARGET_DIR, "source_directories.xml")
PRIORITY_PREFIXES = ['clouddrive', 'cloudnas']  # 不区分大小写匹配
MAX_FILENAME_LENGTH = 100
MAX_FOLDERR_NAME_LENGTH = 90
SIMILAR_PREFIX_LENGTH = 10
MONITOR_CHECK_INTERVAL = 240
FULLSCREEN_CHECK_INTERVAL = 120
monitor_running = False

# --------------------------
# 初始化函数
# --------------------------
def initialize():
    if not xbmcvfs.exists(TARGET_DIR):
        try:
            xbmcvfs.mkdirs(TARGET_DIR)
        except Exception as e:
            xbmc.log(f"[STRM同步工具] 创建STRM根目录失败：{str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("初始化失败", f"无法创建STRM目录：{str(e)}")
            sys.exit(1)
    
    if not xbmcvfs.exists(SOURCE_RECORD_FILE):
        try:
            root = ET.Element("source_directories")
            rough_string = ET.tostring(root, 'utf-8')
            reparsed = minidom.parseString(rough_string)
            pretty_xml = reparsed.toprettyxml(indent="  ")
            
            with open(SOURCE_RECORD_FILE, 'w', encoding='utf-8') as f:
                f.write(pretty_xml)
        except Exception as e:
            xbmc.log(f"[STRM同步工具] 创建源目录XML记录文件失败：{str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("初始化失败", f"无法创建源目录记录文件：{str(e)}")
            sys.exit(1)

# --------------------------
# 源目录管理函数
# --------------------------
def load_source_directories():
    if not xbmcvfs.exists(SOURCE_RECORD_FILE):
        return []
    try:
        tree = ET.parse(SOURCE_RECORD_FILE)
        root = tree.getroot()
        
        sources = []
        for dir_elem in root.findall('directory'):
            path = dir_elem.text.strip() if dir_elem.text else ""
            if path and xbmcvfs.exists(path) and is_dir(path) and path not in sources:
                sources.append(path)
        return sources
    except Exception as e:
        xbmc.log(f"[STRM同步工具] 读取源目录XML记录失败：{str(e)}", xbmc.LOGERROR)
        return []

def add_source_directory(new_dir):
    sources = load_source_directories()
    if new_dir in sources:
        return True, "目录已存在"
    
    if not xbmcvfs.exists(new_dir) or not is_dir(new_dir):
        return False, "目录不存在或不是有效目录"
    
    try:
        tree = ET.parse(SOURCE_RECORD_FILE)
        root = tree.getroot()
        
        dir_elem = ET.SubElement(root, "directory")
        dir_elem.text = new_dir
        dir_elem.tail = "\n  "
        
        rough_string = ET.tostring(root, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ")
        lines = [line for line in pretty_xml.split('\n') if line.strip() != '']
        pretty_xml = '\n'.join(lines)
        
        with open(SOURCE_RECORD_FILE, 'w', encoding='utf-8') as f:
            f.write(pretty_xml)
        
        return True, "添加成功"
    except Exception as e:
        return False, f"添加失败：{str(e)}"

# --------------------------
# 文件名/路径处理函数
# --------------------------
def extract_without_brackets(filename):
    cleaned = re.sub(r'【|】|\[|\]', ' ', filename)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned if cleaned else "未命名文件"

def clean_folder_name(folder_name):
    cleaned = extract_without_brackets(folder_name)
    cleaned = re.sub(r'[^\w\s\u4e00-\u9fa5\.\-]', '', cleaned)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    
    if not cleaned:
        cleaned = "未命名文件夹"
    
    if len(cleaned) > MAX_FOLDERR_NAME_LENGTH:
        cleaned = cleaned[:MAX_FOLDERR_NAME_LENGTH].strip()
        while cleaned.endswith('.'):
            cleaned = cleaned[:-1].strip()
        if not cleaned:
            cleaned = "未命名文件夹"
    
    return cleaned

def clean_and_truncate(filename, max_length):
    base_name = os.path.splitext(filename)[0]
    core_content = extract_without_brackets(base_name)
    safe_content = re.sub(r'[^\w\s\u4e00-\u9fa5\.\-]', '', core_content)
    safe_content = re.sub(r'\s+', ' ', safe_content).strip()
    if not safe_content:
        safe_content = "未命名文件"
    
    original_ext = os.path.splitext(filename)[1].lower()
    valid_exts = get_video_extensions()
    ext_part = original_ext if original_ext in valid_exts else ""
    
    strm_ext = ".strm"
    available_length = max_length - len(ext_part) - len(strm_ext)
    available_length = max(available_length, 1)
    
    truncated_body = safe_content[:available_length] if len(safe_content) > available_length else safe_content
    final_name = f"{truncated_body}{ext_part}{strm_ext}"
    
    if len(final_name) > max_length:
        final_name = final_name[:max_length - len(strm_ext)] + strm_ext
    
    if final_name.startswith('.'):
        final_name = f"视频{final_name}"
        if len(final_name) > max_length:
            final_name = final_name[:max_length - len(strm_ext)] + strm_ext
    
    return final_name

# --------------------------
# STRM文件处理函数
# --------------------------
def find_similar_strm_files(target_dir, target_filename):
    if not xbmcvfs.exists(target_dir) or not is_dir(target_dir):
        return []
    
    similar_files = []
    target_base = os.path.splitext(target_filename)[0]
    target_prefix = target_base[:SIMILAR_PREFIX_LENGTH].lower()
    
    if not target_dir.startswith(('smb://', 'nfs://', 'dav://')):
        try:
            for filename in os.listdir(target_dir):
                if filename.lower().endswith('.strm') and filename != target_filename:
                    file_base = os.path.splitext(filename)[0]
                    file_prefix = file_base[:SIMILAR_PREFIX_LENGTH].lower()
                    if file_prefix == target_prefix:
                        similar_files.append(os.path.join(target_dir, filename))
        except Exception as e:
            xbmc.log(f"[STRM同步工具] 遍历目录失败：{str(e)}", xbmc.LOGERROR)
    
    return similar_files

def get_strm_content(strm_path):
    try:
        if strm_path.startswith(('smb://', 'nfs://', 'dav://')):
            f = xbmcvfs.File(strm_path, 'r')
            content = f.read().strip()
            f.close()
        else:
            with open(strm_path, 'r', encoding='utf-8') as f:
                content = f.readline().strip()
        return content
    except Exception as e:
        xbmc.log(f"[STRM同步工具] 读取STRM失败：{str(e)}", xbmc.LOGERROR)
        return None

def remove_duplicate_strm_files(target_path):
    if not xbmcvfs.exists(target_path) or not is_file(target_path):
        return 0
    
    if target_path.startswith(('smb://', 'nfs://', 'dav://')):
        return 0
    
    target_dir = os.path.dirname(target_path)
    target_filename = os.path.basename(target_path)
    similar_files = find_similar_strm_files(target_dir, target_filename)
    
    if not similar_files:
        return 0
    
    target_content = get_strm_content(target_path)
    if not target_content:
        return 0
    
    target_mtime = os.path.getmtime(target_path)
    deleted_count = 0
    
    for file_path in similar_files:
        file_content = get_strm_content(file_path)
        if file_content == target_content:
            file_mtime = os.path.getmtime(file_path)
            if file_mtime < target_mtime:
                try:
                    os.remove(file_path)
                    deleted_count += 1
                except Exception as e:
                    xbmc.log(f"[STRM同步工具] 删除重复文件失败：{str(e)}", xbmc.LOGERROR)
    
    if deleted_count > 0:
        delete_empty_dirs(target_dir)
    
    return deleted_count

# --------------------------
# 核心处理函数（修改）
# --------------------------
def process_single_item(item_path, progress=None):
    if not item_path or not xbmcvfs.exists(item_path):
        return (0, 0, 0, 0, [f"项目不存在：{item_path}"])
    
    source_dirs = load_source_directories()
    base_source = None
    for src_dir in source_dirs:
        if item_path.startswith(src_dir):
            base_source = src_dir
            break
    
    if not base_source:
        base_source = os.path.dirname(item_path) if is_file(item_path) else item_path
        add_source_directory(base_source)
    
    video_extensions = get_video_extensions()
    new_count = 0
    updated_count = 0
    deleted_duplicates = 0
    deleted_obsolete = 0
    error_list = []
    existing_strm = collect_existing_strm(include_mtime=True)
    
    try:
        if is_dir(item_path):
            has_bdmv = False
            if item_path.startswith(('smb://', 'nfs://', 'dav://')):
                dirs, _ = xbmcvfs.listdir(item_path)
                has_bdmv = any(dir_name.lower() == 'bdmv' for dir_name in dirs)
            else:
                has_bdmv = any(dir_name.lower() == 'bdmv' for dir_name in os.listdir(item_path) 
                              if is_dir(os.path.join(item_path, dir_name)))
            
            if has_bdmv:
                rel_path = xbmcvfs.makeLegalFilename(os.path.relpath(item_path, base_source))
                item_key = f"bdmv_{rel_path}_{base_source}"
                folder_name = os.path.basename(item_path)
                
                if item_path.startswith(('smb://', 'nfs://', 'dav://')):
                    is_new = item_key not in existing_strm
                else:
                    folder_mtime = os.path.getmtime(item_path)
                    is_new = item_key not in existing_strm
                    if not is_new:
                        strm_path, strm_mtime = existing_strm[item_key]
                        if folder_mtime <= strm_mtime:
                            return (0, 0, 0, 0, [])
                
                if progress:
                    progress.update(50, f"处理BDMV：{folder_name}")
                success, result = create_strm_file("bdmv", item_path, folder_name, base_source)
                if success:
                    new_count += 1 if is_new else 0
                    updated_count += 0 if is_new else 1
                    deleted = remove_duplicate_strm_files(result)
                    deleted_duplicates += deleted
                else:
                    error_list.append(f"BDMV {folder_name}：{result}")
                
                return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list)
            
            source_keys = set()
            if item_path.startswith(('smb://', 'nfs://', 'dav://')):
                from queue import Queue
                dir_queue = Queue()
                dir_queue.put(item_path)
                
                while not dir_queue.empty() and (not progress or not progress.iscanceled()):
                    current_dir = dir_queue.get()
                    dirs, files = xbmcvfs.listdir(current_dir)
                    
                    bdmv_dirs = [d for d in dirs if d.lower() == 'bdmv']
                    if bdmv_dirs:
                        bdmv_path = os.path.join(current_dir, bdmv_dirs[0])
                        parent_folder = os.path.dirname(bdmv_path)
                        rel_path = xbmcvfs.makeLegalFilename(os.path.relpath(parent_folder, base_source))
                        item_key = f"bdmv_{rel_path}_{base_source}"
                        source_keys.add(item_key)
                        
                        folder_name = os.path.basename(parent_folder)
                        is_new = item_key not in existing_strm
                        
                        if progress:
                            progress.update(0, f"处理BDMV：{folder_name}")
                        success, result = create_strm_file("bdmv", parent_folder, folder_name, base_source)
                        if success:
                            new_count += 1 if is_new else 0
                            updated_count += 0 if is_new else 1
                            deleted_duplicates += remove_duplicate_strm_files(result)
                        else:
                            error_list.append(f"BDMV {folder_name}：{result}")
                        
                        continue
                    
                    for file in files:
                        file_ext = os.path.splitext(file)[1].lower()
                        if file_ext in video_extensions:
                            file_path = os.path.join(current_dir, file)
                            rel_path = xbmcvfs.makeLegalFilename(os.path.relpath(file_path, base_source))
                            item_key = f"video_{rel_path}_{base_source}"
                            source_keys.add(item_key)
                            
                            is_new = item_key not in existing_strm
                            
                            if progress:
                                progress.update(0, f"处理文件：{file}")
                            success, result = create_strm_file("video", file_path, file, base_source)
                            if success:
                                new_count += 1 if is_new else 0
                                updated_count += 0 if is_new else 1
                                deleted_duplicates += remove_duplicate_strm_files(result)
                            else:
                                error_list.append(f"视频 {file}：{result}")
                    
                    for dir_name in dirs:
                        if dir_name.lower() != 'bdmv':
                            dir_queue.put(os.path.join(current_dir, dir_name))
            else:
                for root, dirs, files in os.walk(item_path):
                    bdmv_dirs = [d for d in dirs if d.lower() == 'bdmv']
                    if bdmv_dirs:
                        bdmv_path = os.path.join(root, bdmv_dirs[0])
                        parent_folder = os.path.dirname(bdmv_path)
                        rel_path = os.path.relpath(parent_folder, base_source)
                        item_key = f"bdmv_{rel_path}_{base_source}"
                        source_keys.add(item_key)
                        
                        folder_name = os.path.basename(parent_folder)
                        folder_mtime = os.path.getmtime(parent_folder)
                        is_new = item_key not in existing_strm
                        
                        if not is_new:
                            strm_path, strm_mtime = existing_strm[item_key]
                            if folder_mtime <= strm_mtime:
                                dirs[:] = []
                                continue
                        
                        if progress:
                            progress.update(0, f"处理BDMV：{folder_name}")
                        success, result = create_strm_file("bdmv", parent_folder, folder_name, base_source)
                        if success:
                            new_count += 1 if is_new else 0
                            updated_count += 0 if is_new else 1
                            deleted_duplicates += remove_duplicate_strm_files(result)
                        else:
                            error_list.append(f"BDMV {folder_name}：{result}")
                        
                        dirs[:] = []
                        continue
                    
                    for file in files:
                        file_ext = os.path.splitext(file)[1].lower()
                        if file_ext in video_extensions:
                            file_path = os.path.join(root, file)
                            rel_path = os.path.relpath(file_path, base_source)
                            item_key = f"video_{rel_path}_{base_source}"
                            source_keys.add(item_key)
                            
                            try:
                                file_mtime = os.path.getmtime(file_path)
                                is_new = item_key not in existing_strm
                                
                                if not is_new:
                                    strm_path, strm_mtime = existing_strm[item_key]
                                    if file_mtime <= strm_mtime:
                                        continue
                                
                                if progress:
                                    progress.update(0, f"处理文件：{file}")
                                success, result = create_strm_file("video", file_path, file, base_source)
                                if success:
                                    new_count += 1 if is_new else 0
                                    updated_count += 0 if is_new else 1
                                    deleted_duplicates += remove_duplicate_strm_files(result)
                                else:
                                    error_list.append(f"视频 {file}：{result}")
                            except Exception as e:
                                error_list.append(f"获取{file}信息失败：{str(e)}")
                
                if progress and progress.iscanceled():
                    error_list.append("操作已取消")
                    return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list)
            
            for item_key in existing_strm:
                if item_key.endswith(f"_{base_source}") and item_key not in source_keys:
                    strm_path = existing_strm[item_key][0] if isinstance(existing_strm[item_key], tuple) else existing_strm[item_key]
                    try:
                        if xbmcvfs.exists(strm_path):
                            xbmcvfs.delete(strm_path)
                            deleted_obsolete += 1
                    except Exception as e:
                        error_list.append(f"删除过时文件失败：{str(e)}")
            
            delete_empty_dirs(TARGET_DIR)
        
        elif is_file(item_path):
            file_ext = os.path.splitext(item_path)[1].lower()
            if file_ext in video_extensions:
                rel_path = xbmcvfs.makeLegalFilename(os.path.relpath(item_path, base_source))
                item_key = f"video_{rel_path}_{base_source}"
                source_keys = {item_key}
                
                try:
                    is_new = item_key not in existing_strm
                    if not item_path.startswith(('smb://', 'nfs://', 'dav://')):
                        file_mtime = os.path.getmtime(item_path)
                        if not is_new:
                            strm_path, strm_mtime = existing_strm[item_key]
                            if file_mtime <= strm_mtime:
                                return (0, 0, 0, 0, [])
                    
                    file_name = os.path.basename(item_path)
                    if progress:
                        progress.update(50, f"处理文件：{file_name}")
                    success, result = create_strm_file("video", item_path, file_name, base_source)
                    if success:
                        new_count += 1 if is_new else 0
                        updated_count += 0 if is_new else 1
                        deleted_duplicates += remove_duplicate_strm_files(result)
                    else:
                        error_list.append(f"视频 {file_name}：{result}")
                except Exception as e:
                    error_list.append(f"处理文件失败：{str(e)}")
                
                for item_key in existing_strm:
                    if item_key.endswith(f"_{base_source}") and item_key not in source_keys:
                        strm_path = existing_strm[item_key][0] if isinstance(existing_strm[item_key], tuple) else existing_strm[item_key]
                        try:
                            if xbmcvfs.exists(strm_path):
                                xbmcvfs.delete(strm_path)
                                deleted_obsolete += 1
                        except Exception as e:
                            error_list.append(f"删除过时文件失败：{str(e)}")
                
                delete_empty_dirs(TARGET_DIR)
            else:
                error_list.append(f"不支持的文件格式：{os.path.basename(item_path)}")
    
    except Exception as e:
        error_msg = f"处理出错：{str(e)}"
        error_list.append(error_msg)
        xbmc.log(f"[STRM同步工具] 处理异常：{error_msg}", xbmc.LOGERROR)
    
    return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list)

def collect_existing_strm(include_mtime=False):
    existing_strm = {}
    if not xbmcvfs.exists(TARGET_DIR) or not is_dir(TARGET_DIR):
        return existing_strm
    
    if not TARGET_DIR.startswith(('smb://', 'nfs://', 'dav://')):
        for root, _, files in os.walk(TARGET_DIR):
            for file in files:
                if file.lower().endswith('.strm'):
                    strm_path = os.path.join(root, file)
                    try:
                        with open(strm_path, 'r', encoding='utf-8') as f:
                            source_path = f.readline().strip()
                        
                        source_dirs = load_source_directories()
                        base_source = None
                        for src_dir in source_dirs:
                            if source_path.startswith(src_dir):
                                base_source = src_dir
                                break
                        if not base_source:
                            continue
                        
                        if 'BDMV/index.bdmv' in source_path:
                            bdmv_folder = os.path.dirname(os.path.dirname(source_path))
                            rel_path = os.path.relpath(bdmv_folder, base_source)
                            item_key = f"bdmv_{rel_path}_{base_source}"
                        else:
                            rel_path = os.path.relpath(source_path, base_source)
                            item_key = f"video_{rel_path}_{base_source}"
                        
                        if include_mtime:
                            strm_mtime = os.path.getmtime(strm_path)
                            existing_strm[item_key] = (strm_path, strm_mtime)
                        else:
                            existing_strm[item_key] = strm_path
                    except Exception as e:
                        xbmc.log(f"[STRM同步工具] 处理STRM失败：{str(e)}", xbmc.LOGERROR)
    
    return existing_strm

def create_strm_file(item_type, source_path, name, source_dir):
    try:
        if item_type == "bdmv":
            strm_content = os.path.join(source_path, "BDMV", "index.bdmv")
            original_filename = name
        else:
            strm_content = source_path
            original_filename = name
        
        strm_content = xbmcvfs.makeLegalFilename(strm_content)
        strm_filename = clean_and_truncate(original_filename, MAX_FILENAME_LENGTH)
        
        # 确定完整源目录路径
        full_source_dir = os.path.dirname(source_path) if item_type == "video" else source_path
        
        # 提取路径部分并标准化分隔符
        if full_source_dir.startswith(('smb://', 'nfs://', 'dav://')):
            # 处理网络路径（使用'/'作为分隔符）
            path_parts = [part for part in full_source_dir.split('/') if part.strip()]
            # 保留协议部分（如smb://）
            protocol = []
            if path_parts and (path_parts[0].endswith('://')):
                protocol = path_parts[:1]
                path_parts = path_parts[1:]
        else:
            # 处理本地路径
            path_parts = [part for part in full_source_dir.split(os.sep) if part.strip()]
            protocol = []
        
        target_parts = []
        found_truncate_index = -1
        
        # 优先查找clouddrive（不区分大小写）
        for i, part in enumerate(path_parts):
            if part.lower() == PRIORITY_PREFIXES[0]:  # 'clouddrive'
                found_truncate_index = i
                break
        
        # 如果没找到clouddrive，查找cloudnas（不区分大小写）
        if found_truncate_index == -1:
            for i, part in enumerate(path_parts):
                if part.lower() == PRIORITY_PREFIXES[1]:  # 'cloudnas'
                    found_truncate_index = i
                    break
        
        # 根据找到的关键词调整路径部分
        if found_truncate_index != -1:
            # 保留关键词及后续部分
            for part in path_parts[found_truncate_index:]:
                cleaned_part = clean_folder_name(part)
                if cleaned_part:
                    target_parts.append(cleaned_part)
        else:
            # 未找到关键词，使用源目录相对路径
            source_dir_parts = [clean_folder_name(part) for part in source_dir.split(os.sep) if part.strip()]
            source_dir_parts = [p for p in source_dir_parts if p]
            if len(path_parts) >= len(source_dir_parts) and path_parts[:len(source_dir_parts)] == source_dir_parts:
                target_parts = path_parts[len(source_dir_parts):]
            else:
                target_parts = path_parts
        
        # 构建最终目标目录
        final_target_dir = TARGET_DIR
        if target_parts:
            # 合并协议部分（如果有）和处理后的路径部分
            combined_parts = protocol + target_parts
            final_target_dir = os.path.join(TARGET_DIR, os.sep.join(combined_parts))
        
        # 创建目录（如果不存在）
        if not xbmcvfs.exists(final_target_dir):
            xbmcvfs.mkdirs(final_target_dir)
        
        # 处理BDMV目录
        if item_type == "bdmv":
            bdmv_empty_dir = os.path.join(final_target_dir, "BDMV")
            if not xbmcvfs.exists(bdmv_empty_dir):
                xbmcvfs.mkdirs(bdmv_empty_dir)
                protection_file = os.path.join(bdmv_empty_dir, ".keep")
                with open(protection_file, 'w', encoding='utf-8') as f:
                    f.write("This file keeps the BDMV directory from being deleted")
        
        # 生成STRM文件路径
        strm_path = os.path.join(final_target_dir, strm_filename)
        
        # 不支持在网络路径创建STRM文件
        if strm_path.startswith(('smb://', 'nfs://', 'dav://')):
            raise Exception("不支持在网络路径创建STRM文件")
        
        # 写入STRM内容
        with open(strm_path, 'w', encoding='utf-8') as f:
            f.write(strm_content)
        
        # 检查文件是否为空
        if os.path.getsize(strm_path) == 0:
            raise Exception("STRM文件为空")
        
        return True, strm_path
    except Exception as e:
        return False, f"{str(e)}"

def delete_empty_dirs(root_dir):
    if not xbmcvfs.exists(root_dir) or not is_dir(root_dir):
        return
    
    if root_dir.startswith(('smb://', 'nfs://', 'dav://')):
        return
    
    for dir_name in os.listdir(root_dir):
        dir_path = os.path.join(root_dir, dir_name)
        if is_dir(dir_path):
            delete_empty_dirs(dir_path)
    
    try:
        if not os.listdir(root_dir):
            os.rmdir(root_dir)
    except Exception as e:
        xbmc.log(f"[STRM同步工具] 删除空目录失败：{str(e)}", xbmc.LOGERROR)

# --------------------------
# 同步与监控函数
# --------------------------
def sync_selected_source(selected_dirs):
    total_new = 0
    total_updated = 0
    total_duplicates = 0
    total_obsolete = 0
    total_errors = []
    progress = xbmcgui.DialogProgress()
    progress.create("同步目录", "准备同步...")
    
    try:
        for i, src_dir in enumerate(selected_dirs):
            src_name = get_display_name(src_dir)
            progress.update(int(i/len(selected_dirs)*100), f"处理目录：{src_name}")
            new_count, updated_count, duplicates, deleted_obsolete, errors, _ = process_source_directory(src_dir, progress)
            total_new += new_count
            total_updated += updated_count
            total_duplicates += duplicates
            total_obsolete += deleted_obsolete
            total_errors.extend(errors)
            
            if progress.iscanceled():
                break
        
        if progress.iscanceled():
            xbmcgui.Dialog().ok("同步取消", "同步已终止")
            return
    
    finally:
        progress.close()
    
    result_msg = [
        f"同步目录数量：{len(selected_dirs)}",
        f"新增STRM文件：{total_new} 个",
        f"更新STRM文件：{total_updated} 个",
        f"删除过时文件：{total_obsolete} 个",
        f"删除重复文件：{total_duplicates} 个"
    ]
    
    if total_errors:
        result_msg.append(f"\n错误 ({len(total_errors)})：")
        for err in total_errors[:5]:
            result_msg.append(f"- {err}")
        if len(total_errors) > 5:
            result_msg.append(f"- 还有 {len(total_errors)-5} 个错误")
    
    xbmcgui.Dialog().ok("同步完成", "\n".join(result_msg))

def get_display_name(source_dir):
    path_parts = [part for part in source_dir.split(os.sep) if part]
    display_parts = []
    found_truncate_index = -1
    
    for i, part in enumerate(path_parts):
        part_lower = part.lower()
        for prefix in PRIORITY_PREFIXES:
            if part_lower == prefix:
                found_truncate_index = i
                break
    
    if found_truncate_index != -1:
        display_parts = path_parts[found_truncate_index + 1:]
    else:
        display_parts = path_parts[-2:] if len(path_parts) >= 2 else path_parts
    
    return os.sep.join(display_parts)

def add_source_and_sync():
    default_path = DEFAULT_source_path
    if not xbmcvfs.exists(default_path) or not is_dir(default_path):
        default_path = "/storage"
    
    new_source = select_directory("选择视频源目录", default_path)
    if not new_source:
        xbmcgui.Dialog().ok("操作取消", "未选择有效的源目录")
        return
    
    success, msg = add_source_directory(new_source)
    if not success:
        xbmcgui.Dialog().ok("操作失败", msg)
        return
    
    progress = xbmcgui.DialogProgress()
    progress.create("同步目录", f"处理：{get_display_name(new_source)}\n{msg}")
    
    try:
        new_count, updated_count, duplicates, deleted_obsolete, error_list, _ = process_source_directory(new_source, progress)
        delete_empty_dirs(TARGET_DIR)
    
    finally:
        progress.close()
    
    result_msg = [
        f"源目录：{get_display_name(new_source)}",
        f"{msg}",
        f"新增STRM文件：{new_count} 个",
        f"更新STRM文件：{updated_count} 个",
        f"删除过时文件：{deleted_obsolete} 个",
        f"删除重复文件：{duplicates} 个"
    ]
    
    if error_list:
        result_msg.append(f"\n错误 ({len(error_list)})：")
        for err in error_list[:5]:
            result_msg.append(f"- {err}")
        if len(error_list) > 5:
            result_msg.append(f"- 还有 {len(error_list)-5} 个错误")
    
    xbmcgui.Dialog().ok("同步完成", "\n".join(result_msg))
    open_strm_in_kodi()

def delete_all_strm():
    if not xbmcvfs.exists(TARGET_DIR):
        xbmcgui.Dialog().ok("提示", "STRM目录不存在")
        return
    
    confirm = xbmcgui.Dialog().yesno(
        "警告",
        f"确定删除 {TARGET_DIR} 下所有内容？\n包括所有STRM文件、子目录（含非空BDMV文件夹）！\n源目录记录文件将被保留。"
    )
    if not confirm:
        return
    
    # 统计所有文件（包括子目录中的文件）
    total_files = 0
    if not TARGET_DIR.startswith(('smb://', 'nfs://', 'dav://')):
        for root, _, files in os.walk(TARGET_DIR):
            # 排除source_directories.xml
            files = [f for f in files if f != "source_directories.xml"]
            total_files += len(files)
    
    progress = xbmcgui.DialogProgress()
    progress.create("删除所有内容", "正在处理...")
    file_count = 0
    
    try:
        if not TARGET_DIR.startswith(('smb://', 'nfs://', 'dav://')):
            # 先删除所有文件（包括BDMV目录下的文件）
            for root, dirs, files in os.walk(TARGET_DIR, topdown=False):
                # 排除source_directories.xml
                files = [f for f in files if f != "source_directories.xml"]
                
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        os.remove(file_path)
                        file_count += 1
                        progress.update(int(file_count/total_files*100) if total_files > 0 else 100, f"删除：{file}")
                    except Exception as e:
                        xbmc.log(f"[STRM同步工具] 删除文件失败：{str(e)}", xbmc.LOGERROR)
                    
                    if progress.iscanceled():
                        progress.close()
                        xbmcgui.Dialog().ok("操作取消", "部分文件已删除")
                        return
            
            # 再删除所有空目录（包括BDMV目录）
            for root, dirs, files in os.walk(TARGET_DIR, topdown=False):
                for dir_name in dirs:
                    dir_path = os.path.join(root, dir_name)
                    try:
                        if not os.listdir(dir_path):
                            os.rmdir(dir_path)
                    except Exception as e:
                        xbmc.log(f"[STRM同步工具] 删除目录失败：{str(e)}", xbmc.LOGERROR)
        
        progress.close()
        
        # 清空源目录记录但保留文件
        with open(SOURCE_RECORD_FILE, 'w', encoding='utf-8') as f:
            f.write('<?xml version="1.0" ?>\n<source_directories>\n</source_directories>')
        
        xbmcgui.Dialog().ok("删除完成", f"共删除 {file_count} 个文件和所有空目录\n源目录记录已清空（文件保留）")
    
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok("删除失败", f"错误：{str(e)}")

def process_source_directory(source_dir, progress=None):
    if not xbmcvfs.exists(source_dir) or not is_dir(source_dir):
        return (0, 0, 0, 0, [f"源目录无效：{source_dir}"], set())
    
    video_extensions = get_video_extensions()
    new_count = 0
    updated_count = 0
    deleted_duplicates = 0
    deleted_obsolete = 0
    error_list = []
    source_keys = set()
    existing_strm = collect_existing_strm(include_mtime=True)
    
    try:
        if source_dir.startswith(('smb://', 'nfs://', 'dav://')):
            from queue import Queue
            dir_queue = Queue()
            dir_queue.put(source_dir)
            
            while not dir_queue.empty() and (not progress or not progress.iscanceled()):
                current_dir = dir_queue.get()
                dirs, files = xbmcvfs.listdir(current_dir)
                
                bdmv_dirs = [d for d in dirs if d.lower() == 'bdmv']
                if bdmv_dirs:
                    bdmv_path = os.path.join(current_dir, bdmv_dirs[0])
                    parent_folder = os.path.dirname(bdmv_path)
                    rel_path = xbmcvfs.makeLegalFilename(os.path.relpath(parent_folder, source_dir))
                    item_key = f"bdmv_{rel_path}_{source_dir}"
                    source_keys.add(item_key)
                    
                    folder_name = os.path.basename(parent_folder)
                    is_new = item_key not in existing_strm
                    
                    if progress:
                        progress.update(0, f"处理BDMV：{folder_name}")
                    success, result = create_strm_file("bdmv", parent_folder, folder_name, source_dir)
                    if success:
                        new_count += 1 if is_new else 0
                        updated_count += 0 if is_new else 1
                        deleted_duplicates += remove_duplicate_strm_files(result)
                    else:
                        error_list.append(f"BDMV {folder_name}：{result}")
                    
                    continue
                
                for file in files:
                    file_ext = os.path.splitext(file)[1].lower()
                    if file_ext in video_extensions:
                        file_path = os.path.join(current_dir, file)
                        rel_path = xbmcvfs.makeLegalFilename(os.path.relpath(file_path, source_dir))
                        item_key = f"video_{rel_path}_{source_dir}"
                        source_keys.add(item_key)
                        
                        is_new = item_key not in existing_strm
                        
                        if progress:
                            progress.update(0, f"处理文件：{file}")
                        success, result = create_strm_file("video", file_path, file, source_dir)
                        if success:
                            new_count += 1 if is_new else 0
                            updated_count += 0 if is_new else 1
                            deleted_duplicates += remove_duplicate_strm_files(result)
                        else:
                            error_list.append(f"视频 {file}：{result}")
                
                for dir_name in dirs:
                    if dir_name.lower() != 'bdmv':
                        dir_queue.put(os.path.join(current_dir, dir_name))
        else:
            for root, dirs, files in os.walk(source_dir):
                bdmv_dirs = [d for d in dirs if d.lower() == 'bdmv']
                if bdmv_dirs:
                    bdmv_path = os.path.join(root, bdmv_dirs[0])
                    parent_folder = os.path.dirname(bdmv_path)
                    rel_path = os.path.relpath(parent_folder, source_dir)
                    item_key = f"bdmv_{rel_path}_{source_dir}"
                    source_keys.add(item_key)
                    
                    folder_name = os.path.basename(parent_folder)
                    folder_mtime = os.path.getmtime(parent_folder)
                    is_new = item_key not in existing_strm
                    
                    if not is_new:
                        strm_path, strm_mtime = existing_strm[item_key]
                        if folder_mtime <= strm_mtime:
                            dirs[:] = []
                            continue
                    
                    if progress:
                        progress.update(0, f"处理BDMV：{folder_name}")
                    success, result = create_strm_file("bdmv", parent_folder, folder_name, source_dir)
                    if success:
                        new_count += 1 if is_new else 0
                        updated_count += 0 if is_new else 1
                        deleted_duplicates += remove_duplicate_strm_files(result)
                    else:
                        error_list.append(f"BDMV {folder_name}：{result}")
                    
                    dirs[:] = []
                    continue
                
                for file in files:
                    file_ext = os.path.splitext(file)[1].lower()
                    if file_ext in video_extensions:
                        file_path = os.path.join(root, file)
                        rel_path = os.path.relpath(file_path, source_dir)
                        item_key = f"video_{rel_path}_{source_dir}"
                        source_keys.add(item_key)
                        
                        try:
                            file_mtime = os.path.getmtime(file_path)
                            is_new = item_key not in existing_strm
                            
                            if not is_new:
                                strm_path, strm_mtime = existing_strm[item_key]
                                if file_mtime <= strm_mtime:
                                    continue
                            
                            if progress:
                                progress.update(0, f"处理文件：{file}")
                            success, result = create_strm_file("video", file_path, file, source_dir)
                            if success:
                                new_count += 1 if is_new else 0
                                updated_count += 0 if is_new else 1
                                deleted_duplicates += remove_duplicate_strm_files(result)
                            else:
                                error_list.append(f"视频 {file}：{result}")
                        except Exception as e:
                            error_list.append(f"获取{file}信息失败：{str(e)}")
                
                if progress and progress.iscanceled():
                    error_list.append("操作已取消")
                    return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list, source_keys)
        
        for item_key in existing_strm:
            if item_key.endswith(f"_{source_dir}") and item_key not in source_keys:
                strm_path = existing_strm[item_key][0] if isinstance(existing_strm[item_key], tuple) else existing_strm[item_key]
                try:
                    if xbmcvfs.exists(strm_path):
                        xbmcvfs.delete(strm_path)
                        deleted_obsolete += 1
                except Exception as e:
                    error_list.append(f"删除过时文件失败：{str(e)}")
        
        delete_empty_dirs(TARGET_DIR)
    
    except Exception as e:
        error_msg = f"扫描目录出错：{str(e)}"
        error_list.append(error_msg)
        xbmc.log(f"[STRM同步工具] 扫描异常：{error_msg}", xbmc.LOGERROR)
    
    return (new_count, updated_count, deleted_duplicates, deleted_obsolete, error_list, source_keys)

# --------------------------
# 菜单与交互函数
# --------------------------
def show_manual_sync_menu():
    options = [
        "添加源目录生成strm文件",
        "选择同步源目录",
        "删除所有strm文件及记录"
    ]
    return xbmcgui.Dialog().select("手动同步模式选择", options)

def show_source_selection_menu():
    source_dirs = load_source_directories()
    if not source_dirs:
        xbmcgui.Dialog().ok("同步失败", "未找到源目录，请先添加源目录")
        return None
    
    options = ["所有文件夹"]
    options.extend([get_display_name(dir) for dir in source_dirs])
    
    selected = xbmcgui.Dialog().select("选择要同步的目录", options)
    if selected == -1:
        return None
    
    if selected == 0:
        return source_dirs
    else:
        return [source_dirs[selected - 1]]

def select_directory(title, default_path):
    result = xbmcgui.Dialog().browse(
        type=3,
        heading=title,
        shares="all",
        defaultt=default_path,
        useThumbs=False,
        treatAsFolder=True,
        mask=""
    )
    if not result or result == default_path:
        return None
    return result

def open_strm_in_kodi():
    if xbmcvfs.exists(TARGET_DIR) and is_dir(TARGET_DIR):
        xbmc.executebuiltin(f'ActivateWindow(Videos, "{TARGET_DIR}", return)')
    else:
        xbmcgui.Dialog().ok("打开失败", "STRM目录不存在")

def auto_mode():
    source_dirs = load_source_directories()
    strm_exists = xbmcvfs.exists(TARGET_DIR) and is_dir(TARGET_DIR)
    strm_empty = True
    
    if strm_exists and not TARGET_DIR.startswith(('smb://', 'nfs://', 'dav://')):
        for _, _, files in os.walk(TARGET_DIR):
            if any(f.lower().endswith('.strm') for f in files):
                strm_empty = False
                break
    
    if not source_dirs or (strm_exists and strm_empty):
        confirm = xbmcgui.Dialog().yesno(
            "未找到有效数据",
            "是否添加源目录并生成STRM文件？"
        )
        if confirm:
            add_source_and_sync()
    else:
        open_strm_in_kodi()

def handle_addstrm():
    item_path = xbmc.getInfoLabel('ListItem.FolderPath')
    if not item_path or item_path == "":
        item_path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    
    if item_path.startswith('special://'):
        item_path = xbmc.translatePath(item_path)
    
    if not item_path or not xbmcvfs.exists(item_path):
        xbmcgui.Dialog().ok("错误", "未找到选中的项目或项目不存在")
        return
    
    progress = xbmcgui.DialogProgress()
    progress.create("生成STRM文件", f"正在处理：{os.path.basename(item_path)}")
    
    try:
        new_count, updated_count, deleted_duplicates, deleted_obsolete, errors = process_single_item(item_path, progress)
    finally:
        progress.close()
    
    result_msg = [
        f"处理项目：{os.path.basename(item_path)}",
        f"新增STRM文件：{new_count} 个",
        f"更新STRM文件：{updated_count} 个",
        f"删除重复文件：{deleted_duplicates} 个",
        f"删除过时文件：{deleted_obsolete} 个"
    ]
    
    if errors:
        result_msg.append(f"\n错误 ({len(errors)})：")
        for err in errors[:5]:
            result_msg.append(f"- {err}")
        if len(errors) > 5:
            result_msg.append(f"- 还有 {len(errors)-5} 个错误")
    
    xbmcgui.Dialog().ok("处理完成", "\n".join(result_msg))

def is_fullscreen_video_playing():
    return xbmc.getCondVisibility("Window.IsVisible(FullscreenVideo)")

def monitor_directory_changes():
    global monitor_running
    while monitor_running:
        if is_fullscreen_video_playing():
            wait_time = 0
            while wait_time < FULLSCREEN_CHECK_INTERVAL and monitor_running and is_fullscreen_video_playing():
                time.sleep(1)
                wait_time += 1
            continue
        
        source_dirs = load_source_directories()
        if not source_dirs:
            time.sleep(MONITOR_CHECK_INTERVAL)
            continue
        
        for src_dir in source_dirs:
            if not monitor_running:
                break
                
            if not xbmcvfs.exists(src_dir) or not is_dir(src_dir):
                xbmc.log(f"[STRM同步工具] 源目录无效：{src_dir}", xbmc.LOGERROR)
                continue
                
            new_count, updated_count, duplicates, deleted_obsolete, errors, _ = process_source_directory(src_dir)
        
        wait_time = 0
        while wait_time < MONITOR_CHECK_INTERVAL and monitor_running and not is_fullscreen_video_playing():
            time.sleep(1)
            wait_time += 1

def start_monitor_mode():
    global monitor_running
    if monitor_running:
        return
    
    monitor_running = True
    monitor_thread = threading.Thread(target=monitor_directory_changes, daemon=True)
    monitor_thread.start()

def stop_monitor_mode():
    global monitor_running
    if not monitor_running:
        return
    
    monitor_running = False

# --------------------------
# 主函数
# --------------------------
def main():
    initialize()
    args = sys.argv[1:] if len(sys.argv) > 1 else []
    
    if "addstrm" in args:
        handle_addstrm()
        return
    
    if "monitor" in args:
        if monitor_running:
            stop_monitor_mode()
        else:
            start_monitor_mode()
        return
    
    if "manualsync" in args:
        selected = show_manual_sync_menu()
        if selected == 0:
            add_source_and_sync()
        elif selected == 1:
            selected_dirs = show_source_selection_menu()
            if selected_dirs is not None and len(selected_dirs) > 0:
                sync_selected_source(selected_dirs)
                open_strm_in_kodi()
        elif selected == 2:
            delete_all_strm()
    else:
        auto_mode()

if __name__ == '__main__':
    main()