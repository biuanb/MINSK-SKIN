import os
import re
import json
import time
import shutil
import zipfile
import tempfile
from urllib.request import Request, urlopen
import xbmc
import xbmcgui
import xbmcvfs

# === 核心配置 ===
SKIN_ADDON_ID = "skin.confluence.minsk"
TOTAL_EXPECTED_SIZE = 25 * 1024 * 1024  # 25MB作为总进度基准

# 路径配置
DOWNLOAD_DIR = "/storage/downloads/"
# 调试存档目录（更新完成后会清理）
DEBUG_ARCHIVE_DIR = os.path.join(DOWNLOAD_DIR, "skin_update_debug")

# 版本检测地址
PRIMARY_VER_URL = "https://gitee.com/ce-fans/minsk-skin/raw/master/minsk-skin/version.txt"
BACKUP_VER_BASE_URL = "https://hub.gitmirror.com/https://raw.githubusercontent.com/biuanb/MINSK-SKIN/main/resource/version.txt"

# 下载地址（Sjoin分割方式）
PRIMARY_DL_PRE_URL = "https://gitee.com/ce-fans/minsk-skin/raw/master/minsk-skin/skin.confluence.minsk-"
BACKUP_DL_PRE_URL = "https://hub.gitmirror.com/https://raw.githubusercontent.com/biuanb/MINSK-SKIN/main/resource/skin.confluence.minsk-"
DL_BASE_SUFFIX = ".zip"
SPLIT_SUFFIXES = ["001", "002", "003"]  # Sjoin分割文件后缀

ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
SKIN_DIR = os.path.join(ADDONS_DIR, SKIN_ADDON_ID)


def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[SkinUpdater] {message}", level)


def clean_up_files(file_list):
    """清理指定文件列表"""
    for file_path in file_list:
        try:
            if os.path.exists(file_path):
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    log(f"已清理文件: {file_path}")
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
                    log(f"已清理目录: {file_path}")
        except Exception as e:
            log(f"清理文件失败 {file_path}: {e}", xbmc.LOGWARNING)


def get_current_skin_version():
    """获取当前皮肤版本"""
    try:
        rpc_request = {
            "jsonrpc": "2.0",
            "method": "Addons.GetAddonDetails",
            "params": {"addonid": SKIN_ADDON_ID, "properties": ["version"]},
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(rpc_request))
        result = json.loads(response)
        if "result" in result and "addon" in result["result"]:
            return result["result"]["addon"]["version"]
        return None
    except Exception as e:
        log(f"获取当前版本失败: {e}", xbmc.LOGERROR)
        return None


def get_latest_version_from_url(url, add_timestamp=False):
    """从指定URL获取版本号"""
    try:
        if add_timestamp:
            timestamp = int(time.time())
            separator = '&' if '?' in url else '?'
            url = f"{url}{separator}t={timestamp}"
            
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urlopen(req, timeout=10) as response:
            version = response.read().decode('utf-8').strip()
            if re.match(r'^\d+\.\d+\.\d+\.\d+$', version) or re.match(r'^\d+\.\d+\.\d+$', version):
                log(f"通过地址[{url}]获取版本成功: {version}")
                return version
        log(f"地址[{url}]返回版本格式不正确")
        return None
    except Exception as e:
        log(f"从地址[{url}]获取版本失败: {str(e)}", xbmc.LOGERROR)
        return None


def get_remote_version_and_source_with_retry():
    """获取远程版本及来源，失败后重试"""
    max_retries = 2
    retry_delay = 20  # 秒
    
    for attempt in range(max_retries):
        log(f"尝试获取远程版本（第{attempt+1}次）")
        
        # 1. 优先使用Gitee主地址
        primary_version = get_latest_version_from_url(PRIMARY_VER_URL)
        if primary_version:
            return primary_version, "primary"

        # 2. 主地址失败，尝试备用加速地址
        log("主版本地址失败，尝试备用加速地址获取版本")
        backup_version = get_latest_version_from_url(BACKUP_VER_BASE_URL, add_timestamp=True)
        if backup_version:
            return backup_version, "backup"

        if attempt < max_retries - 1:
            log(f"将在{retry_delay}秒后重试...")
            time.sleep(retry_delay)

    return None, None


def get_latest_split_urls(version, source_type):
    """构造Sjoin分割文件的下载链接"""
    base_url = PRIMARY_DL_PRE_URL if source_type == "primary" else BACKUP_DL_PRE_URL
    base_filename = f"{base_url}{version}{DL_BASE_SUFFIX}"
    log(f"生成Sjoin分割文件地址 | 基础地址: {base_filename}")
    
    split_urls = []
    for suffix in SPLIT_SUFFIXES:
        url = f"{base_filename}.{suffix}"
        split_urls.append(url)
        log(f"生成地址[{suffix}]: {url}")
    
    return split_urls


def compare_versions(ver1, ver2):
    """比较版本号"""
    try:
        v1 = [int(p) for p in ver1.split('.')]
        v2 = [int(p) for p in ver2.split('.')]
        for i in range(max(len(v1), len(v2))):
            num1 = v1[i] if i < len(v1) else 0
            num2 = v2[i] if i < len(v2) else 0
            if num1 > num2:
                return 1
            elif num1 < num2:
                return -1
        return 0
    except Exception as e:
        log(f"版本比较出错: {e}", xbmc.LOGERROR)
        return None


def download_all_parts(split_urls, version, download_dir):
    """下载所有Sjoin分割文件（仅显示百分比进度）"""
    total_files = len(split_urls)
    downloaded_files = []
    total_downloaded = 0  # 已下载总大小
    dialog = xbmcgui.DialogProgress()
    dialog.create("皮肤更新", f"准备下载...")  # 初始提示
    
    try:
        log(f"开始下载分割文件 | 总数: {total_files} | 版本: {version}")
        
        for i, url in enumerate(split_urls, 1):
            filename = os.path.basename(url)
            save_path = os.path.join(download_dir, filename)
            
            if os.path.exists(save_path) and os.path.getsize(save_path) > 0:
                file_size = os.path.getsize(save_path)
                total_downloaded += file_size
                downloaded_files.append(save_path)
                log(f"文件 {filename} 已存在，跳过下载")
                continue
                
            # 开始下载当前文件
            req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urlopen(req) as response:
                file_size = int(response.headers.get("Content-Length", 0))
                downloaded_size = 0

                with open(save_path, "wb") as out_file:
                    while True:
                        chunk = response.read(8192)
                        if not chunk:
                            break
                        out_file.write(chunk)
                        downloaded_size += len(chunk)
                        total_downloaded += len(chunk)
                        
                        # 计算进度（仅显示百分比）
                        if TOTAL_EXPECTED_SIZE > 0:
                            percent = min(int((total_downloaded / TOTAL_EXPECTED_SIZE) * 100), 100)
                        else:
                            percent = int((downloaded_size / file_size) * 100) if file_size > 0 else 0
                            
                        # 仅显示百分比，不显示详细信息
                        dialog.update(percent, f"下载中... {percent}%")
                        
                        if dialog.iscanceled():
                            dialog.close()
                            xbmcgui.Dialog().ok("下载取消", "您已取消下载。")
                            return downloaded_files  # 返回已下载文件供后续清理

                downloaded_files.append(save_path)
                log(f"文件 {i}/{total_files} 下载成功")
        
        dialog.update(100, "下载完成，准备处理...")
        time.sleep(1)
        dialog.close()
        log(f"所有分割文件下载完成 | 已下载: {len(downloaded_files)}个")
        return downloaded_files
        
    except Exception as e:
        dialog.close()
        log(f"下载出错: {str(e)}", xbmc.LOGERROR)
        return downloaded_files


def merge_split_files(split_files, output_path, version):
    """合并Sjoin分割文件"""
    try:
        # 创建临时存档目录
        version_archive_dir = os.path.join(DEBUG_ARCHIVE_DIR, version)
        os.makedirs(version_archive_dir, exist_ok=True)

        # 验证分割文件完整性
        required_suffixes = set(SPLIT_SUFFIXES)
        found_suffixes = set()
        for file in split_files:
            for suffix in required_suffixes:
                if file.endswith(f".{suffix}"):
                    found_suffixes.add(suffix)
                    break
        missing = required_suffixes - found_suffixes
        if missing:
            log(f"分割文件不完整，缺少: {missing}", xbmc.LOGERROR)
            return False, version_archive_dir

        # 按001→002→003顺序排序
        def get_split_order(file_path):
            file_name = os.path.basename(file_path)
            for i, suffix in enumerate(SPLIT_SUFFIXES):
                if file_name.endswith(f".{suffix}"):
                    return i
            return 999

        split_files_sorted = sorted(split_files, key=get_split_order)
        log(f"合并顺序: {[os.path.basename(f) for f in split_files_sorted]}")

        # 复制到存档目录
        archived_files = []
        for file in split_files_sorted:
            archive_path = os.path.join(version_archive_dir, os.path.basename(file))
            shutil.copy2(file, archive_path)
            archived_files.append(archive_path)

        # 合并文件
        merged_archive_path = os.path.join(version_archive_dir, f"merged_{version}{DL_BASE_SUFFIX}")
        with open(merged_archive_path, 'wb') as outfile:
            for file in archived_files:
                with open(file, 'rb') as infile:
                    while True:
                        chunk = infile.read(1024 * 1024)  # 1MB块
                        if not chunk:
                            break
                        outfile.write(chunk)

        # 验证ZIP有效性
        is_valid = zipfile.is_zipfile(merged_archive_path)
        log(f"合并文件有效性: {'有效' if is_valid else '无效'}")
        
        # 复制到工作路径
        shutil.copy2(merged_archive_path, output_path)
        return is_valid, version_archive_dir
            
    except Exception as e:
        log(f"合并失败: {str(e)}", xbmc.LOGERROR)
        return False, None


def refresh_addon_database():
    """刷新插件数据库"""
    try:
        xbmc.executebuiltin('UpdateLocalAddons')
        log("已执行数据库刷新")
        time.sleep(2)
    except Exception as e:
        log(f"刷新数据库出错: {e}", xbmc.LOGERROR)


def copy_override(src_dir, dst_dir):
    """复制覆盖文件"""
    failed_files = []
    try:
        os.makedirs(dst_dir, exist_ok=True)

        for root, dirs, files in os.walk(src_dir):
            rel_path = os.path.relpath(root, src_dir)
            target_root = os.path.join(dst_dir, rel_path)
            os.makedirs(target_root, exist_ok=True)

            for file in files:
                src_file = os.path.join(root, file)
                dst_file = os.path.join(target_root, file)
                try:
                    if os.path.exists(dst_file):
                        os.remove(dst_file)
                    shutil.copy2(src_file, dst_file)
                except Exception as e:
                    failed_files.append(f"{dst_file} (原因: {str(e)[:50]})")
                    log(f"覆盖失败: {dst_file} | 原因: {e}")

        return True, failed_files
    except Exception as e:
        log(f"复制覆盖失败: {e}", xbmc.LOGERROR)
        return False, [f"整体复制失败 (原因: {str(e)[:50]})"]


def install_from_zip_dialog():
    """手动更新"""
    dialog = xbmcgui.Dialog()
    if dialog.ok("手动更新", "请把皮肤ZIP包复制到 downloads 文件夹后点击确定。"):
        xbmc.executebuiltin('InstallFromZip')
        xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')


def main():
    # 定义需要清理的文件列表
    files_to_clean = []
    
    try:
        if not xbmc.getCondVisibility('!Skin.HasSetting(allowskinupdate)'):
            log("皮肤更新开关未开启，跳过")
            return
        
        log("===== 开始皮肤更新流程 =====")
        current_ver = get_current_skin_version()
        remote_ver, source_type = get_remote_version_and_source_with_retry()

        if not current_ver or not remote_ver:
            log("无法获取版本信息，终止")
            return

        log(f"版本信息 | 当前: {current_ver} | 远程: {remote_ver}")
        compare_result = compare_versions(remote_ver, current_ver)

        if compare_result > 0:
            xbmc.executebuiltin('Skin.SetString(skincanupdate,1)')
            log("发现新版本，准备更新")

            dialog = xbmcgui.Dialog()
            options = ["自动更新", "手动更新", "不更新"]
            title = f"发现新版本 (当前: {current_ver} → 最新: {remote_ver})"
            ret = dialog.select(title, options)

            if ret == 0:  # 自动更新
                # 获取下载链接
                split_urls = get_latest_split_urls(remote_ver, source_type)
                if not split_urls:
                    xbmcgui.Dialog().ok("更新失败", "无法构造下载链接")
                    return
                
                # 下载文件
                downloaded_files = download_all_parts(split_urls, remote_ver, DOWNLOAD_DIR)
                files_to_clean.extend(downloaded_files)  # 加入清理列表
                
                if not downloaded_files or len(downloaded_files) != len(split_urls):
                    xbmcgui.Dialog().ok("下载错误", "文件下载不完整")
                    return
                
                # 合并文件
                merged_zip_path = os.path.join(DOWNLOAD_DIR, f"merged_{remote_ver}{DL_BASE_SUFFIX}")
                files_to_clean.append(merged_zip_path)  # 加入清理列表
                
                merge_success, archive_dir = merge_split_files(downloaded_files, merged_zip_path, remote_ver)
                if archive_dir:
                    files_to_clean.append(archive_dir)  # 加入清理列表
                
                if not merge_success or not archive_dir:
                    xbmcgui.Dialog().ok("合并失败", "分割文件合并失败或不完整")
                    return
                
                # 解压ZIP
                with tempfile.TemporaryDirectory() as temp_dir:
                    try:
                        log(f"开始解压: {merged_zip_path}")
                        with zipfile.ZipFile(merged_zip_path, 'r') as zip_ref:
                            zip_ref.extractall(temp_dir)
                    except Exception as e:
                        log(f"解压失败: {e}", xbmc.LOGERROR)
                        xbmcgui.Dialog().ok("解压失败", f"错误: {str(e)}")
                        return

                    # 定位皮肤源目录
                    src_skin_dir = temp_dir
                    if not os.path.exists(os.path.join(temp_dir, "addon.xml")):
                        for root, dirs, files in os.walk(temp_dir):
                            if "addon.xml" in files:
                                src_skin_dir = root
                                break

                    # 复制覆盖文件
                    success, failed_files = copy_override(src_skin_dir, SKIN_DIR)

                    if not success:
                        xbmcgui.Dialog().ok("更新失败", f"复制错误:\n{failed_files[0]}")
                        return
                    if failed_files:
                        fail_msg = "部分文件覆盖失败:\n" + "\n".join(failed_files[:3])
                        if len(failed_files) > 3:
                            fail_msg += f"\n... 共 {len(failed_files)} 个"
                        xbmcgui.Dialog().ok("更新警告", f"{fail_msg}\n建议重启Kodi。")

                # 刷新并重新加载皮肤
                refresh_addon_database()
                xbmc.executebuiltin('ReloadSkin()')
                time.sleep(3)

                new_version = get_current_skin_version()
                if new_version == remote_ver:
                    xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')
                    xbmcgui.Dialog().ok("更新成功", f"已更新到 {new_version}！")
                else:
                    xbmcgui.Dialog().ok("更新未生效", f"当前版本: {new_version}\n建议手动更新或重启。")

            elif ret == 1:  # 手动更新
                install_from_zip_dialog()

            # 不更新选项不做处理

        else:
            xbmc.executebuiltin('Skin.SetString(skincanupdate,0)')
            log("当前已是最新版本")
            xbmcgui.Dialog().notification("已是最新", "当前皮肤已是最新版本", xbmcgui.NOTIFICATION_INFO, 3000)
    
    finally:
        # 无论成功与否，都清理所有临时文件
        log("开始清理临时文件...")
        clean_up_files(files_to_clean)
        log("临时文件清理完成")
    
    log("===== 更新流程结束 =====")


if __name__ == "__main__":
    main()